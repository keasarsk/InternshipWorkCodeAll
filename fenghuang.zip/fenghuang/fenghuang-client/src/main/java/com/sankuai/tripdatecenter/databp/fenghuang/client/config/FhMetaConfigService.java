package com.sankuai.tripdatecenter.databp.fenghuang.client.config;

import com.facebook.swift.service.ThriftMethod;
import com.facebook.swift.service.ThriftService;
import com.meituan.servicecatalog.api.annotations.InterfaceDoc;
import com.meituan.servicecatalog.api.annotations.MethodDoc;
import com.meituan.servicecatalog.api.annotations.ParamDoc;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.request.DimensionAppConfigRequest;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.request.IndicatorAppConfigRequest;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.response.SubmitStatusResponse;

/**
 * description 凤凰指标维度配置接口
 *
 * @author nixuefeng
 * @createTime 2023/2/7 15:11
 */
@ThriftService
@InterfaceDoc(
        displayName = "凤凰元数据配置写入接口",
        type = "octo.thrift.annotation",
        scenarios = "凤凰元数据配置写入接口",
        description = "凤凰元数据配置写入接口"
)
public interface FhMetaConfigService {
    /**
     * 维度配置提交接口
     * @param request 维度配置信息请求参数
     * @return 数据存储结果
     */
    @ThriftMethod
    @MethodDoc(
            displayName = "维度配置提交接口",
            description = "维度配置提交接口",
            returnValueDescription = "维度配置提交结果",
            parameters = {@ParamDoc(
                    name = "request",
                    description = "请求参数"
            )},
            definition = "维度配置提交接口",
            example = "请求示例：1\n返回示例："
    )
    SubmitStatusResponse submitDimensionConfig(DimensionAppConfigRequest request);

    /**
     * 指标配置提交接口
     * @param request 指标配置信息请求参数
     * @return 数据存储结果
     */
    @ThriftMethod
    @MethodDoc(
            displayName = "指标配置提交接口",
            description = "指标配置提交接口",
            returnValueDescription = "指标配置提交结果",
            parameters = {@ParamDoc(
                    name = "request",
                    description = "请求参数"
            )},
            definition = "指标配置提交接口",
            example = "请求示例：1\n返回示例："
    )
    SubmitStatusResponse submitIndicatorConfig(IndicatorAppConfigRequest request);
}
