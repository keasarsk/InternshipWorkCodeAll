package com.sankuai.tripdatecenter.databp.fenghuang.client.config;

import com.facebook.swift.service.ThriftMethod;
import com.facebook.swift.service.ThriftService;
import com.meituan.servicecatalog.api.annotations.InterfaceDoc;
import com.meituan.servicecatalog.api.annotations.MethodDoc;
import com.meituan.servicecatalog.api.annotations.ParamDoc;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.request.DataSourceConfigRequest;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.request.DimensionInfoRequest;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.request.IndicatorCaliberInfoRequest;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.request.IndicatorFormulaRequest;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.request.IndicatorInfoRequest;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.response.DataSourceConfigResponse;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.response.DimensionResponse;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.response.IndicatorCeliberResponse;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.response.IndicatorFormulaResponse;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.response.IndicatorResponse;

/**
 * description 指标维度元数据
 *
 * @author fuzhengwei02
 * @createTime 2022年06月13日 11:44:00
 */
@ThriftService
@InterfaceDoc(
        displayName = "凤凰元数据查询接口",
        type = "octo.thrift.annotation",
        scenarios = "凤凰元数据查询接口",
        description = "凤凰元数据查询接口"
)
public interface ExMetadataConfigService {

    /**
     * 获取数据源配置信息
     * @param request 数据源配置查询请求
     * @return 数据源配置信息
     */
    @ThriftMethod
    @MethodDoc(
            displayName = "数据源配置查询接口",
            description = "数据源配置查询接口",
            returnValueDescription = "数据源配置查询结果",
            parameters = {@ParamDoc(
                    name = "request",
                    description = "请求参数"
            )},
            definition = "数据源配置查询接口",
            example = "请求示例：1\n返回示例："
    )
    DataSourceConfigResponse getDatasourceConfig(DataSourceConfigRequest request);

    /**
     * 获取指标口径信息
     * @param request 口径查询请求
     * @return 指标口径信息
     */
    @ThriftMethod
    @MethodDoc(
            displayName = "指标口径配置查询接口",
            description = "指标口径配置查询接口",
            returnValueDescription = "指标口径配置查询结果",
            parameters = {@ParamDoc(
                    name = "request",
                    description = "请求参数"
            )},
            definition = "指标口径配置查询接口",
            example = "请求示例：1\n返回示例："
    )
    IndicatorCeliberResponse getIndicatorCaliber(IndicatorCaliberInfoRequest request);

    /**
     * 获取指标元信息
     * @param request 指标信息查询
     * @return 指标元信息
     */
    @ThriftMethod
    @MethodDoc(
            displayName = "指标元信息查询接口",
            description = "指标元信息查询接口",
            returnValueDescription = "指标元信息返回结果",
            parameters = {@ParamDoc(
                    name = "request",
                    description = "指标元信息查询参数"
            )},
            definition = "指标元信息查询接口",
            example = "请求示例：1\n返回示例："
    )
    IndicatorResponse getIndicator(IndicatorInfoRequest request);

    /**
     * 获取维度元信息
     * @param request 维度元信息查询接口
     * @return 维度元信息
     */
    @ThriftMethod
    @MethodDoc(
            displayName = "维度元信息查询接口",
            description = "维度元信息查询接口",
            returnValueDescription = "维度元信息返回结果",
            parameters = {@ParamDoc(
                    name = "request",
                    description = "维度元信息查询参数"
            )},
            definition = "维度元信息查询接口",
            example = "请求示例：1\n返回示例："
    )
    DimensionResponse getDimension(DimensionInfoRequest request);

    /**
     * 获取指标公式信息
     * @param request 获取指标公式请求
     * @return 指标公式信息
     */
    @ThriftMethod
    @MethodDoc(
            displayName = "获取指标公式信息接口",
            description = "获取指标公式信息接口",
            returnValueDescription = "指标公式信息",
            parameters = {@ParamDoc(
                    name = "request",
                    description = "获取指标公式请求"
            )},
            definition = "指标公式信息",
            example = "请求示例：1\n返回示例："
    )
    IndicatorFormulaResponse getIndicatorFormulaInfo(IndicatorFormulaRequest request);

}
