package com.sankuai.tripdatecenter.databp.fenghuang.client.config;


import com.facebook.swift.service.ThriftMethod;
import com.facebook.swift.service.ThriftService;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.request.GetIndicatorRelatedAppRequest;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.response.GetIndicatorRelatedAppResponse;

/**
 * description 凤凰元数据导出服务
 *
 * @author fuzhengwei02
 * @createTime 2022年12月19日 14:30:00
 */
@ThriftService
public interface ExMetaExportService {

    @ThriftMethod
    GetIndicatorRelatedAppResponse getIndicatorRelatedApp(GetIndicatorRelatedAppRequest getIndicatorRelatedAppRequest);

}
