package com.sankuai.tripdatecenter.databp.fenghuang.client.config;

import com.facebook.swift.service.ThriftMethod;
import com.facebook.swift.service.ThriftService;
import com.meituan.servicecatalog.api.annotations.InterfaceDoc;
import com.meituan.servicecatalog.api.annotations.MethodDoc;
import com.meituan.servicecatalog.api.annotations.ParamDoc;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.domain.BusinessLineVO;

/**
 * description
 *
 * @author fuzhengwei02
 * @createTime 2022/4/13 11:49 上午
 */
@ThriftService
@InterfaceDoc(
        displayName = "凤凰业务线查询接口",
        type = "octo.thrift.annotation",
        scenarios = "凤凰业务线查询接口",
        description = "凤凰业务线查询接口"
)
public interface BusinessLineService {

    @ThriftMethod
    @MethodDoc(
            displayName = "根据业务线ID获取业务线信息接口",
            description = "根据业务线ID获取业务线信息接口",
            returnValueDescription = "业务线信息",
            parameters = {@ParamDoc(
                    name = "request",
                    description = "请求参数"
            )},
            definition = "根据业务线ID获取业务线信息接口",
            example = "请求示例：1\n返回示例："
    )
    BusinessLineVO getBusinessLineByBusinessId(String businessId);

}
