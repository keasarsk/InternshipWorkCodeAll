package com.sankuai.tripdatecenter.databp.fenghuang.client.utils;

import com.google.common.collect.Lists;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.domain.ConditionMappingInfo;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.domain.QueryCriteria;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.request.ConditionParam;
import com.sankuai.tripdatecenter.databp.fenghuang.common.enums.ConditionTypeEnum;
import com.sankuai.tripdatecenter.databp.fenghuang.common.enums.LogicOperatorEnum;
import java.util.List;
import java.util.Map;

/**
 * description Criteria 工具类
 *
 * @author fuzhengwei02
 * @createTime 2022年12月06日 11:24:00
 */
public class CriteriaUtils {

    /**
     * ConditionParam 转 Criteria
     * @param condition
     * @param conditionMappingInfo
     * @return
     */
    public static QueryCriteria convertToCriteria(ConditionParam condition, ConditionMappingInfo conditionMappingInfo){
        QueryCriteria rootQueryCriteria = QueryCriteria.createCriteria();
        //构建操作符
        LogicOperatorEnum logicOperatorEnum = LogicOperatorEnum.getByCode(condition.getLogicOperator());
        if(logicOperatorEnum == null){
            logicOperatorEnum = LogicOperatorEnum.AND;
        }
        rootQueryCriteria.setLogicOperator(logicOperatorEnum);

        //构建查询关系。
        List<Object> conditionList = Lists.newArrayList();
        rootQueryCriteria.setConditionList(conditionList);

        Map<String, List<String>> conditionParentChildrenMap = conditionMappingInfo.getConditionParentChildrenMap();
        Map<String, ConditionParam> conditionMap = conditionMappingInfo.getConditionMap();
        String conditionId = condition.getConditionId();
        List<String> childrenConditionIds = conditionParentChildrenMap.get(conditionId);

        //条件树构建
        for(String childrenConditionId : childrenConditionIds){
            ConditionParam childCondition = conditionMap.get(childrenConditionId);
            Integer conditionType = childCondition.getConditionType();
            ConditionTypeEnum conditionTypeEnum = ConditionTypeEnum.getByCode(conditionType);
            if(conditionTypeEnum == null){
                conditionTypeEnum = ConditionTypeEnum.CONDITION;
            }
            switch (conditionTypeEnum){
                case CONDITION:
                    conditionList.add(childCondition);
                    break;
                case CRITERIA:
                    //递归构建
                    QueryCriteria childQueryCriteria = convertToCriteria(childCondition, conditionMappingInfo);
                    conditionList.add(childQueryCriteria);
                    break;
                default:
                    //
            }
        }
        return rootQueryCriteria;
    }

}
