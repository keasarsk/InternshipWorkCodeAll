package com.sankuai.tripdatecenter.databp.fenghuang.client.constants;

/**
 * description 凤凰元数据相关常量
 *
 * @author fuzhengwei02
 * @createTime 2022年08月02日 21:14:00
 */
public class FenghuangConstant {

    /**
     * 起源指标、维度、应用后缀
     */
    public static final String ORIGIN_SUFFIX = "_1";

    /**
     * 临时指标、维度、应用后缀
     */
    public static final String TEMP_SUFFIX = "_2";

    /**
     * 上传指标、维度、应用后缀
     */
    public static final String UPLOAD_SUFFIX = "_3";

}
