package com.sankuai.tripdatecenter.databp.fenghuang.client.config;

import com.sankuai.tripdatecenter.databp.fenghuang.common.domain.filter.WutongOrgFilterVO;

import java.util.List;

/**
 * description 梧桐组织架构树功能
 *
 * @author mayuzhe
 * @createTime 2023-03-22
 */
public interface WutongOrgService {
    /**
     * 组织架构/区域架构 1.0，不带group
     *
     * @param type
     * @return
     */
    String getUserAuthNoGroupV1(String type, String mis);

    /**
     * 组织架构/区域架构 2.0，不带group
     *
     * @param type
     * @return
     */
    String getUserAuthNoGroupV2(String type, String mis);

    /**
     * 组织架构/区域架构 1.0
     *
     * @param type
     * @return
     */
    String getUserAuthV1(String type, String mis);

    /**
     * 组织架构/区域架构 2.0
     *
     * @param type
     * @return
     */
    String getUserAuthV2(String type, String mis);
}
