package com.sankuai.tripdatecenter.databp.fenghuang.client.config;

import com.facebook.swift.service.ThriftMethod;
import com.facebook.swift.service.ThriftService;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.request.OriginAppRequest;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.request.OriginSqlRequest;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.response.OriginAppResponse;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.response.OriginSqlResponse;

/**
 * description 起源元数据服务
 *
 * @author fuzhengwei02
 * @createTime 2022年06月13日 11:44:00
 */
@ThriftService
public interface ExOriginService {

    /**
     * 通用调用调用方法
     * @param request
     * @return
     */
    @ThriftMethod
    OriginSqlResponse getSql(OriginSqlRequest request);


    /**
     *
     * @param request
     * @return
     */
    @ThriftMethod
    OriginAppResponse getAppDetail(OriginAppRequest request);
}
