package com.sankuai.tripdatecenter.databp.fenghuang.client.utils;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.domain.ConditionMappingInfo;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.request.ConditionParam;
import java.util.List;
import java.util.Map;
import org.apache.commons.collections4.CollectionUtils;

/**
 * description 解析条件映射信息
 *
 * @author fuzhengwei02
 * @createTime 2022年12月06日 22:53:00
 */
public class ConditionUtils {

    public static ConditionMappingInfo parseConditionMapping(List<ConditionParam> conditions){
        Map<String, ConditionParam> conditionMap  = Maps.newHashMap();
        Map<String, String> conditionParentMap  = Maps.newHashMap();
        Map<String, List<String>> conditionParentChildrenMap  = Maps.newHashMap();
        if(CollectionUtils.isNotEmpty(conditions)){
            for(ConditionParam condition : conditions){
                String parentConditionId = condition.getParentConditionId();
                String conditionId = condition.getConditionId();
                if(conditionId != null && parentConditionId != null){
                    conditionParentMap.put(conditionId, parentConditionId);
                    conditionMap.put(conditionId, condition);
                    List<String> childrenConditionIds = conditionParentChildrenMap.get(parentConditionId);
                    if(childrenConditionIds == null){
                        childrenConditionIds = Lists.newArrayList();
                    }
                    childrenConditionIds.add(conditionId);
                    conditionParentChildrenMap.put(parentConditionId, childrenConditionIds);
                }
            }
        }
        ConditionMappingInfo newConditionMappingInfo = new ConditionMappingInfo();
        newConditionMappingInfo.setConditionMap(conditionMap);
        newConditionMappingInfo.setConditionParentMap(conditionParentMap);
        newConditionMappingInfo.setConditionParentChildrenMap(conditionParentChildrenMap);
        return newConditionMappingInfo;
    }

}
