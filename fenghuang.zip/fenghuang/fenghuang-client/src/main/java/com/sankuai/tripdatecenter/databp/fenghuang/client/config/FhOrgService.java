package com.sankuai.tripdatecenter.databp.fenghuang.client.config;

import com.sankuai.tripdatecenter.databp.fenghuang.client.config.request.GetAllAreasRequest;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.request.GetAllOrgsRequest;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.request.GetUserAuthAreasRequest;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.request.GetUserAuthOrgsRequest;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.response.OrgTreeResponse;

/**
 * description 组织架构树功能
 *
 * @author fuzhengwei02
 * @createTime 2022年04月28日 14:11:00
 */
public interface FhOrgService {

    /**
     * 获取所有组织架构树V1(带SKA)
     * @param getAllOrgsRequest
     * @return
     */
    OrgTreeResponse getAllOrgsV1(GetAllOrgsRequest getAllOrgsRequest);

    /**
     * 获取所有组织架构树V2（不带SKA）
     * @param getAllOrgsRequest
     * @return
     */
    OrgTreeResponse getAllOrgsV2(GetAllOrgsRequest getAllOrgsRequest);

    /**
     * 获取所有区域架构树V1(带SKA)
     * @param getAllAreasRequest
     * @return
     */
    OrgTreeResponse getAllAreasV1(GetAllAreasRequest getAllAreasRequest);

    /**
     * 获取所有区域架构树V2（不带SKA）
     * @param getAllAreasRequest
     * @return
     */
    OrgTreeResponse getAllAreasV2(GetAllAreasRequest getAllAreasRequest);

    /**
     * 获取人员有权限的组织架构树V1(带SKA)
     * @param getUserAuthOrgsRequest
     * @return
     */
    OrgTreeResponse getUserAuthOrgsV1(GetUserAuthOrgsRequest getUserAuthOrgsRequest);

    /**
     * 获取人员有权限的组织架构树（不带SKA）
     * @param getUserAuthOrgsRequest
     * @return
     */
    OrgTreeResponse getUserAuthOrgsV2(GetUserAuthOrgsRequest getUserAuthOrgsRequest);

    /**
     * 获取人员有权限的区域架构树V1(带SKA)
     * @param getUserAuthAreasRequest
     * @return
     */
    OrgTreeResponse getUserAuthAreasV1(GetUserAuthAreasRequest getUserAuthAreasRequest);

    /**
     * 获取人员有权限的区域架构树（不带SKA）
     * @param getUserAuthAreasRequest
     * @return
     */
    OrgTreeResponse getUserAuthAreasV2(GetUserAuthAreasRequest getUserAuthAreasRequest);



}
