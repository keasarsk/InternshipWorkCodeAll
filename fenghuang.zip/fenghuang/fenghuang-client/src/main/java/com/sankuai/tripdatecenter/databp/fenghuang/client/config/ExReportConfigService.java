package com.sankuai.tripdatecenter.databp.fenghuang.client.config;


import com.facebook.swift.service.ThriftMethod;
import com.facebook.swift.service.ThriftService;
import com.meituan.servicecatalog.api.annotations.MethodDoc;
import com.meituan.servicecatalog.api.annotations.ParamDoc;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.request.*;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.response.*;

import java.util.List;

/**
 * description 报表配置信息接口
 *
 * @author fuzhengwei02
 */
@ThriftService
public interface ExReportConfigService {

    /**
     * 查询报表配置信息
     * @param request 查询报表配置请求
     * @return 报表配置
     */
    @ThriftMethod
    LoadReportConfigResponse getReportConfig(LoadReportConfigRequest request);

    /**
     * 查询报表基本信息
     * @param request 查询报表请求
     * @return 报表配置信息
     */
    @ThriftMethod
    GetReportConfigBaseInfoResponse getReportConfigBaseInfo(GetReportConfigBaseInfoRequest request);

    /**
     * 查询报表主题信息
     * @param request 查询主题配置请求
     * @return 主题配置
     */
    @ThriftMethod
    GetTopicConfigInfoResponse getTopicConfigInfoRequest (GetTopicConfigInfoRequest request);

    /**
     *  查询指标应用信息
     * @param request 查询指标应用请求
     * @return 指标应用信息
     */
    @ThriftMethod
    IndicatorAppConfigResponse getIndicatorAppConfig(IndicatorAppConfigRequest request);

    /**
     * 查询报表下所有的指标
     * @param reportId 报表ID
     * @param topicId  主题ID
     * @param version  版本
     * @return 指标信息
     */
    @ThriftMethod
    QueryReportTopicIndicatorIdsResponse queryReportTopicIndicatorIds(Long reportId, Long topicId, Long version);

    /**
     *  查询报表主题下指标配置信息
     * @param reportId 报表ID
     * @param topicId  主题ID
     * @param version  版本
     * @param indicatorIds 指标ID
     * @return 指标配置信息
     */
    @ThriftMethod
    QueryReportTopicIndicatorInfosResponse queryReportTopicIndicatorInfos(Long reportId, Long topicId, Long version, List<String> indicatorIds);

    /**
     * 指标和维度维值权限校验
     * @param reportId 报表ID
     * @param topicId  主题ID
     * @param version  版本
     * @param indicatorIds 指标ID
     * @param dimensionId  维度ID
     * @param dimensionEnumValues 维值
     * @return
     */
    @ThriftMethod
    CheckIndicatorDimensionPermissionResponse checkIndicatorDimensionPermission(Long reportId, Long topicId, Long version, List<String> indicatorIds, String dimensionId, List<String> dimensionEnumValues);

    /**
     * 报表主题下模块信息
     * @param reportId 报表ID
     * @param topicId  主题ID
     * @param version  版本
     * @return         模块信息
     */
    @ThriftMethod
    QueryReportTopicModuleInfoResponse queryReportTopicModuleInfo(Long reportId, Long topicId, Long version);

    /**
     * 查询模块下root指标Id
     * @param reportId 报表ID
     * @param topicId  主题ID
     * @param moduleId 模块ID
     * @param version  版本
     * @return         指标ID
     */
    @ThriftMethod
    QueryModuleIndicatorIdsResponse queryModuleRootIndicatorIds(Long reportId, Long topicId, Long moduleId, Long version);

    /**
     * 查询主题模版信息
     * @param reportId 报表ID
     * @param topicId  主题ID
     * @param version  版本
     * @param businessId 业务线ID
     * @return         主题模版信息
     */
    @ThriftMethod
    GetTopicTemplateResponse getTopicTemplate(Long reportId, Long topicId, Long version, String businessId);

    /**
     * 查询模块下全部指标ID
     * @param reportId 报表ID
     * @param topicId  主题ID
     * @param moduleId 模块ID
     * @param version  版本
     * @return         指标ID
     */
    @ThriftMethod
    QueryModuleIndicatorIdsResponse queryModuleAllIndicatorIds(Long reportId, Long topicId, Long moduleId, Long version);

    /**
     *
     * @param request
     * @return
     */
    @ThriftMethod
    @MethodDoc(
            displayName = "获取维度枚举值信息",
            description = "获取维度枚举值信息",
            returnValueDescription = "维度枚举值信息",
            parameters = {@ParamDoc(
                    name = "request",
                    description = "维度枚举值信息请求"
            )},
            definition = "指标公式信息",
            example = "请求示例：1\n返回示例："
    )
    DimReduceDimensionResponse getDimReduceDimensionInfo(DimReduceDimensionRequest request);

    /**
     *
     * @param request
     * @return
     */
    @ThriftMethod
    @MethodDoc(
            displayName = "获取维度枚举值信息",
            description = "获取维度枚举值信息",
            returnValueDescription = "维度枚举值信息",
            parameters = {@ParamDoc(
                    name = "request",
                    description = "维度枚举值信息请求"
            )},
            definition = "指标公式信息",
            example = "请求示例：1\n返回示例："
    )
    DimReduceDimensionListResponse getDimReduceDimensionList(DimReduceDimensionListRequest request);

    /**
     *
     * @param request
     * @return
     */
    @ThriftMethod
    @MethodDoc(
            displayName = "获取报表业务线信息",
            description = "获取报表业务线信息",
            returnValueDescription = "报表业务线信息",
            parameters = {@ParamDoc(
                    name = "request",
                    description = "获取报表业务线信息请求"
            )},
            definition = "报表业务线信息",
            example = "请求示例：1\n返回示例："
    )
    GetBusinessIdResponse getReportBusinessId(GetBusinessIdRequest request);

}
