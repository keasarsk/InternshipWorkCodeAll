package com.sankuai.tripdatecenter.databp.fenghuang.client.config;


import com.facebook.swift.service.ThriftMethod;
import com.facebook.swift.service.ThriftService;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.domain.ResourceAttrInfo;

import java.util.List;

/**
 * description 权限验证服务
 *
 * @author fuzhengwei02
 * @createTime 2022年06月13日 11:44:00
 */
@ThriftService
public interface FhAuthService {

    @ThriftMethod
    boolean checkPermission(String misId, String resourceCode);

    @ThriftMethod
    boolean checkResourceExists(String resourceCode);

    @ThriftMethod
    boolean updateResourceAttr(String resourceCode, ResourceAttrInfo resourceAttrInfo);

    @ThriftMethod
    String getAuthResourceAttr(String misId, String resourceCode);

    @ThriftMethod
    boolean authResource(String misId, String resourceCode, String authStr);

    @ThriftMethod
    String getAuthResourceCascade(String mis, String resourceCodeRoot);

    @ThriftMethod
    String getResourceInfoCascade(String resourceCode);

}
