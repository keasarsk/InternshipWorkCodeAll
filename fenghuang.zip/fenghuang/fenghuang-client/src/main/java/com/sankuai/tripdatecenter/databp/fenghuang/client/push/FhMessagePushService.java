package com.sankuai.tripdatecenter.databp.fenghuang.client.push;

import com.sankuai.tripdatecenter.databp.fenghuang.client.config.request.SendComplexMessageRequest;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.request.SendRoomComplexMessageRequest;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.request.SendRoomTextMessageRequest;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.request.SendTextMessageRequest;
import com.sankuai.tripdatecenter.databp.fenghuang.common.domain.result.thrift.BooleanDataResult;

/**
 * description TODO
 *
 * @author fuzhengwei02
 * @createTime 2022年10月25日 14:09:00
 */
public interface FhMessagePushService {

    /**
     * 发送个人文本消息
     * @param sendTextMessageRequest
     * @return
     */
    BooleanDataResult sendTextMessage(SendTextMessageRequest sendTextMessageRequest);


    /**
     * 发送复杂消息
     * @param sendComplexMessageRequest
     * @return
     */
    BooleanDataResult sendComplexMessageRequest(SendComplexMessageRequest sendComplexMessageRequest);

    /**
     * 发送群文本消息
     * @param sendRoomTextMessageRequest
     * @return
     */
    BooleanDataResult sendRoomMessage(SendRoomTextMessageRequest sendRoomTextMessageRequest);

    /**
     * 发送群复合消息
     * @param sendRoomComplexMessageRequest
     * @return
     */
    BooleanDataResult sendRoomComplexMessage(SendRoomComplexMessageRequest sendRoomComplexMessageRequest);

}
