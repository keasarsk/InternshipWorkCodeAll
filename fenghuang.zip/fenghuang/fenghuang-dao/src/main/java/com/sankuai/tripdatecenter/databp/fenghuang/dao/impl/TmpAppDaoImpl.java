package com.sankuai.tripdatecenter.databp.fenghuang.dao.impl;

import com.sankuai.tripdatecenter.databp.fenghuang.common.domain.request.TmpAppRequestParam;
import com.sankuai.tripdatecenter.databp.fenghuang.common.enums.DeleteStatusEnum;
import com.sankuai.tripdatecenter.databp.fenghuang.common.enums.OnlineStatusEnum;
import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.TimeUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.WutongUserUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.TmpAppDao;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.mapper.auto.TmpAppPOMapper;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.mapper.ext.TmpAppPOMapperExt;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ext.TmpAppExtPO;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.TmpAppPO;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.example.TmpAppPOExample;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.List;

import static com.sankuai.tripdatecenter.databp.fenghuang.common.constant.NumberConstant.ZERO;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2022/4/22 2:16 下午
 */
@Repository
public class TmpAppDaoImpl implements TmpAppDao {
    @Resource
    private TmpAppPOMapper tmpAppPOMapper;

    @Resource
    private TmpAppPOMapperExt tmpAppPOMapperExt;

    @Override
    public List<TmpAppExtPO> selectList(TmpAppRequestParam requestParam) {
        List<TmpAppExtPO> tmpApps = tmpAppPOMapperExt.selectTmpApp(requestParam);
        if(tmpApps == null){
            return Collections.EMPTY_LIST;
        }
        return tmpApps;
    }

    @Override
    public TmpAppExtPO selectDetail(Long tmpAppId, Long version, String businessId) {
        return tmpAppPOMapperExt.selectTmpAppByAppIdAndVersion(tmpAppId, version, businessId);
    }

    @Override
    public Long selectMaxVersion(Long tmpAppId, String businessId) {
        Long version = tmpAppPOMapperExt.selectMaxTmpAppVersion(tmpAppId, businessId);
        if(version == null){
            version = (long)ZERO;
        }
        return version;
    }

    @Override
    public int updateByIdAndVersion(TmpAppPO tmpAppPO, String businessId) {
        setUpdateInfo(tmpAppPO);
        TmpAppPOExample example = new TmpAppPOExample();
        TmpAppPOExample.Criteria criteria = example.createCriteria();
        criteria.andTmpappIdEqualTo(tmpAppPO.getTmpappId());
        criteria.andBusinessIdEqualTo(businessId);
        if(tmpAppPO.getVersion() != null){
            criteria.andVersionEqualTo(tmpAppPO.getVersion());
        }
        return tmpAppPOMapper.updateByExampleSelective(tmpAppPO, example);
    }

    @Override
    public int insertTmpApp(TmpAppPO tmpAppPO, String businessId) {
        setCreateInfo(tmpAppPO);
        setUpdateInfo(tmpAppPO);
        tmpAppPO.setBusinessId(businessId);
        return tmpAppPOMapper.insert(tmpAppPO);
    }

    private void setCreateInfo(TmpAppPO tmpAppPO){
        tmpAppPO.setCreatedTime(TimeUtils.getCurrentJavaDate());
        tmpAppPO.setCreatedMis(WutongUserUtils.getUser());
        tmpAppPO.setIsOnline(OnlineStatusEnum.OFFLINE.getCode());
        tmpAppPO.setIsDelete(DeleteStatusEnum.NOT_DELETED.getCode());
        setUpdateInfo(tmpAppPO);
    }

    private void setUpdateInfo(TmpAppPO tmpAppPO){
        tmpAppPO.setUpdateTime(TimeUtils.getCurrentJavaDate());
        tmpAppPO.setLastUpdateMis(WutongUserUtils.getUser());
    }

}
