package com.sankuai.tripdatecenter.databp.fenghuang.dao.impl;

import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.TimeUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.WutongUserUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.DatasourceDAO;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.mapper.auto.DatasourcePOMapper;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.DatasourcePO;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.example.DatasourcePOExample;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

import static com.sankuai.tripdatecenter.databp.fenghuang.common.constant.NumberConstant.ZERO;

/**
 * Description:
 *
 * @author mayuzhe@meituan.com
 * @date 2022/4/11
 */
@Repository
public class DatasourceDAOImpl implements DatasourceDAO {
    @Resource
    private DatasourcePOMapper datasourcePOMapper;

    @Override
    public List<DatasourcePO> selectDsnList(String businessId) {
        return this.selectMultiByExampleWithBLOBs(this.createCommonExample(businessId));
    }

    @Override
    public DatasourcePO selectByDsnId(long dsnId, String businessId) {
        DatasourcePOExample example = this.createCommonExample(businessId);
        example.getOredCriteria().get(0).andDatasourceIdEqualTo(dsnId);
        return this.selectByExampleWithBLOBs(example);
    }

    @Override
    public void insertDsn(DatasourcePO datasourcePO, String businessId) {
        Date curDate = TimeUtils.getCurrentJavaDate();
        String mis = WutongUserUtils.getUser();
        datasourcePO.setCreatedTime(curDate);
        datasourcePO.setUpdateTime(curDate);
        datasourcePO.setCreatedMis(mis);
        datasourcePO.setLastUpdateMis(mis);
        if (datasourcePO.getParams() == null || StringUtils.isBlank(datasourcePO.getParams())) {
            datasourcePO.setParams(null);
        }
        datasourcePO.setBusinessId(businessId);
        datasourcePOMapper.insertSelective(datasourcePO);
    }

    @Override
    public DatasourcePO updateDsn(long dsnId, DatasourcePO datasourcePO, String businessId) {
        // 准备 Example
        DatasourcePOExample example = this.createCommonExample(businessId);
        example.getOredCriteria().get(0).andDatasourceIdEqualTo(dsnId);
        this.updateByExampleSelective(datasourcePO, example);
        return datasourcePO;
    }

    @Override
    public void deleteByDsnId(long dsnId, String businessId) {
        DatasourcePO datasourcePO = new DatasourcePO();
        datasourcePO.setIsDelete((short) 1);

        // 准备 Example
        DatasourcePOExample example = this.createCommonExample(businessId);
        example.getOredCriteria().get(0).andDatasourceIdEqualTo(dsnId);
        datasourcePOMapper.updateByExampleSelective(datasourcePO, example);
    }

    @Override
    public boolean isExisted(DatasourcePO datasourcePO, String businessId) {
        DatasourcePOExample datasourcePOExample = createCommonExample(businessId);
        datasourcePOExample.getOredCriteria().get(ZERO).andDatasourceNameEqualTo(datasourcePO.getDatasourceName());
        return !CollectionUtils.isEmpty(selectMultiByExampleWithBLOBs(datasourcePOExample));
    }

    /**
     * 创建公共 example
     *
     * @return
     */
    private DatasourcePOExample createCommonExample(String businessId){
        DatasourcePOExample example = new DatasourcePOExample();
        DatasourcePOExample.Criteria criteria = example.createCriteria();
        criteria.andIsDeleteEqualTo((short) 0).andBusinessIdEqualTo(businessId);
        return example;
    }

    /**
     * 查询多条
     *
     * @param example
     * @return
     */
    private List<DatasourcePO> selectMultiByExampleWithBLOBs(DatasourcePOExample example) {
        return datasourcePOMapper.selectByExampleWithBLOBs(example);
    }


    /**
     * 查询单条
     *
     * @param example
     * @return
     */
    private DatasourcePO selectByExampleWithBLOBs(DatasourcePOExample example) {
        List<DatasourcePO> list = datasourcePOMapper.selectByExampleWithBLOBs(example);
        if (list.isEmpty()) {
            return null;
        }
        return list.get(0);
    }

    /**
     * 封装更新。修改更新人mis、更新时间
     *
     * @param po
     * @param example
     * @return
     */
    private int updateByExampleSelective(DatasourcePO po, DatasourcePOExample example) {
        po.setLastUpdateMis(WutongUserUtils.getUser());
        po.setUpdateTime(TimeUtils.getCurrentJavaDate());
        return datasourcePOMapper.updateByExampleSelective(po, example);
    }
}
