package com.sankuai.tripdatecenter.databp.fenghuang.dao.mapper.ext;

import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ext.TopicDimensionExtPO;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.TopicDimensionPO;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * description 报表相关Mapper
 *
 * @author nixuefeng
 * @createTime 2022/4/19 8:04 下午
 */
public interface TopicDimensionPOMapperExt {
    Integer selectMaxOrderNum(@Param("reportId") Long reportId, @Param("topicId") Long topicId,
                              @Param("version") Long version);

    void batchUpdateTopicDimensionOrder(@Param("topicDimensions") List<TopicDimensionPO> topicDimensions);

    List<TopicDimensionExtPO> selectListByTopicId(@Param("reportId") Long reportId, @Param("topicId") Long topicId,
                                                  @Param("version") Long version);

    List<TopicDimensionExtPO> selectEnumListByTopicId(@Param("reportId") Long reportId,
                                                      @Param("topicId") Long topicId,
                                                      @Param("dimensionId") String dimensionId,
                                                      @Param("version") Long version
                                                      );

    int insertBatch(@Param("topicDimensions") List<TopicDimensionPO> topicDimensions);

}
