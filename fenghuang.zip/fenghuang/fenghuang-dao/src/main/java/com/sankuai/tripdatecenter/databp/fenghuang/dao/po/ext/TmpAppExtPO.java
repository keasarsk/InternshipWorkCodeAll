package com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ext;

import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.TmpAppPO;
import lombok.Data;
import lombok.ToString;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2022/4/11 4:00 下午
 */
@Data
@ToString
public class TmpAppExtPO extends TmpAppPO {
    /**
     * 数据源名字
     */
    private String datasourceName;

    /**
     * 数据源类型。MySQL、Doris、Kylin、ES
     */
    private String datasourceType;


}
