package com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ext;

import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.TopicDimensionPO;
import lombok.Data;
import lombok.ToString;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2022/4/25 11:28 下午
 */
@Data
@ToString
public class TopicDimensionExtPO extends TopicDimensionPO {
    /**
     * 维度 name
     */
    private String dimensionName;

    /**
     * 维度枚举code
     */
    private String dimensionEnumCode;

    /**
     * 维度枚举值
     */
    private String dimensionEnumName;
}
