package com.sankuai.tripdatecenter.databp.fenghuang.dao;

import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.TopicDimensionEnumPO;

import java.util.List;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2022/4/28 6:37 下午
 */
public interface TopicDimensionEnumDao {
    List<TopicDimensionEnumPO> selectListById(Long reportId, Long topicId, String dimensionId, Long version);
    int insertDimensionEnums(List<TopicDimensionEnumPO> topicDimensionEnumPOS);
    int deleteDimensionEnumByTopicId(Long reportId, Long topicId, String dimensionId, Long version);
}
