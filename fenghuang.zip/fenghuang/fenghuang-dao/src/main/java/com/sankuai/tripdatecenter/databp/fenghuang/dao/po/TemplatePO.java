package com.sankuai.tripdatecenter.databp.fenghuang.dao.po;

import java.util.Date;
import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class TemplatePO {
    /**
     * 自增主键
     */
    private Long id;

    /**
     * 模板 id
     */
    private Long templateId;

    /**
     * 模板 code
     */
    private String templateCode;

    /**
     * 模板名称
     */
    private String templateName;

    private String templateType;

    /**
     * 是否在线。0为下线，1为在线
     */
    private Short isOnline;

    /**
     * 是否删除。0为未删除，1为删除
     */
    private Short isDelete;

    /**
     * 编辑人
     */
    private String createdMis;

    /**
     * 最新编辑人
     */
    private String lastUpdateMis;

    /**
     * 创建时间
     */
    private Date createdTime;

    /**
     * 最后修改时间
     */
    private Date updateTime;
}