package com.sankuai.tripdatecenter.databp.fenghuang.dao;

import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.DimReduceDimEnumPO;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ext.IndicatorReduceDimExtPO;

import java.util.List;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2023/5/26 15:17
 */
public interface IndicatorReduceDimDao {
    List<IndicatorReduceDimExtPO> getReduceDimByIndicatorId(Long topicId, String indicatorId);

    List<IndicatorReduceDimExtPO> getReduceDimByTopicId(Long topicId);

    int deleteDimReduceByIndicator(Long reportId, Long topicId, String indicatorId, Long version);

    int batchSaveReduceDimEnums(List<DimReduceDimEnumPO> dimReduceDimEnumPOS);
}
