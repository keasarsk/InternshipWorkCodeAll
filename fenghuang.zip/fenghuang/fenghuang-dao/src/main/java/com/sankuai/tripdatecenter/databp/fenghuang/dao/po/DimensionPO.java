package com.sankuai.tripdatecenter.databp.fenghuang.dao.po;

import java.util.Date;
import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class DimensionPO {
    /**
     * 自增主键
     */
    private Long id;

    /**
     * 维度 id
     */
    private String dimensionId;

    /**
     * 版本号。格式 yyyyMMddHHmmss
     */
    private Long version;

    /**
     * 应用 id
     */
    private Long appId;

    /**
     * 应用类型。起源1，临时应用2。默认为1
     */
    private String appType;

    /**
     * 维度 code
     */
    private String dimensionCode;

    /**
     * 维度名
     */
    private String dimensionName;

    /**
     * 维度类型
     */
    private String dimensionType;

    /**
     * 维度注释
     */
    private String dimensionComment;

    /**
     * 是否删除。0为未删除，1为删除
     */
    private Short isDelete;

    /**
     * 编辑人
     */
    private String createdMis;

    /**
     * 最新编辑人
     */
    private String lastUpdateMis;

    /**
     * 创建时间
     */
    private Date createdTime;

    /**
     * 最后修改时间
     */
    private Date updateTime;

    /**
     * 业务线ID
     */
    private String businessId;
}