package com.sankuai.tripdatecenter.databp.fenghuang.dao.impl;

import com.sankuai.hbdata.commonutils.common.CollectionUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.common.enums.DataTypeEnum;
import com.sankuai.tripdatecenter.databp.fenghuang.common.enums.DataUnitEnum;
import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.TimeUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.WutongUserUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.TopicIndicatorDAO;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.mapper.auto.TopicIndicatorPOMapper;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.mapper.ext.TopicIndicatorPOMapperExt;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.TopicIndicatorPO;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.example.TopicIndicatorPOExample;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ext.TopicIndicatorExtPO;
import org.apache.commons.compress.utils.Lists;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

/**
 * Description:
 *
 * @author mayuzhe@meituan.com
 * @date 2022/4/20
 */
@Repository
public class TopicIndicatorDAOImpl implements TopicIndicatorDAO {
    @Resource
    private TopicIndicatorPOMapper topicIndicatorPOMapper;
    @Resource
    private TopicIndicatorPOMapperExt topicIndicatorPOMapperExt;

    @Override
    public void offlineIndicator(long curId) {
        TopicIndicatorPO po = new TopicIndicatorPO();
        po.setIsOnline((short) 0);
        TopicIndicatorPOExample example = this.createCommonExample();
        example.getOredCriteria().get(0)
                .andCurIdEqualTo(curId);
        this.updateByExampleSelective(po, example);
    }

    @Override
    public void deleteModuleIndicators(long reportId, long version, long moduleId) {
        TopicIndicatorPOExample example = this.createCommonExample();
        example.getOredCriteria().get(0)
                .andReportIdEqualTo(reportId)
                .andVersionEqualTo(version)
                .andModuleIdEqualTo(moduleId);
        topicIndicatorPOMapper.deleteByExample(example);
    }

    @Override
    public void deleteIndicator(long curId) {
        TopicIndicatorPOExample example = this.createCommonExample();
        example.getOredCriteria().get(0)
                .andCurIdEqualTo(curId);
        topicIndicatorPOMapper.deleteByExample(example);
    }

    @Override
    public void insertIndicator(TopicIndicatorPO topicIndicatorPO) {
        setDefaultValue(topicIndicatorPO);
        topicIndicatorPOMapper.insertSelective(topicIndicatorPO);
    }

    @Override
    public void updateIndicator(TopicIndicatorPO topicIndicatorPO) {
        TopicIndicatorPOExample example = this.createCommonExample();
        example.getOredCriteria().get(0)
                .andCurIdEqualTo(topicIndicatorPO.getCurId());
        this.updateByExampleSelective(topicIndicatorPO, example);
    }

    @Override
    public List<TopicIndicatorPO> selectIndicators(long reportId, long version, long moduleId) {
        TopicIndicatorPOExample example = this.createCommonExample();
        example.getOredCriteria().get(0)
                .andReportIdEqualTo(reportId)
                .andVersionEqualTo(version)
                .andModuleIdEqualTo(moduleId);
        return topicIndicatorPOMapper.selectByExample(example);
    }

    @Override
    public List<TopicIndicatorPO> selectIndicatorsByTopic(long reportId, long version, long topicId, String indicatorId) {
        TopicIndicatorPOExample example = this.createCommonExample();
        example.getOredCriteria().get(0)
                .andVersionEqualTo(version)
                .andTopicIdEqualTo(topicId)
                .andReportIdEqualTo(reportId)
                .andIndicatorIdEqualTo(indicatorId);
        return topicIndicatorPOMapper.selectByExample(example);
    }

    @Override
    public List<TopicIndicatorExtPO> selectIndicatorsByModuleId(Long reportId, Long version, Long moduleId) {
        return topicIndicatorPOMapperExt.selectIndicatorsByRTMIIds(reportId, version, moduleId);
    }

    /**
     * 创建公共 example
     *
     * @return
     */
    private TopicIndicatorPOExample createCommonExample() {
        TopicIndicatorPOExample example = new TopicIndicatorPOExample();
        TopicIndicatorPOExample.Criteria criteria = example.createCriteria();
        criteria.andIsDeleteEqualTo((short) 0);
        return example;
    }

    /**
     * 查询多条
     *
     * @param example
     * @return
     */
    private List<TopicIndicatorPO> selectMultiByExample(TopicIndicatorPOExample example) {
        return topicIndicatorPOMapper.selectByExample(example);
    }

    /**
     * 查询单条
     *
     * @param example
     * @return
     */
    private TopicIndicatorPO selectByExample(TopicIndicatorPOExample example) {
        List<TopicIndicatorPO> list = topicIndicatorPOMapper.selectByExample(example);
        if (list.isEmpty()) {
            return null;
        }
        return list.get(0);
    }


    /**
     * 封装更新。修改更新人mis、更新时间
     *
     * @param po
     * @param example
     * @return
     */
    private int updateByExampleSelective(TopicIndicatorPO po, TopicIndicatorPOExample example) {
        po.setLastUpdateMis(WutongUserUtils.getUser());
        po.setUpdateTime(TimeUtils.getCurrentJavaDate());
        return topicIndicatorPOMapper.updateByExampleSelective(po, example);
    }

    @Override
    public List<TopicIndicatorPO> selectIndicatorById(String indicatorId) {
        TopicIndicatorPOExample example = this.createCommonExample();
        example.getOredCriteria().get(0)
                .andIndicatorIdEqualTo(indicatorId)
                .andIsDeleteEqualTo((short) 0);
        return topicIndicatorPOMapper.selectByExample(example);
    }

    @Override
    public List<String> checkTopicIndicatorDuplicate(Long report, Long topicId, Long version) {
        return topicIndicatorPOMapperExt.selectTopicIndicatorsDuplicate(report, topicId, version);
    }

    @Override
    public int batchInsertTopicIndicators(List<TopicIndicatorPO> topicIndicatorPOs) {
        if (CollectionUtils.isEmpty(topicIndicatorPOs)) {
            return 0;
        }
        List<TopicIndicatorExtPO> topicIndicatorExtPOs = Lists.newArrayList();
        topicIndicatorPOs.stream().forEach(topicIndicatorPO -> {
            setDefaultValue(topicIndicatorPO);
            TopicIndicatorExtPO topicIndicatorExtPO = new TopicIndicatorExtPO();
            BeanUtils.copyProperties(topicIndicatorPO, topicIndicatorExtPO);
            topicIndicatorExtPOs.add(topicIndicatorExtPO);
        });
        return topicIndicatorPOMapperExt.insertBatch(topicIndicatorExtPOs);
    }

    @Override
    public int deleteByTopicId(Long reportId, Long topicId, Long version) {
        TopicIndicatorPOExample example = new TopicIndicatorPOExample();
        example.createCriteria()
                .andReportIdEqualTo(reportId)
                .andTopicIdEqualTo(topicId)
                .andVersionEqualTo(version);
        return topicIndicatorPOMapper.deleteByExample(example);
    }

    private void setDefaultValue(TopicIndicatorPO topicIndicatorPO) {
        Date curDate = TimeUtils.getCurrentJavaDate();
        String mis = WutongUserUtils.getFhUserInfo().getMisId();
        topicIndicatorPO.setCreatedMis(mis);
        topicIndicatorPO.setLastUpdateMis(mis);
        topicIndicatorPO.setUpdateTime(curDate);
        topicIndicatorPO.setCreatedTime(curDate);
        topicIndicatorPO.setIsDelete((short) 0);
        topicIndicatorPO.setIsOnline((short) 1);
        if(topicIndicatorPO.getValueDigit() == null){
            topicIndicatorPO.setValueDigit(0);
        }
        if(topicIndicatorPO.getValueType() == null){
            topicIndicatorPO.setValueType(DataTypeEnum.NUMBER.getCode());
        }
        if(topicIndicatorPO.getRateValueDigit() == null){
            topicIndicatorPO.setRateValueDigit(2);
        }
        if(topicIndicatorPO.getRateValueType() == null){
            topicIndicatorPO.setRateValueType(DataTypeEnum.NUMBER.getCode());
        }
        if(topicIndicatorPO.getRateValueUnit() == null){
            topicIndicatorPO.setRateValueUnit(DataUnitEnum.PERCENT.getCode());
        }
    }
}
