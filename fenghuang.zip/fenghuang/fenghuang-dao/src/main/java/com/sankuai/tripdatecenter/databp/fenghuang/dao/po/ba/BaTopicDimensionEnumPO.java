package com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ba;

import java.util.Date;
import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class BaTopicDimensionEnumPO {
    /**
     * 自增主键
     */
    private Long id;

    /**
     * 维度 id
     */
    private String dimensionId;

    /**
     * 报表 id
     */
    private Long reportId;

    /**
     * 主题 id
     */
    private Long topicId;

    /**
     * 维值code
     */
    private String dimensionEnumCode;

    /**
     * 维值name
     */
    private String dimensionEnumName;

    /**
     * 是否存在级联关系
     */
    private Short hasRelation;

    /**
     * 排序
     */
    private Integer orderNum;

    /**
     * 是否删除。0为未删除，1为删除
     */
    private Short isDelete;

    /**
     * 编辑人
     */
    private String createdMis;

    /**
     * 最新编辑人
     */
    private String lastUpdateMis;

    /**
     * 创建时间
     */
    private Date createdTime;

    /**
     * 最后修改时间
     */
    private Date updateTime;
}