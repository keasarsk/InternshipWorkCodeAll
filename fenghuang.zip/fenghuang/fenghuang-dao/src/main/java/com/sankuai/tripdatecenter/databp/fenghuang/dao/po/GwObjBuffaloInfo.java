package com.sankuai.tripdatecenter.databp.fenghuang.dao.po;

import java.util.Date;
import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class GwObjBuffaloInfo {
    /**
     * 主键ID
     */
    private Long id;

    /**
     * buffaloAPI domainCode
     */
    private String domainCode;

    /**
     * buffaloAPI名称
     */
    private String apiName;

    /**
     * buffaloAPI描述
     */
    private String apiDesc;

    /**
     * 创建人 misid
     */
    private String createUser;

    /**
     * 创建人姓名
     */
    private String createUserName;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 修改人misid 
     */
    private String lastModifier;

    /**
     * 修改人名称
     */
    private String lastModifierName;

    /**
     * 修改时间
     */
    private Date lastModifyTime;

    /**
     * 是否已删除。 0-正常
     */
    private Long isDeleted;

    /**
     * 慢查询标志
     */
    private Integer slowTag;
}