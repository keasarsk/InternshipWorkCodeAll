package com.sankuai.tripdatecenter.databp.fenghuang.dao.ba;

import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ba.BaModulePO;

import java.util.List;

/**
 * description
 *
 * @author mayuzhe@meituan.com
 * @date 2023/2/28
 */
public interface BaModuleDao {
    List<BaModulePO> selectListByTopicId(Long topicId);

    int selectMaxOrder(Long topicId);

    int insertModule(BaModulePO baModulePO);

    int updateByIdAndVersion(BaModulePO baModulePO);

    void batchUpdateOrder(List<BaModulePO> baModulePOS);
}
