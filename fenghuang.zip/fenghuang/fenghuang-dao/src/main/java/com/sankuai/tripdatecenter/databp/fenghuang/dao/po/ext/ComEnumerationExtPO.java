package com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ext;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class ComEnumerationExtPO {
    /**
     * 自增主键
     */
    private Long id;

    /**
     * 维度id
     */
    private String dimensionId;

    /**
     * 维度名称
     */
    private String dimensionName;

    /**
     * 枚举id
     */
    private String measureId;

    /**
     * 枚举名称
     */
    private String measureName;

    /**
     * 父维度id
     */
    private String fatherDimensionId;

    /**
     * 父枚举id
     */
    private String fatherMeasureId;

    /**
     * 其他说明
     */
    private String extraInfo;
}