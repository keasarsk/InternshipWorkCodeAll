package com.sankuai.tripdatecenter.databp.fenghuang.dao;

import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.DatasourcePO;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.example.DatasourcePOExample;

import java.util.List;

/**
 * Description:
 *
 * @author mayuzhe@meituan.com
 * @date 2022/4/11
 */
public interface DatasourceDAO {
    /**
     * 查询数据源里诶包
     *
     * @return
     */
    List<DatasourcePO> selectDsnList(String businessId);

    /**
     * 根据 id 查询
     *
     * @param dsnId
     * @return
     */
    DatasourcePO selectByDsnId(long dsnId, String businessId);

    /**
     * 创建数据源
     *
     * @param datasourcePO 数据
     * @return
     */
    void insertDsn(DatasourcePO datasourcePO, String businessId);

    /**
     * 修改数据
     *
     * @param dsnId 数据源 id
     * @param datasourcePO 数据
     * @return
     */
    DatasourcePO updateDsn(long dsnId, DatasourcePO datasourcePO, String businessId);

    /**
     * 删除数据源
     *
     * @param dsnId
     * @return
     */
    void deleteByDsnId(long dsnId, String businessId);

    /**
     * 判断数据源是否存在
     * @param datasourcePO
     * @return
     */
    boolean isExisted(DatasourcePO datasourcePO, String businessId);
}
