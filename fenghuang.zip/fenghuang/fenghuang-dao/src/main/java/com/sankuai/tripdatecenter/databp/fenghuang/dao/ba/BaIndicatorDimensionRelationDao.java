package com.sankuai.tripdatecenter.databp.fenghuang.dao.ba;


import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ba.BaRelationIndicatorDimensionPO;

import java.util.List;

/**
 * Description:
 *
 * @author mayuzhe@meituan.com
 * @date 2023/3/2
 */
public interface BaIndicatorDimensionRelationDao {
    /**
     * 根据主题删除指标维度关系
     *
     * @param reportId
     * @param topicId
     * @param dimensionId
     * @return
     */
    int deleteRelationByTopicId(Long reportId, Long topicId, String dimensionId);

    int insertRelations(List<BaRelationIndicatorDimensionPO> baRelationIndicatorDimensionPOS);

    List<BaRelationIndicatorDimensionPO> selectListById(Long reportId, Long topicId, String dimensionId);

    /**
     * 获取主题下所有指标维度枚举关系
     * @param topicId
     * @return
     */
    List<BaRelationIndicatorDimensionPO> selectListByTopicId(Long topicId);

}
