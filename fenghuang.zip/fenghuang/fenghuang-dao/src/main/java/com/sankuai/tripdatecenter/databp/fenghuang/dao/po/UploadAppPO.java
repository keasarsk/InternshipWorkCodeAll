package com.sankuai.tripdatecenter.databp.fenghuang.dao.po;

import java.util.Date;
import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class UploadAppPO {
    private Long id;

    /**
     * 应用名称
     */
    private String appName;

    /**
     * 应用用途
     */
    private String appUse;

    /**
     * 删除状态
     */
    private Long isDelete;

    /**
     * 创建人mis
     */
    private String createMis;

    /**
     * 创建人姓名
     */
    private String createName;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新人mis
     */
    private String lastUpdateMis;

    /**
     * 更新人名称
     */
    private String lastUpdateName;

    /**
     * 更新时间
     */
    private Date lastUpdateTime;

    private String businessId;

    /**
     * 是否在线
     */
    private Integer isOnline;
}