package com.sankuai.tripdatecenter.databp.fenghuang.dao;

import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ext.TopicDimensionExtPO;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.TopicDimensionPO;

import java.util.List;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2022/4/21 3:25 下午
 */
public interface DimensionBizDao {
    /**
     * 根据 reportId,topicId,version 查询多条数据。
     *
     * @param reportId
     * @param topicId
     * @param version
     * @return
     */
    List<TopicDimensionExtPO> selectList(Long reportId, Long topicId, Long version);

    /**
     * 根据 reportId,topicId,version 查询多条数据。
     *
     * @param reportId
     * @param topicId
     * @param version
     * @return
     */
    List<TopicDimensionExtPO> selectDimensionEnumList(Long reportId, Long topicId, String dimensionId, Long version);

    /**
     * 查询维度最新排序值
     *
     * @param reportId
     * @param topicId
     * @param version
     * @return
     */
    int selectMaxOrder(Long reportId, Long topicId, Long version);

    /**
     * 插入维度与主题关系
     *
     * @param topicDimensionPO
     */
    int insertTopicDimension(TopicDimensionPO topicDimensionPO);

    /**
     * 批量插入维度与主题关系
     *
     * @param topicDimensionPOS
     */
    int batchInsertTopicDimension(List<TopicDimensionPO> topicDimensionPOS);

    /**
     * 根据维度 id 更新数据
     *
     * @param topicDimensionPO
     * @return
     */
    int updateTopicDimensionById(TopicDimensionPO topicDimensionPO);

    /**
     * 批量更新
     *
     * @param topicDimensionPOS
     * @return
     */
    void batchUpdateTopicDimensionOrder(List<TopicDimensionPO> topicDimensionPOS);

    List<TopicDimensionPO> selectDimensionById(String dimensionId, String businessId);

    /**
     * 根据topicId 删除维度与主题关系
     * @param reportId
     * @param topicId
     * @param version
     * @return
     */
    int deleteByTopicId(Long reportId, Long topicId, Long version);

}
