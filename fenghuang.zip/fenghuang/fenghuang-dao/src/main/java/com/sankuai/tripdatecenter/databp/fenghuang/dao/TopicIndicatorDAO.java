package com.sankuai.tripdatecenter.databp.fenghuang.dao;


import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.TopicIndicatorPO;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ext.TopicIndicatorExtPO;

import java.util.List;

/**
 * Description:
 *
 * @author mayuzhe@meituan.com
 * @date 2022/4/20
 */
public interface TopicIndicatorDAO {
    /**
     * 指标下线
     *
     * @param curId 节点 id
     */
    void offlineIndicator(long curId);

    /**
     * 删除模块下全部指标
     *
     * @param reportId 报表 id
     * @param version  报表 version
     * @param moduleId   模块 id
     */
    void deleteModuleIndicators(long reportId, long version, long moduleId);

    /**
     * 指标删除
     *
     * @param curId 节点 id
     */
    void deleteIndicator(long curId);

    /**
     * 添加指标
     *
     * @param topicIndicatorPO 数据
     * @return
     */
    void insertIndicator(TopicIndicatorPO topicIndicatorPO);

    /**
     * 指标修改
     *
     * @param topicIndicatorPO
     */
    void updateIndicator(TopicIndicatorPO topicIndicatorPO);

    /**
     * 查询指标列表
     *
     * @param reportId 指标 id
     * @param version 版本
     * @param moduleId
     * @return
     */
    List<TopicIndicatorPO> selectIndicators(long reportId, long version, long moduleId);

    /**
     * 查询主题下的指标
     *
     * @param reportId
     * @param version
     * @param topicId
     * @param indicatorId
     * @return
     */
    List<TopicIndicatorPO> selectIndicatorsByTopic(long reportId, long version,long topicId, String indicatorId);

    /**
     * 查询指标列表
     *
     * @param moduleId 模块 id
     * @return
     */
    List<TopicIndicatorExtPO> selectIndicatorsByModuleId(Long reportId, Long version, Long moduleId);

    List<TopicIndicatorPO> selectIndicatorById(String indicatorId);

    /**
     * 检查主题指标重复性
     * @param version
     * @param topicId
     * @param version
     * @return
     */
    List<String> checkTopicIndicatorDuplicate(Long report, Long topicId, Long version);

    /**
     * 批量插入指标、主题信息
     * @param topicIndicatorPOs
     * @return
     */
    int batchInsertTopicIndicators(List<TopicIndicatorPO> topicIndicatorPOs);

    /**
     * 根据topicId 删除维度与主题关系
     * @param reportId
     * @param topicId
     * @param version
     * @return
     */
    int deleteByTopicId(Long reportId, Long topicId, Long version);
}
