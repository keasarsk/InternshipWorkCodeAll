package com.sankuai.tripdatecenter.databp.fenghuang.dao.ba;

import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ba.BaMultiEnumPO;

import java.util.List;

/**
 * Description:
 *
 * @author mayuzhe@meituan.com
 * @date 2023/3/2
 */
public interface BaMultiEnumDAO {
    List<BaMultiEnumPO> getMultiEnumListByMultiType(String multiConfigType);
}
