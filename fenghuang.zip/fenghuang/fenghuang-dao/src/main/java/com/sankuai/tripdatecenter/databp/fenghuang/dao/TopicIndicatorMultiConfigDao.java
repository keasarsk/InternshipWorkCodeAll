package com.sankuai.tripdatecenter.databp.fenghuang.dao;

import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.TopicIndicatorMultiConfigPO;

import java.util.List;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2023/5/25 15:11
 */
public interface TopicIndicatorMultiConfigDao {
    /**
     * 删除模块下全部指标多选配置
     *
     * @param moduleId    模块id
     * @param indicatorId 指标id
     * @param multiType   配置类型
     */
    void deleteConfigs(long moduleId, String indicatorId, String multiType);

    /**
     * 添加多选配置
     *
     * @param multiConfigPO 数据
     * @return
     */
    void insertConfig(TopicIndicatorMultiConfigPO multiConfigPO);

    void batchInsertConfig(List<TopicIndicatorMultiConfigPO> multiConfigPOS);

    /**
     * 删除指标多选配置
     *
     * @param moduleId
     * @param indicatorId
     */
    void deleteIndicator(long moduleId, String indicatorId);

    List<TopicIndicatorMultiConfigPO> getIndicatorMultiConfig(long moduleId, String indicatorId, String multiType);

}
