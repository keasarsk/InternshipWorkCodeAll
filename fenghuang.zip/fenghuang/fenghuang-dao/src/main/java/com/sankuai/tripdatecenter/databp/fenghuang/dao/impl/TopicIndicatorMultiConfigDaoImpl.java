package com.sankuai.tripdatecenter.databp.fenghuang.dao.impl;

import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.TimeUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.WutongUserUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.TopicIndicatorMultiConfigDao;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.mapper.auto.TopicIndicatorMultiConfigPOMapper;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.TopicIndicatorMultiConfigPO;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.example.TopicIndicatorMultiConfigPOExample;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.Date;
import java.util.List;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2023/5/25 15:12
 */
@Repository
public class TopicIndicatorMultiConfigDaoImpl implements TopicIndicatorMultiConfigDao {

    @Resource
    private TopicIndicatorMultiConfigPOMapper topicIndicatorMultiConfigPOMapper;

    @Override
    public void deleteConfigs(long moduleId, String indicatorId, String multiType) {
        TopicIndicatorMultiConfigPOExample example = this.createCommonExample();
        example.getOredCriteria().get(0)
                .andModuleIdEqualTo(moduleId)
                .andIndicatorIdEqualTo(indicatorId)
                .andMultiConfigTypeEqualTo(multiType);
        topicIndicatorMultiConfigPOMapper.deleteByExample(example);
    }

    @Override
    public void insertConfig(TopicIndicatorMultiConfigPO multiConfigPO) {
        this.setDefaultValue(multiConfigPO);
        topicIndicatorMultiConfigPOMapper.insertSelective(multiConfigPO);
    }

    @Override
    public void batchInsertConfig(List<TopicIndicatorMultiConfigPO> multiConfigPOS) {
        if(CollectionUtils.isEmpty(multiConfigPOS)){
            return;
        }
        multiConfigPOS.stream().forEach(multiConfig->{
            insertConfig(multiConfig);
        });
    }

    @Override
    public void deleteIndicator(long moduleId, String indicatorId) {
        TopicIndicatorMultiConfigPOExample example = this.createCommonExample();
        example.getOredCriteria().get(0)
                .andModuleIdEqualTo(moduleId)
                .andIndicatorIdEqualTo(indicatorId);
        topicIndicatorMultiConfigPOMapper.deleteByExample(example);
    }

    @Override
    public List<TopicIndicatorMultiConfigPO> getIndicatorMultiConfig(long moduleId, String indicatorId, String multiType) {
        TopicIndicatorMultiConfigPOExample example = this.createCommonExample();
        example.getOredCriteria().get(0)
                .andModuleIdEqualTo(moduleId)
                .andIndicatorIdEqualTo(indicatorId)
                .andMultiConfigTypeEqualTo(multiType);
        List<TopicIndicatorMultiConfigPO> configPOS = topicIndicatorMultiConfigPOMapper.selectByExample(example);
        if(configPOS == null){
            return Collections.EMPTY_LIST;
        }
        return configPOS;
    }

    /**
     * 创建公共 example
     *
     * @return
     */
    private TopicIndicatorMultiConfigPOExample createCommonExample() {
        TopicIndicatorMultiConfigPOExample example = new TopicIndicatorMultiConfigPOExample();
        TopicIndicatorMultiConfigPOExample.Criteria criteria = example.createCriteria();
        criteria.andIsDeleteEqualTo((short) 0);
        example.setOrderByClause("order_num asc");
        return example;
    }

    private void setDefaultValue(TopicIndicatorMultiConfigPO multiConfigPO) {
        Date curDate = TimeUtils.getCurrentJavaDate();
        String mis = WutongUserUtils.getFhUserInfo().getMisId();
        multiConfigPO.setCreatedMis(mis);
        multiConfigPO.setLastUpdateMis(mis);
        multiConfigPO.setUpdateTime(curDate);
        multiConfigPO.setCreatedTime(curDate);
        multiConfigPO.setIsDelete((short) 0);
    }
}
