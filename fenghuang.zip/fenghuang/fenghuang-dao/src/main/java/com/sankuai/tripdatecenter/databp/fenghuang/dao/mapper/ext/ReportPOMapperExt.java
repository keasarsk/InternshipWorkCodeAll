package com.sankuai.tripdatecenter.databp.fenghuang.dao.mapper.ext;

import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ReportPO;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.example.ReportPOExample;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ext.ReportParamPO;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * description 报表相关Mapper
 *
 * @author nixuefeng
 * @createTime 2022/4/19 8:04 下午
 */
public interface ReportPOMapperExt {
    Long selectMaxReportVersion(@Param("reportId") Long reportId, @Param("businessId")String businessId);

    List<ReportPO> select4List(ReportParamPO param);

}
