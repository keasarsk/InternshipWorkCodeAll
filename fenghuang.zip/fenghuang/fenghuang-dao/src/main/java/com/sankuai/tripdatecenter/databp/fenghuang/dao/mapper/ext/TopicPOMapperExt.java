package com.sankuai.tripdatecenter.databp.fenghuang.dao.mapper.ext;

import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.TopicPO;
import io.swagger.models.auth.In;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * description 报表相关Mapper
 *
 * @author nixuefeng
 * @createTime 2022/4/19 8:04 下午
 */
public interface TopicPOMapperExt {
    Integer selectMaxOrderNum(@Param("reportId") Long reportId, @Param("version") Long version);

    void batchUpdateTopicOrderBatch(@Param("topics") List<TopicPO> topics);

}
