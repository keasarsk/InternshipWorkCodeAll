package com.sankuai.tripdatecenter.databp.fenghuang.dao.mapper.ext;

import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.TemplatePO;
import org.apache.ibatis.annotations.Param;


/**
 * description 数据服务化相关查询
 *
 * @author fuzhengwei02
 * @createTime 2022/4/11 3:47 下午
 */
public interface TemplatePOMapperExt {

    TemplatePO getTemplateByTopicId(@Param("topicId")Long topicId);

}
