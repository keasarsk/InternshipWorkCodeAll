package com.sankuai.tripdatecenter.databp.fenghuang.dao;

import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.TopicPO;

import java.util.List;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2022/4/22 4:41 下午
 */
public interface TopicDao {
    List<TopicPO> selectListByReportId(Long reportId, Long version);

    TopicPO getTopicInfo(Long reportId, Long topicId, Long version);

    TopicPO getTopicInfo(Long topicId);

    int selectMaxOrder(Long reportId, Long version);

    int insertTopic(TopicPO topicPO);

    int updateByIdAndVersion(TopicPO topicPO);

    int updateTopicName(TopicPO topicPO);

    void batchUpdateOrder(List<TopicPO> topicPOS);
}
