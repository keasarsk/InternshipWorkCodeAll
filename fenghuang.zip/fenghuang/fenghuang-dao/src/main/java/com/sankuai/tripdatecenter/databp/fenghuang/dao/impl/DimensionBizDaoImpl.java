package com.sankuai.tripdatecenter.databp.fenghuang.dao.impl;

import com.sankuai.tripdatecenter.databp.fenghuang.common.enums.DeleteStatusEnum;
import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.TimeUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.WutongUserUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.DimensionBizDao;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.mapper.auto.TopicDimensionPOMapper;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.mapper.ext.TopicDimensionPOMapperExt;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ext.TopicDimensionExtPO;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.TopicDimensionPO;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.example.TopicDimensionPOExample;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.List;

import static com.sankuai.tripdatecenter.databp.fenghuang.common.constant.NumberConstant.ZERO;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2022/4/21 3:40 下午
 */
@Repository
@Slf4j
public class DimensionBizDaoImpl implements DimensionBizDao {
    @Resource
    private TopicDimensionPOMapper topicDimensionPOMapper;

    @Resource
    private TopicDimensionPOMapperExt topicDimensionPOMapperExt;

    @Override
    public List<TopicDimensionExtPO> selectList(Long reportId, Long topicId, Long version) {
        List<TopicDimensionExtPO> topicDimensionList = topicDimensionPOMapperExt.selectListByTopicId(reportId, topicId, version);
        if (topicDimensionList == null) {
            return Collections.EMPTY_LIST;
        }
        return topicDimensionList;
    }

    @Override
    public List<TopicDimensionExtPO> selectDimensionEnumList(Long reportId, Long topicId, String dimensionId, Long version) {
        List<TopicDimensionExtPO> dimensionEnumList =
                topicDimensionPOMapperExt.selectEnumListByTopicId(reportId, topicId, dimensionId, version);
        if (dimensionEnumList == null) {
            return Collections.EMPTY_LIST;
        }
        return dimensionEnumList;
    }

    @Override
    public int selectMaxOrder(Long reportId, Long topicId, Long version) {
        Integer orderNum = topicDimensionPOMapperExt.selectMaxOrderNum(reportId, topicId, version);
        if (orderNum == null) {
            orderNum = ZERO;
        }
        return orderNum;
    }

    @Override
    public int insertTopicDimension(TopicDimensionPO topicDimensionPO) {
        setCreateInfo(topicDimensionPO);
        return topicDimensionPOMapper.insert(topicDimensionPO);
    }

    @Override
    public int batchInsertTopicDimension(List<TopicDimensionPO> topicDimensionPOS) {
        topicDimensionPOS.stream().forEach(topicDimensionPO -> {setCreateInfo(topicDimensionPO);});
        return topicDimensionPOMapperExt.insertBatch(topicDimensionPOS);
    }

    @Override
    public int updateTopicDimensionById(TopicDimensionPO topicDimensionPO) {
        TopicDimensionPOExample example = new TopicDimensionPOExample();
        TopicDimensionPOExample.Criteria criteria = example.createCriteria();
        if (topicDimensionPO.getReportId() != null) {
            criteria.andReportIdEqualTo(topicDimensionPO.getReportId());
        }
        if (topicDimensionPO.getTopicId() != null) {
            criteria.andTopicIdEqualTo(topicDimensionPO.getTopicId());
        }
        if (topicDimensionPO.getDimensionId() != null) {
            criteria.andDimensionIdEqualTo(topicDimensionPO.getDimensionId());
        }
        if (topicDimensionPO.getVersion() != null) {
            criteria.andVersionEqualTo(topicDimensionPO.getVersion());
        }
        return topicDimensionPOMapper.updateByExampleSelective(topicDimensionPO, example);
    }

    @Override
    public void batchUpdateTopicDimensionOrder(List<TopicDimensionPO> topicDimensionPOS) {
        topicDimensionPOMapperExt.batchUpdateTopicDimensionOrder(topicDimensionPOS);
    }

    private void setCreateInfo(TopicDimensionPO topicDimensionPO) {
        topicDimensionPO.setCreatedMis(WutongUserUtils.getFhUserInfo().getMisId());
        topicDimensionPO.setCreatedTime(TimeUtils.getCurrentJavaDate());
        topicDimensionPO.setIsDelete(DeleteStatusEnum.NOT_DELETED.getCode());
        setUpdateInfo(topicDimensionPO);
    }

    private void setUpdateInfo(TopicDimensionPO topicDimensionPO) {
        topicDimensionPO.setLastUpdateMis(WutongUserUtils.getFhUserInfo().getMisId());
        topicDimensionPO.setUpdateTime(TimeUtils.getCurrentJavaDate());
    }

    @Override
    public List<TopicDimensionPO> selectDimensionById(String dimensionId, String businessId) {
        TopicDimensionPOExample example = new TopicDimensionPOExample();
        TopicDimensionPOExample.Criteria criteria = example.createCriteria();
        criteria.andIsDeleteEqualTo((short) 0)
                .andDimensionIdEqualTo(dimensionId);
        return topicDimensionPOMapper.selectByExample(example);
    }

    @Override
    public int deleteByTopicId(Long reportId, Long topicId, Long version) {
        TopicDimensionPOExample example = new TopicDimensionPOExample();
        example.createCriteria()
                .andReportIdEqualTo(reportId)
                .andTopicIdEqualTo(topicId)
                .andVersionEqualTo(version);
        return topicDimensionPOMapper.deleteByExample(example);
    }
}
