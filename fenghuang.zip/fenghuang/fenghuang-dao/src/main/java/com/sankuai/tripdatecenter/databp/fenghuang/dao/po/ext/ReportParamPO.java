package com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ext;

import lombok.Data;
import lombok.ToString;

import java.util.Date;

@Data
@ToString
public class ReportParamPO {

    /**
     * 报表 id
     */
    private Long reportId;

    /**
     * 版本号。格式 yyyyMMddHHmmss
     */
    private Long version;

    /**
     * 报表类型，1：wbr配置化报表，2：定制化报表
     */
    private Short reportType;

    /**
     * 报表名称
     */
    private String reportName;


    /**
     * 是否在线。0为下线，1为在线
     */
    private Short isOnline;

    /**
     * 是否删除。0为未删除，1为删除
     */
    private Short isDelete;

    /**
     * 编辑人
     */
    private String createdMis;

    /**
     * 业务线ID
     */
    private String businessId;

    /**
     * 协助管理员
     */
    private String relatedMis;

}