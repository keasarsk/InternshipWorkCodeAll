package com.sankuai.tripdatecenter.databp.fenghuang.dao.impl;

import com.sankuai.tripdatecenter.databp.fenghuang.common.enums.DeleteStatusEnum;
import com.sankuai.tripdatecenter.databp.fenghuang.common.enums.OnlineStatusEnum;
import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.FhIdUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.TimeUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.WutongUserUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.TopicDao;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.mapper.auto.TopicPOMapper;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.mapper.ext.TopicPOMapperExt;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.TopicPO;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.example.TopicPOExample;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.List;

import static com.sankuai.tripdatecenter.databp.fenghuang.common.constant.BizConstant.ORDER_STR;
import static com.sankuai.tripdatecenter.databp.fenghuang.common.constant.NumberConstant.ONE;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2022/4/22 4:46 下午
 */
@Repository
public class TopicDaoImpl implements TopicDao {
    @Resource
    private TopicPOMapper topicPOMapper;

    @Resource
    private TopicPOMapperExt topicPOMapperExt;

    @Override
    public List<TopicPO> selectListByReportId(Long reportId, Long version) {
        TopicPOExample example = new TopicPOExample();
        example.createCriteria()
                .andReportIdEqualTo(reportId)
                .andVersionEqualTo(version)
                .andIsDeleteEqualTo(DeleteStatusEnum.NOT_DELETED.getCode());
        example.setOrderByClause(ORDER_STR);
        List<TopicPO> topicPOS = topicPOMapper.selectByExample(example);
        if (topicPOS == null) {
            topicPOS = Collections.EMPTY_LIST;
        }
        return topicPOS;
    }

    @Override
    public TopicPO getTopicInfo(Long reportId, Long topicId, Long version) {
        TopicPOExample example = new TopicPOExample();
        example.createCriteria()
                .andReportIdEqualTo(reportId)
                .andTopicIdEqualTo(topicId)
                .andVersionEqualTo(version)
                .andIsDeleteEqualTo(DeleteStatusEnum.NOT_DELETED.getCode());
        List<TopicPO> topicPOS = topicPOMapper.selectByExample(example);
        if (CollectionUtils.isEmpty(topicPOS)){
           return null;
        }
        return topicPOS.get(0);
    }

    @Override
    public TopicPO getTopicInfo(Long topicId) {
        TopicPOExample example = new TopicPOExample();
        example.createCriteria()
                .andTopicIdEqualTo(topicId)
                .andVersionEqualTo(1l)
                .andIsDeleteEqualTo(DeleteStatusEnum.NOT_DELETED.getCode());
        List<TopicPO> topicPOS = topicPOMapper.selectByExample(example);
        if (CollectionUtils.isEmpty(topicPOS)){
            return null;
        }
        return topicPOS.get(0);
    }

    @Override
    public int selectMaxOrder(Long reportId, Long version) {
        Integer orderNum = topicPOMapperExt.selectMaxOrderNum(reportId, version);
        if (orderNum == null) {
            orderNum = ONE;
        }
        return orderNum;
    }

    @Override
    public int insertTopic(TopicPO topicPO) {
        setCreateInfo(topicPO);
        return topicPOMapper.insert(topicPO);
    }

    @Override
    public int updateByIdAndVersion(TopicPO topicPO) {
        setUpdateInfo(topicPO);
        TopicPOExample example = new TopicPOExample();
        TopicPOExample.Criteria criteria = example.createCriteria();
        if(topicPO.getReportId() != null){
            criteria.andReportIdEqualTo(topicPO.getReportId());
        }
        if(topicPO.getTopicId() != null){
            criteria.andTopicIdEqualTo(topicPO.getTopicId());
        }
        if (topicPO.getVersion() != null) {
            criteria.andVersionEqualTo(topicPO.getVersion());
        }
        if (topicPO.getBusinessId() != null) {
            criteria.andBusinessIdEqualTo(topicPO.getBusinessId());
        }
        return topicPOMapper.updateByExampleSelective(topicPO, example);
    }

    @Override
    public int updateTopicName(TopicPO topicPO) {
        setUpdateInfo(topicPO);
        TopicPOExample example = new TopicPOExample();
        TopicPOExample.Criteria criteria = example.createCriteria();
        criteria.andReportIdEqualTo(topicPO.getReportId());
        criteria.andTopicIdEqualTo(topicPO.getTopicId());
        criteria.andVersionEqualTo(topicPO.getVersion());
        criteria.andBusinessIdEqualTo(topicPO.getBusinessId());
        return topicPOMapper.updateByExampleSelective(topicPO, example);
    }

    @Override
    public void batchUpdateOrder(List<TopicPO> topicPOS) {
        topicPOMapperExt.batchUpdateTopicOrderBatch(topicPOS);
    }

    private void setUpdateInfo(TopicPO topicPO) {
        topicPO.setUpdateTime(TimeUtils.getCurrentJavaDate());
        topicPO.setLastUpdateMis(WutongUserUtils.getUser());
    }

    private void setCreateInfo(TopicPO topicPO) {
        topicPO.setCreatedTime(TimeUtils.getCurrentJavaDate());
        topicPO.setCreatedMis(WutongUserUtils.getUser());
        topicPO.setTopicId(FhIdUtils.genFhUnifiedId());
        topicPO.setIsOnline(OnlineStatusEnum.OFFLINE.getCode());
        topicPO.setIsDelete(DeleteStatusEnum.NOT_DELETED.getCode());
        setUpdateInfo(topicPO);
    }
}
