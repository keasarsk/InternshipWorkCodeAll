package com.sankuai.tripdatecenter.databp.fenghuang.dao;

import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ext.ComEnumerationExtPO;

import java.util.List;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2022/11/21 15:42
 */
public interface EnumDimDao {
    /**
     * 根据dimensionId获取维度枚举值
     *
     * @param dimensionIds
     * @return
     */
    List<ComEnumerationExtPO> getEnumDimList(List<String> dimensionIds);
}
