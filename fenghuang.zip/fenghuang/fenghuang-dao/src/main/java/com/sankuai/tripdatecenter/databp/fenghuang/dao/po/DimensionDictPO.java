package com.sankuai.tripdatecenter.databp.fenghuang.dao.po;

import java.util.Date;
import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class DimensionDictPO {
    /**
     * 自增ID
     */
    private Long id;

    /**
     * 统一维度ID
     */
    private String dimensionId;

    /**
     * 维值code
     */
    private String dimensionCode;

    /**
     * 维值对应名称
     */
    private String dimensionName;

    /**
     * 维值描述
     */
    private String dimensionDesc;

    /**
     * 显示排序
     */
    private Integer orderSeq;

    /**
     * 删除状态
     */
    private Long isDelete;

    /**
     * 创建人
     */
    private String createdMis;

    /**
     * 删除人
     */
    private String lastUpdateMis;

    /**
     * 创建时间
     */
    private Date createdTime;

    /**
     * 删除时间
     */
    private Date updateTime;
}