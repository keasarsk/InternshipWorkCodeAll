package com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ext;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class TravelDimBdExtPO {

    private Integer regionId;

    private String region;

    private Integer subRegionId;

    private String subRegion;

    private Integer groupId;

    private Integer bdId;

    private String bdName;

    private String login;

}