package com.sankuai.tripdatecenter.databp.fenghuang.dao.impl;

import com.sankuai.tripdatecenter.databp.fenghuang.common.enums.DeleteStatusEnum;
import com.sankuai.tripdatecenter.databp.fenghuang.common.enums.OnlineStatusEnum;
import com.sankuai.tripdatecenter.databp.fenghuang.common.enums.ReportTypeEnum;
import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.TimeUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.WutongUserUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.ReportDao;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.mapper.auto.ReportPOMapper;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.mapper.ext.ReportPOMapperExt;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ReportPO;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.example.ReportPOExample;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ext.ReportParamPO;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.List;

import static com.sankuai.tripdatecenter.databp.fenghuang.common.constant.NumberConstant.ZERO;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2022/4/22 3:10 下午
 */
@Repository
public class ReportDaoImpl implements ReportDao {

    @Resource
    private ReportPOMapper reportPOMapper;

    @Resource
    private ReportPOMapperExt reportPOMapperExt;

    @Override
    public List<ReportPO> selectList(ReportParamPO param) {
        return reportPOMapperExt.select4List(param);
    }

    @Override
    public Long selectMaxVersion(Long reportId, String businessId) {
        Long version = reportPOMapperExt.selectMaxReportVersion(reportId, businessId);
        if(version == null){
            version = (long)ZERO;
        }
        return version;
    }

    @Override
    public int insertReport(ReportPO reportPO) {
        setCreateInfo(reportPO);
        return reportPOMapper.insertSelective(reportPO);
    }

    @Override
    public int updateByIdAndVersion(ReportPO reportPO) {
        setUpdateInfo(reportPO);
        ReportPOExample example = new ReportPOExample();
        ReportPOExample.Criteria criteria = example.createCriteria();
        criteria.andReportIdEqualTo(reportPO.getReportId());
        if(reportPO.getVersion() != null){
            criteria.andVersionEqualTo(reportPO.getVersion());
        }
        if(null != reportPO.getBusinessId()){
            criteria.andBusinessIdEqualTo(reportPO.getBusinessId());
        }
        criteria.andIsDeleteEqualTo(DeleteStatusEnum.NOT_DELETED.getCode());
        return reportPOMapper.updateByExampleSelective(reportPO, example);
    }

    @Override
    public Long getOnlineVersion(Long reportId) {
        ReportPOExample example = new ReportPOExample();
        ReportPOExample.Criteria criteria = example.createCriteria();
        criteria.andIsDeleteEqualTo(DeleteStatusEnum.NOT_DELETED.getCode());
        criteria.andReportIdEqualTo(reportId);
        criteria.andIsOnlineEqualTo(OnlineStatusEnum.ONLINE.getCode());
        List<ReportPO> reportPOS = reportPOMapper.selectByExample(example);
        if(CollectionUtils.isEmpty(reportPOS)){
            return null;
        }else if(reportPOS.size() > 1){
            throw new RuntimeException("online version should be only 1. reportId : " + reportId);
        }else {
            return reportPOS.get(0).getVersion();
        }
    }

    @Override
    public String getBusinessIdByReportId(Long reportId, Long version) {
        ReportPOExample example = new ReportPOExample();
        ReportPOExample.Criteria criteria = example.createCriteria();
        criteria.andIsDeleteEqualTo(DeleteStatusEnum.NOT_DELETED.getCode());
        criteria.andReportIdEqualTo(reportId);
        List<ReportPO> reportPOS = reportPOMapper.selectByExample(example);
        if(CollectionUtils.isEmpty(reportPOS)){
            return null;
        }else if(reportPOS.size() > 1){
            throw new RuntimeException("report version should be only 1. reportId : " + reportId + ", verison: " + version);
        }else {
            return reportPOS.get(0).getBusinessId();
        }
    }

    private void setCreateInfo(ReportPO reportPO){
        reportPO.setIsOnline(OnlineStatusEnum.OFFLINE.getCode());
        reportPO.setCreatedMis(WutongUserUtils.getUser());
        reportPO.setCreatedTime(TimeUtils.getCurrentJavaDate());
        reportPO.setIsDelete(DeleteStatusEnum.NOT_DELETED.getCode());
        reportPO.setReportType(ReportTypeEnum.CONFIGURATION.getCode());
        setUpdateInfo(reportPO);
    }

    private void setUpdateInfo(ReportPO reportPO){
        reportPO.setUpdateTime(TimeUtils.getCurrentJavaDate());
        reportPO.setLastUpdateMis(WutongUserUtils.getUser());
    }
}
