package com.sankuai.tripdatecenter.databp.fenghuang.dao.ba;

import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ba.BaTopicIndicatorMultiConfigPO;

import java.util.List;

/**
 * Description:
 *
 * @author mayuzhe@meituan.com
 * @date 2023/3/1
 */
public interface BaTopicIndicatorMultiConfigDAO {
    /**
     * 删除模块下全部指标多选配置
     *
     * @param moduleId    模块id
     * @param indicatorId 指标id
     * @param multiType   配置类型
     */
    void deleteConfigs(long moduleId, String indicatorId, String multiType);

    /**
     * 添加多选配置
     *
     * @param multiConfigPO 数据
     * @return
     */
    void insertConfig(BaTopicIndicatorMultiConfigPO multiConfigPO);

    /**
     * 删除指标多选配置
     *
     * @param moduleId
     * @param indicatorId
     */
    void deleteIndicator(long moduleId, String indicatorId);

    List<BaTopicIndicatorMultiConfigPO> getIndicatorMultiConfig(long moduleId, String indicatorId, String multiType);
}
