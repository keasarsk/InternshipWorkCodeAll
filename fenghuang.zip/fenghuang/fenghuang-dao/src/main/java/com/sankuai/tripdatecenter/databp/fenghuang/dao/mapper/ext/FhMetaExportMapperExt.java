package com.sankuai.tripdatecenter.databp.fenghuang.dao.mapper.ext;

import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ext.IndicatorRelatedAppExtPO;
import java.util.List;
import org.apache.ibatis.annotations.Param;

/**
 * description
 *
 * @author fuzhengwei02
 * @createTime 2022/12/19 14:30
 */
public interface FhMetaExportMapperExt {

    List<IndicatorRelatedAppExtPO> getIndicatorRelatedApp(@Param("indicatorCodes") List<String> indicatorCodes);
}
