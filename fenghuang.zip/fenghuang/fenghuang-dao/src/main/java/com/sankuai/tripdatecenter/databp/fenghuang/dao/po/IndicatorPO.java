package com.sankuai.tripdatecenter.databp.fenghuang.dao.po;

import java.util.Date;
import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class IndicatorPO {
    /**
     * 自增主键
     */
    private Long id;

    /**
     * 指标 id。指标 code + appType。
     */
    private String indicatorId;

    /**
     * 版本号。格式 yyyyMMddHHmmss
     */
    private Long version;

    /**
     * 应用 id
     */
    private Long appId;

    /**
     * 应用类型。起源1，临时应用2。
     */
    private String appType;

    /**
     * 指标 code
     */
    private String indicatorCode;

    /**
     * 指标名
     */
    private String indicatorName;

    /**
     * 指标类型
     */
    private String indicatorType;

    /**
     * 起源指标id
     */
    private Long orgIndicatorId;

    /**
     * 聚合方式
     */
    private String aggregateFunction;

    /**
     * 指标注释
     */
    private String indicatorComment;

    /**
     * 是否删除。0为未删除，1为删除
     */
    private Short isDelete;

    /**
     * 编辑人
     */
    private String createdMis;

    /**
     * 最新编辑人
     */
    private String lastUpdateMis;

    /**
     * 创建时间
     */
    private Date createdTime;

    /**
     * 最后修改时间
     */
    private Date updateTime;

    /**
     * 指标单位
     */
    private String indicatorUnit;

    /**
     * 业务线ID
     */
    private String businessId;
}