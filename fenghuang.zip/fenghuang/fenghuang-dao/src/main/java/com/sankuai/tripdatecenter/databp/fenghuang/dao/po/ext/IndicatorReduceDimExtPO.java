package com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ext;

import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.DimReduceDimEnumPO;
import lombok.Data;
import lombok.ToString;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2023/5/26 14:56
 */
@Data
@ToString
public class IndicatorReduceDimExtPO extends DimReduceDimEnumPO {
    /**
     * 维度 name
     */
    private String dimensionName;

}
