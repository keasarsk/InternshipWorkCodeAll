package com.sankuai.tripdatecenter.databp.fenghuang.dao.impl;

import com.sankuai.tripdatecenter.databp.fenghuang.dao.IndicatorReduceDimDao;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.mapper.ext.DimReduceDimEnumPOMapperExt;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.mapper.ext.IndicatorReduceDimPOMapperExt;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.DimReduceDimEnumPO;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ext.IndicatorReduceDimExtPO;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.util.List;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2023/5/26 15:18
 */
@Repository
public class IndicatorReduceDimDaoImpl implements IndicatorReduceDimDao {
    @Resource
    private IndicatorReduceDimPOMapperExt indicatorReduceDimPOMapperExt;

    @Resource
    private DimReduceDimEnumPOMapperExt dimReduceDimEnumPOMapperExt;

    @Override
    public List<IndicatorReduceDimExtPO> getReduceDimByIndicatorId(Long topicId, String indicatorId) {
        return indicatorReduceDimPOMapperExt.selectReduceDimByIndicator(topicId, indicatorId);
    }

    @Override
    public List<IndicatorReduceDimExtPO> getReduceDimByTopicId(Long topicId) {
        return indicatorReduceDimPOMapperExt.selectReduceDimByTopicId(topicId);
    }

    @Override
    public int deleteDimReduceByIndicator(Long reportId, Long topicId, String indicatorId, Long version) {
        return dimReduceDimEnumPOMapperExt.deleteTopicIndicatorDimReduce(reportId, topicId, version, indicatorId);
    }

    @Override
    public int batchSaveReduceDimEnums(List<DimReduceDimEnumPO> dimReduceDimEnumPOS) {
        if(CollectionUtils.isEmpty(dimReduceDimEnumPOS)){
            return 0;
        }
        return indicatorReduceDimPOMapperExt.batchSaveReduceDimEnums(dimReduceDimEnumPOS);
    }
}
