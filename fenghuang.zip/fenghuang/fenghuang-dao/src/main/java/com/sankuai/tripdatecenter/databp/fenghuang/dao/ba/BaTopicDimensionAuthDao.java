package com.sankuai.tripdatecenter.databp.fenghuang.dao.ba;

import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ba.BaTopicDimensionAuthPO;

import java.util.List;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2023/5/16 17:48
 */
public interface BaTopicDimensionAuthDao {
    /**
     * 插入维度权限信息
     * @param baTopicDimensionAuthPOList
     * @return
     */
    int insertBaTopicDimensionAuthPO(List<BaTopicDimensionAuthPO> baTopicDimensionAuthPOList);

    /**
     * 删除主题下维度权限信息
     * @param topicId
     * @return
     */
    int deleteBaTopicDimensionAuthByTopicId(Long topicId);

    /**
     * 查询主题下维度权限信息
     * @param topicId
     * @return
     */
    List<BaTopicDimensionAuthPO> selectBaTopicDimensionAuthByTopicId(Long topicId);

    /**
     * 根据topicId 和 dimensionId 获取维度权限配置
     * @param topicId
     * @param dimensionId
     * @return
     */
    BaTopicDimensionAuthPO selectByTopicIdAndDimensionId(Long topicId,String dimensionId);
}
