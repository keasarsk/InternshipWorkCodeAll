package com.sankuai.tripdatecenter.databp.fenghuang.dao.impl;

import com.sankuai.tripdatecenter.databp.fenghuang.dao.EnumDimDao;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.mapper.ext.ComEnumerationPOMapperExt;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ext.ComEnumerationExtPO;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.List;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2022/11/21 15:47
 */
@Repository
public class EnumDimDaoImpl implements EnumDimDao {
    @Resource
    private ComEnumerationPOMapperExt comEnumerationPOMapper;
    @Override
    public List<ComEnumerationExtPO> getEnumDimList(List<String> dimensionIds) {
        return comEnumerationPOMapper.queryEnumByDimensionIds(dimensionIds);
    }
}
