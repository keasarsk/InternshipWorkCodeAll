package com.sankuai.tripdatecenter.databp.fenghuang.dao;

import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ReportPO;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ext.ReportParamPO;

import java.util.List;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2022/4/22 3:04 下午
 */
public interface ReportDao {
    List<ReportPO> selectList(ReportParamPO param);
    Long selectMaxVersion(Long reportId, String businessId);
    int insertReport(ReportPO reportPO);
    int updateByIdAndVersion(ReportPO reportPO);
    Long getOnlineVersion(Long reportId);
    String getBusinessIdByReportId(Long reportId, Long version);

}
