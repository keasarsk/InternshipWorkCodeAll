package com.sankuai.tripdatecenter.databp.fenghuang.dao.ba.impl;

import com.sankuai.tripdatecenter.databp.fenghuang.common.enums.DeleteStatusEnum;
import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.TimeUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.WutongUserUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.ba.BaDimensionBizDao;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.mapper.ba.auto.BaTopicDimensionPOMapper;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.mapper.ba.ext.BaTopicDimensionPOMapperExt;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ba.BaTopicDimensionPO;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ba.example.BaTopicDimensionPOExample;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ba.ext.BaTopicDimensionExtPO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.List;

import static com.sankuai.tripdatecenter.databp.fenghuang.common.constant.NumberConstant.ZERO;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2022/4/21 3:40 下午
 */
@Repository
@Slf4j
public class BaDimensionBizDaoImpl implements BaDimensionBizDao {
    @Resource
    private BaTopicDimensionPOMapper baTopicDimensionPOMapper;

    @Resource
    private BaTopicDimensionPOMapperExt baTopicDimensionPOMapperExt;

    @Override
    public List<BaTopicDimensionExtPO> selectList(Long topicId, String businessId) {
        List<BaTopicDimensionExtPO> topicDimensionList = baTopicDimensionPOMapperExt.selectListByTopicId(topicId, businessId);
        if (topicDimensionList == null) {
            return Collections.EMPTY_LIST;
        }
        return topicDimensionList;
    }

    @Override
    public List<BaTopicDimensionExtPO> selectNotRelatedList(Long topicId, String businessId) {
        List<BaTopicDimensionExtPO> topicDimensionList = baTopicDimensionPOMapperExt.selectNotRelatedList(topicId, businessId);
        if (topicDimensionList == null) {
            return Collections.EMPTY_LIST;
        }
        return topicDimensionList;
    }

    @Override
    public List<BaTopicDimensionExtPO> selectDimensionEnumList(Long topicId, String dimensionId, String businessId) {
        List<BaTopicDimensionExtPO> dimensionEnumList =
                baTopicDimensionPOMapperExt.selectEnumListByTopicId(topicId, dimensionId, businessId);
        if (dimensionEnumList == null) {
            return Collections.EMPTY_LIST;
        }
        return dimensionEnumList;
    }

    @Override
    public int selectMaxOrder( Long topicId, String businessId) {
        Integer orderNum = baTopicDimensionPOMapperExt.selectMaxOrderNum(topicId, businessId);
        if (orderNum == null) {
            orderNum = ZERO;
        }
        return orderNum;
    }

    @Override
    public int insertTopicDimension(BaTopicDimensionPO topicDimensionPO, String businessId) {
        setCreateInfo(topicDimensionPO);
        return baTopicDimensionPOMapper.insert(topicDimensionPO);
    }

    @Override
    public int batchInsertTopicDimension(List<BaTopicDimensionPO> topicDimensionPOS, String businessId) {
        topicDimensionPOS.stream().forEach(topicDimensionPO -> {setCreateInfo(topicDimensionPO);});
        return baTopicDimensionPOMapperExt.insertBatch(topicDimensionPOS);
    }

    @Override
    public int updateTopicDimensionById(BaTopicDimensionPO topicDimensionPO, String businessId) {
        BaTopicDimensionPOExample example = new BaTopicDimensionPOExample();
        BaTopicDimensionPOExample.Criteria criteria = example.createCriteria();
        if (topicDimensionPO.getReportId() != null) {
            criteria.andReportIdEqualTo(topicDimensionPO.getReportId());
        }
        if (topicDimensionPO.getTopicId() != null) {
            criteria.andTopicIdEqualTo(topicDimensionPO.getTopicId());
        }
        if (topicDimensionPO.getDimensionId() != null) {
            criteria.andDimensionIdEqualTo(topicDimensionPO.getDimensionId());
        }
        return baTopicDimensionPOMapper.updateByExampleSelective(topicDimensionPO, example);
    }

    @Override
    public void batchUpdateTopicDimensionOrder(List<BaTopicDimensionPO> topicDimensionPOS, String businessId) {
        baTopicDimensionPOMapperExt.batchUpdateTopicDimensionOrder(topicDimensionPOS, businessId);
    }

    private void setCreateInfo(BaTopicDimensionPO topicDimensionPO) {
        topicDimensionPO.setCreatedMis(WutongUserUtils.getFhUserInfo().getMisId());
        topicDimensionPO.setCreatedTime(TimeUtils.getCurrentJavaDate());
        topicDimensionPO.setIsDelete(DeleteStatusEnum.NOT_DELETED.getCode());
        setUpdateInfo(topicDimensionPO);
    }

    private void setUpdateInfo(BaTopicDimensionPO topicDimensionPO) {
        topicDimensionPO.setLastUpdateMis(WutongUserUtils.getFhUserInfo().getMisId());
        topicDimensionPO.setUpdateTime(TimeUtils.getCurrentJavaDate());
    }

    @Override
    public List<BaTopicDimensionPO> selectDimensionById(String dimensionId, String businessId) {
        BaTopicDimensionPOExample example = new BaTopicDimensionPOExample();
        example.createCriteria()
                .andIsDeleteEqualTo((short) 0)
                .andDimensionIdEqualTo(dimensionId);
        return baTopicDimensionPOMapper.selectByExample(example);
    }

    @Override
    public int deleteByTopicId(Long topicId) {
        BaTopicDimensionPOExample example = new BaTopicDimensionPOExample();
        example.createCriteria()
                .andTopicIdEqualTo(topicId);
        return baTopicDimensionPOMapper.deleteByExample(example);
    }
}
