package com.sankuai.tripdatecenter.databp.fenghuang.dao.ba;

import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ba.BaTopicDimensionPO;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ba.ext.BaTopicDimensionExtPO;

import java.util.List;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2022/4/21 3:25 下午
 */
public interface BaDimensionBizDao {
    /**
     * 根据 topicId,version 查询多条数据。
     *
     * @param topicId
     * @return
     */
    List<BaTopicDimensionExtPO> selectList(Long topicId, String businessId);

    /**
     * 根据 topicId,version 查询不被级联的维度
     * @param topicId
     * @param businessId
     * @return
     */
    List<BaTopicDimensionExtPO> selectNotRelatedList(Long topicId, String businessId);

    /**
     * 根据 reportId,topicId,version 查询多条数据。
     *
     * @param topicId
     * @return
     */
    List<BaTopicDimensionExtPO> selectDimensionEnumList(Long topicId, String dimensionId, String businessId);

    /**
     * 查询维度最新排序值
     *
     * @param topicId
     * @return
     */
    int selectMaxOrder(Long topicId, String businessId);

    /**
     * 插入维度与主题关系
     *
     * @param baTopicDimensionPO
     */
    int insertTopicDimension(BaTopicDimensionPO baTopicDimensionPO, String businessId);

    /**
     * 批量插入维度与主题关系
     *
     * @param baTopicDimensionPOS
     */
    int batchInsertTopicDimension(List<BaTopicDimensionPO> baTopicDimensionPOS, String businessId);

    /**
     * 根据维度 id 更新数据
     *
     * @param baTopicDimensionPO
     * @return
     */
    int updateTopicDimensionById(BaTopicDimensionPO baTopicDimensionPO, String businessId);

    /**
     * 批量更新
     *
     * @param baTopicDimensionPOS
     * @return
     */
    void batchUpdateTopicDimensionOrder(List<BaTopicDimensionPO> baTopicDimensionPOS, String businessId);

    List<BaTopicDimensionPO> selectDimensionById(String dimensionId, String businessId);

    /**
     * 根据topicId 删除维度与主题关系
     * @param topicId
     * @return
     */
    int deleteByTopicId(Long topicId);

}
