package com.sankuai.tripdatecenter.databp.fenghuang.dao.ba.impl;

import com.sankuai.tripdatecenter.databp.fenghuang.common.enums.DeleteStatusEnum;
import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.FhIdUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.TimeUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.WutongUserUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.ba.BaModuleDao;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.mapper.ba.auto.BaModulePOMapper;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.mapper.ba.ext.BaModulePOMapperExt;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ba.BaModulePO;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ba.example.BaModulePOExample;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.List;

import static com.sankuai.tripdatecenter.databp.fenghuang.common.constant.BizConstant.ORDER_STR;
import static com.sankuai.tripdatecenter.databp.fenghuang.common.constant.NumberConstant.ZERO;

/**
 * description
 *
 * @author mayuzhe@meituan.com
 * @date 2023/2/28
 */
@Repository
public class BaModuleDaoImpl implements BaModuleDao {
    @Resource
    private BaModulePOMapper baModulePOMapper;
    @Resource
    private BaModulePOMapperExt baModulePOMapperExt;

    @Override
    public List<BaModulePO> selectListByTopicId(Long topicId) {
        BaModulePOExample example = new BaModulePOExample();
        example.createCriteria()
                .andTopicIdEqualTo(topicId)
                .andIsDeleteEqualTo(DeleteStatusEnum.NOT_DELETED.getCode());
        example.setOrderByClause(ORDER_STR);
        List<BaModulePO> modulePOS = baModulePOMapper.selectByExample(example);
        if(modulePOS == null){
            return Collections.EMPTY_LIST;
        }
        return modulePOS;
    }

    @Override
    public int selectMaxOrder(Long topicId) {
        Integer orderNum = baModulePOMapperExt.selectMaxOrderNum(topicId);
        if (orderNum == null) {
            orderNum = ZERO;
        }
        return orderNum;
    }

    @Override
    public int insertModule(BaModulePO baModulePO) {
        setCreateInfo(baModulePO);
        return baModulePOMapper.insert(baModulePO);
    }

    @Override
    public int updateByIdAndVersion(BaModulePO baModulePO) {
        setUpdateInfo(baModulePO);
        BaModulePOExample example = new BaModulePOExample();
        BaModulePOExample.Criteria criteria = example.createCriteria();
        if(baModulePO.getTopicId() != null){
            criteria.andTopicIdEqualTo(baModulePO.getTopicId());
        }
        if(baModulePO.getModuleId() != null){
            criteria.andModuleIdEqualTo(baModulePO.getModuleId());
        }
        if(baModulePO.getReportId() != null){
            criteria.andReportIdEqualTo(baModulePO.getReportId());
        }
        return baModulePOMapper.updateByExampleSelective(baModulePO, example);
    }

    @Override
    public void batchUpdateOrder(List<BaModulePO> baModulePOS) {
        baModulePOMapperExt.updateBaModuleOrderBatch(baModulePOS);
    }

    private void setCreateInfo(BaModulePO baModulePO) {
        baModulePO.setCreatedTime(TimeUtils.getCurrentJavaDate());
        baModulePO.setCreatedMis(WutongUserUtils.getUser());
        baModulePO.setModuleId(FhIdUtils.genFhUnifiedId());
        baModulePO.setIsDelete(DeleteStatusEnum.NOT_DELETED.getCode());
        setUpdateInfo(baModulePO);
    }

    private void setUpdateInfo(BaModulePO baModulePO) {
        baModulePO.setUpdateTime(TimeUtils.getCurrentJavaDate());
        baModulePO.setLastUpdateMis(WutongUserUtils.getUser());
    }
}
