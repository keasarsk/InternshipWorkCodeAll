package com.sankuai.tripdatecenter.databp.fenghuang.dao.mapper.ext;

import com.sankuai.tripdatecenter.databp.fenghuang.common.domain.request.IndicatorRequestParam;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.IndicatorPO;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * description 临时应用相关Mapper
 *
 * @author nixuefeng
 * @createTime 2022/4/11 3:47 下午
 */
public interface IndicatorPOMapperExt {

    int updateDeleted(@Param("indicators") List<IndicatorPO> list, @Param("version") Long version, @Param("appId") Long appId, @Param("businessId") String businessId);

    List<String> selectIndicatorCodeByOnlineApp(@Param("indicators") List<IndicatorPO> indicators, @Param("appId") Long appId, @Param("businessId") String businessId);

    int insertBatch(@Param("indicators") List<IndicatorPO> indicators, @Param("businessId") String businessId);

    Long countIndicator(@Param("param") IndicatorRequestParam requestParam, @Param("businessId") String businessId);

    List<IndicatorPO> selectIndicators(@Param("indicatorCodeOrName") String indicatorCodeOrName, @Param("indicatorId") String indicatorId, @Param("appType")Integer appType, @Param("appId")Long appId, @Param("businessId") String businessId);

    List<IndicatorPO> selectIndicatorsByTmpAppId(@Param("codes") List<String> codes, @Param("tmpAppId") Long tmpAppId, @Param("version") Long version, @Param("businessId") String businessId);

    List<IndicatorPO> selectIndicatorsByTopicId(@Param("reportId") Long reportId, @Param("topicId") Long topicId, @Param("version") Long version, @Param("businessId") String businessId);

    List<IndicatorPO> selectIndicatorsByTopicIdWithoutVersion(@Param("reportId") Long reportId, @Param("topicId") Long topicId, @Param("businessId") String businessId);
}
