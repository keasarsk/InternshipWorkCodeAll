package com.sankuai.tripdatecenter.databp.fenghuang.dao.mapper.ext;


import com.dianping.zebra.dao.datasource.ZebraRouting;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ext.BdQueryParamPO;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ext.OrgAreaExtPO;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ext.OrgQueryParamPO;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ext.TravelDimBdExtPO;
import org.apache.ibatis.annotations.Param;

import java.util.List;


@ZebraRouting("dataSource_mysql_data_center_data")
public interface OrgStructurePOMapperExt {

    /**
     * 包含SKA组织架构
     * @return
     */
    List<OrgAreaExtPO> queryAllOrgsWithSKA(@Param("param")OrgQueryParamPO orgQueryParam);

    /**
     * 不包含SKA组织架构
     * @return
     */
    List<OrgAreaExtPO> queryAllOrgsWithoutSKA(@Param("param")OrgQueryParamPO orgQueryParam);

    /**
     * 查询所有BD列表
     * @return
     */
    List<TravelDimBdExtPO> queryAllBds(@Param("param")BdQueryParamPO bdQueryParam);

    /**
     * 查询所有BD列表
     * @return
     */
    List<TravelDimBdExtPO> queryAllUsers(@Param("param")BdQueryParamPO bdQueryParam);

    /**
     * 查询所有BD列表
     * @return
     */
    List<TravelDimBdExtPO> queryAllNotBds(@Param("param")BdQueryParamPO bdQueryParam);

}