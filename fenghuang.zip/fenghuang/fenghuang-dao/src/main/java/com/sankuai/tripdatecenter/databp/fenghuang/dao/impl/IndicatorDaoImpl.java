package com.sankuai.tripdatecenter.databp.fenghuang.dao.impl;

import com.sankuai.tripdatecenter.databp.fenghuang.common.enums.AppTypeEnum;
import com.sankuai.tripdatecenter.databp.fenghuang.common.enums.DeleteStatusEnum;
import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.TimeUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.WutongUserUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.IndicatorDao;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.mapper.auto.IndicatorPOMapper;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.mapper.ext.IndicatorPOMapperExt;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.IndicatorPO;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.example.IndicatorPOExample;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.example.IndicatorPOExample.Criteria;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import static com.sankuai.tripdatecenter.databp.fenghuang.common.constant.NumberConstant.ZERO;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2022/4/24 7:45 下午
 */
@Repository
@Slf4j
public class IndicatorDaoImpl implements IndicatorDao {
    @Resource
    private IndicatorPOMapper indicatorPOMapper;

    @Resource
    private IndicatorPOMapperExt indicatorPOMapperExt;

    @Override
    public List<IndicatorPO> selectListByTopicId(Long reportId, Long topicId, Long version, String businessId) {
        List<IndicatorPO> indicatorPOS = null;
        if (version == null) {
            indicatorPOS = indicatorPOMapperExt.selectIndicatorsByTopicIdWithoutVersion(reportId, topicId, businessId);
        } else {
            indicatorPOS = indicatorPOMapperExt.selectIndicatorsByTopicId(reportId, topicId, version, businessId);
        }
        if (indicatorPOS == null) {
            return Collections.EMPTY_LIST;
        }
        return indicatorPOS;
    }

    @Override
    public List<IndicatorPO> selectListByTmpAppId(Long tmpAppId, Long version, String businessId) {
        IndicatorPOExample indicatorExample = new IndicatorPOExample();
        IndicatorPOExample.Criteria criteria = indicatorExample.createCriteria();
        criteria.andAppIdEqualTo(tmpAppId);
        criteria.andBusinessIdEqualTo(businessId);
        criteria.andIsDeleteEqualTo((short) ZERO);
        if (version != null && version != ZERO) {
            criteria.andVersionEqualTo(version);
        }
        List<IndicatorPO> indicatorPOS = indicatorPOMapper.selectByExample(indicatorExample);
        if (indicatorPOS == null) {
            return Collections.EMPTY_LIST;
        }
        return indicatorPOS;
    }

    private IndicatorPOExample createIndicatorExampleByAppId(Long tmpAppId, Long version, String businessId) {
        IndicatorPOExample indicatorExample = new IndicatorPOExample();
        IndicatorPOExample.Criteria criteria = indicatorExample.createCriteria();
        criteria.andAppIdEqualTo(tmpAppId);
        criteria.andIsDeleteEqualTo((short) ZERO);
        criteria.andBusinessIdEqualTo(businessId);
        if (version != null && version != ZERO) {
            criteria.andVersionEqualTo(version);
        }
        return indicatorExample;
    }

    @Override
    public List<IndicatorPO> selectListByTmpAppId(List<String> indicatorCodes, Long tmpAppId, Long version, String businessId) {
        List<IndicatorPO> indicatorPOS = indicatorPOMapperExt.selectIndicatorsByTmpAppId(indicatorCodes, tmpAppId, version, businessId);
        if (indicatorPOS == null) {
            return Collections.EMPTY_LIST;
        }
        return indicatorPOS;
    }

    @Override
    public List<IndicatorPO> selectList(String indicatorCodeOrName, String indicatorId, Integer appType, Long appId, String businessId) {
        return indicatorPOMapperExt.selectIndicators(indicatorCodeOrName, indicatorId, appType, appId, businessId);
    }

    @Override
    public List<String> selectIndicatorCodeByOnlineApp(List<IndicatorPO> indicators, Long tmpAppId, String businessId) {
        List<String> indicatorCodes = indicatorPOMapperExt.selectIndicatorCodeByOnlineApp(indicators, tmpAppId, businessId);
        if (indicatorCodes == null) {
            return Collections.EMPTY_LIST;
        }
        return indicatorCodes;
    }

    @Override
    public boolean isExistIndicator(String indicatorCode, String businessId) {
        IndicatorPOExample example = new IndicatorPOExample();
        example.createCriteria()
                .andIndicatorCodeEqualTo(indicatorCode)
                .andAppTypeEqualTo(AppTypeEnum.ORIGIN.getCode())
                .andIsDeleteEqualTo(DeleteStatusEnum.NOT_DELETED.getCode())
                .andBusinessIdEqualTo(businessId);
        List<IndicatorPO> indicatorPOS = indicatorPOMapper.selectByExample(example);
        return !CollectionUtils.isEmpty(indicatorPOS);
    }

    @Override
    public int batchInsert(List<IndicatorPO> indicatorPOS, String businessId) {
        indicatorPOS.stream().forEach(indicatorPO -> {
            setCreateInfo(indicatorPO);
        });
        return indicatorPOMapperExt.insertBatch(indicatorPOS, businessId);
    }

    @Override
    public int batchDelete(List<IndicatorPO> indicatorPOS, String businessId) {
        IndicatorPOExample example = new IndicatorPOExample();
        example.createCriteria()
                .andIndicatorIdIn(indicatorPOS.stream().map(IndicatorPO::getIndicatorId).collect(Collectors.toList()))
                .andBusinessIdEqualTo(businessId);
        return indicatorPOMapper.deleteByExample(example);
    }

    @Override
    public int insert(IndicatorPO indicatorPO, String businessId) {
        setCreateInfo(indicatorPO);
        indicatorPO.setBusinessId(businessId);
        return indicatorPOMapper.insertSelective(indicatorPO);
    }

    @Override
    public int updateByTmpAppId(IndicatorPO indicatorPO, String businessId) {
        IndicatorPOExample indicatorExample = createIndicatorExampleByAppId(indicatorPO.getAppId(), null, businessId);
        if(indicatorPO.getIndicatorId() != null){
            indicatorExample.getOredCriteria().get(ZERO).andIndicatorIdEqualTo(indicatorPO.getIndicatorId());
        }
        indicatorPO.setBusinessId(businessId);
        return indicatorPOMapper.updateByExampleSelective(indicatorPO, indicatorExample);
    }

    @Override
    public int batchUpdateDelete(List<IndicatorPO> needDelete, Long tmpAppId, Long version, String businessId) {
        return indicatorPOMapperExt.updateDeleted(needDelete, version, tmpAppId, businessId);
    }

    @Override
    public int deleteIndicator(List<String> indicatorIds, String businessId) {
        IndicatorPOExample example = new IndicatorPOExample();
        IndicatorPOExample.Criteria criteria = example.createCriteria();
        criteria.andIsDeleteEqualTo((short) ZERO);
        criteria.andIndicatorIdIn(indicatorIds);
        int deleteNum = indicatorPOMapper.deleteByExample(example);
        return deleteNum;
    }

    private void setCreateInfo(IndicatorPO indicatorPO) {
        indicatorPO.setCreatedMis(WutongUserUtils.getFhUserInfo().getMisId());
        indicatorPO.setCreatedTime(TimeUtils.getCurrentJavaDate());
        indicatorPO.setIsDelete(DeleteStatusEnum.NOT_DELETED.getCode());
        setUpdateInfo(indicatorPO);
    }

    private void setUpdateInfo(IndicatorPO indicatorPO) {
        indicatorPO.setLastUpdateMis(WutongUserUtils.getFhUserInfo().getMisId());
        indicatorPO.setUpdateTime(TimeUtils.getCurrentJavaDate());
    }
}
