package com.sankuai.tripdatecenter.databp.fenghuang.dao.impl;

import com.sankuai.tripdatecenter.databp.fenghuang.common.enums.DeleteStatusEnum;
import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.TimeUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.WutongUserUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.TopicDimensionEnumDao;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.mapper.auto.TopicDimensionEnumPOMapper;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.mapper.ext.TopicDimensionEnumPOMapperExt;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.TopicDimensionEnumPO;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.example.TopicDimensionEnumPOExample;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.List;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2022/4/28 6:41 下午
 */
@Repository
public class TopicDimensionEnumDaoImpl implements TopicDimensionEnumDao {
    @Resource
    private TopicDimensionEnumPOMapper topicDimensionEnumPOMapper;
    @Resource
    private TopicDimensionEnumPOMapperExt topicDimensionEnumPOMapperExt;

    @Override
    public List<TopicDimensionEnumPO> selectListById(Long reportId, Long topicId, String dimensionId, Long version) {
        TopicDimensionEnumPOExample example = new TopicDimensionEnumPOExample();
        example.createCriteria()
                .andReportIdEqualTo(reportId)
                .andTopicIdEqualTo(topicId)
                .andDimensionIdEqualTo(dimensionId)
                .andVersionEqualTo(version)
                .andIsDeleteEqualTo(DeleteStatusEnum.NOT_DELETED.getCode());
        List<TopicDimensionEnumPO> topicDimensionEnumPOS = topicDimensionEnumPOMapper.selectByExample(example);
        if(topicDimensionEnumPOS == null){
            return Collections.EMPTY_LIST;
        }
        return topicDimensionEnumPOS;
    }

    @Override
    public int insertDimensionEnums(List<TopicDimensionEnumPO> topicDimensionEnumPOS) {
        topicDimensionEnumPOS.stream().forEach(enumPO->{
            setCreateInfo(enumPO);
        });
        return topicDimensionEnumPOMapperExt.insertBatch(topicDimensionEnumPOS);
    }

    @Override
    public int deleteDimensionEnumByTopicId(Long reportId, Long topicId, String dimensionId, Long version) {
        TopicDimensionEnumPOExample example = new TopicDimensionEnumPOExample();
        example.createCriteria()
                .andReportIdEqualTo(reportId)
                .andTopicIdEqualTo(topicId)
                .andDimensionIdEqualTo(dimensionId)
                .andVersionEqualTo(version);
        return topicDimensionEnumPOMapper.deleteByExample(example);
    }

    private void setCreateInfo(TopicDimensionEnumPO topicDimensionEnumPO){
        topicDimensionEnumPO.setCreatedMis(WutongUserUtils.getUser());
        topicDimensionEnumPO.setCreatedTime(TimeUtils.getCurrentJavaDate());
        topicDimensionEnumPO.setIsDelete(DeleteStatusEnum.NOT_DELETED.getCode());
        setUpdateInfo(topicDimensionEnumPO);
    }

    private void setUpdateInfo(TopicDimensionEnumPO topicDimensionEnumPO){
        topicDimensionEnumPO.setLastUpdateMis(WutongUserUtils.getUser());
        topicDimensionEnumPO.setUpdateTime(TimeUtils.getCurrentJavaDate());
    }
}
