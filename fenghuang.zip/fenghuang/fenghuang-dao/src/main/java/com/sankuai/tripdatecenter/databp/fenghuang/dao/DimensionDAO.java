package com.sankuai.tripdatecenter.databp.fenghuang.dao;

import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.DimensionPO;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.example.DimensionPOExample;

import java.util.List;

/**
 * Description:
 *
 * @author mayuzhe@meituan.com
 * @date 2022-04-18
 */
public interface DimensionDAO {
    /**
     * 插入维度
     *
     * @param dimensionPO
     */
    void insertDimension(DimensionPO dimensionPO, String businessId);

    /**
     * 根据维度 id 进行查询
     *
     * @param dimensionId
     * @return
     */
    DimensionPO selectByDimensionId(String dimensionId, String businessId);

    /**
     * 查询维度列表
     * @param dimName
     * @return
     */
    List<DimensionPO> selectDimensionList(String dimName, String businessId);

    /**
     * 根据临时应用id查询维度数据
     * @param tmpAppId
     * @param version
     * @return
     */
    List<DimensionPO> selectListByTmpAppID(Long tmpAppId,Long version, String businessId);

    /**
     * 根据临时应用id更新维度信息
     * @param dimensionPO
     * @return
     */
    int updateDimensionById(DimensionPO dimensionPO, String businessId);

    /**
     * 批量更新维度信息
     * @param dimensions
     * @param tmpAppId
     * @param version
     * @return
     */
    int batchUpdateDimensionList(List<DimensionPO> dimensions,Long tmpAppId,Long version, String businessId);

    int deleteDimension(List<String> dimensionIds, String businessId);
}
