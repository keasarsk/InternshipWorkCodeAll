package com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ext;

import com.facebook.swift.codec.ThriftField;
import com.facebook.swift.codec.ThriftStruct;
import java.io.Serializable;
import lombok.Data;
import lombok.ToString;

/**
 * description 指标关联应用信息
 *
 * @author fuzhengwei02
 * @createTime 2022年06月13日 12:12:00
 */
@ThriftStruct
@Data
@ToString
public class IndicatorRelatedAppExtPO implements Serializable{

   /**
    * 业务ID
    */
   private Integer indicatorId;

   /**
    * 指标CODE
    */
   private String indicatorCode;

   /**
    * 应用来源系统
    */
   private String sourceSystem;

   /**
    * 应用ID
    */
   private String appId;

   /**
    * 应用名称
    */
   private String appName;

   /**
    * 应用URL
    */
   private String appUrl;

   /**
    * 报表ID
    */
   private Long reportId;

   /**
    * 主题ID
    */
   private Long topicId;

}
