package com.sankuai.tripdatecenter.databp.fenghuang.dao.mapper.ext;

import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.DimensionPO;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * description 临时应用相关Mapper
 *
 * @author nixuefeng
 * @createTime 2022/4/11 3:47 下午
 */
public interface DimensionPOMapperExt {

    int updateDeleted(@Param("dimensions") List<DimensionPO> list, @Param("version") Long version,@Param("appId") Long appId, @Param("businessId") String businessId);
}
