package com.sankuai.tripdatecenter.databp.fenghuang.dao.impl;

import com.sankuai.tripdatecenter.databp.fenghuang.common.enums.DeleteStatusEnum;
import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.TimeUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.WutongUserUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.IndicatorDimensionRelationDao;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.mapper.auto.IndicatorDimensionRelationPOMapper;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.mapper.ext.IndicatorDimensionRelationPOMapperExt;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.IndicatorDimensionRelationPO;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.example.IndicatorDimensionRelationPOExample;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.List;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2022/4/24 4:43 下午
 */
@Repository
public class IndicatorDimensionRelationDaoImpl implements IndicatorDimensionRelationDao {
    @Resource
    private IndicatorDimensionRelationPOMapper indicatorDimensionRelationPOMapper;
    @Resource
    private IndicatorDimensionRelationPOMapperExt indicatorDimensionRelationPOMapperExt;

    @Override
    public List<IndicatorDimensionRelationPO> selectListById(Long reportId, Long topicId, String dimensionId, Long version) {
        IndicatorDimensionRelationPOExample example = new IndicatorDimensionRelationPOExample();
        example.createCriteria()
                .andReportIdEqualTo(reportId)
                .andTopicIdEqualTo(topicId)
                .andDimensionIdEqualTo(dimensionId)
                .andVersionEqualTo(version)
                .andIsDeleteEqualTo(DeleteStatusEnum.NOT_DELETED.getCode());
        List<IndicatorDimensionRelationPO> indicatorDimensionRelationPOS = indicatorDimensionRelationPOMapper.selectByExample(example);
        if(indicatorDimensionRelationPOS == null){
            return Collections.EMPTY_LIST;
        }
        return indicatorDimensionRelationPOS;
    }

    @Override
    public int insertRelation(IndicatorDimensionRelationPO indicatorDimensionRelation) {
        setCreateInfo(indicatorDimensionRelation);
        return indicatorDimensionRelationPOMapper.insert(indicatorDimensionRelation);
    }

    @Override
    public int insertRelations(List<IndicatorDimensionRelationPO> indicatorDimensionRelations) {
        indicatorDimensionRelations.stream().forEach(relation->{
            setCreateInfo(relation);
        });
        return indicatorDimensionRelationPOMapperExt.insertBatch(indicatorDimensionRelations);
    }

    @Override
    public int deleteRelation(IndicatorDimensionRelationPO indicatorDimensionRelation) {
        IndicatorDimensionRelationPOExample example = new IndicatorDimensionRelationPOExample();
        IndicatorDimensionRelationPOExample.Criteria criteria = example.createCriteria();
        if(indicatorDimensionRelation.getReportId() != null){
            criteria.andReportIdEqualTo(indicatorDimensionRelation.getReportId());
        }
        criteria.andTopicIdEqualTo(indicatorDimensionRelation.getTopicId());
        if(indicatorDimensionRelation.getDimensionId() != null){
            criteria.andDimensionIdEqualTo(indicatorDimensionRelation.getDimensionId());
        }
        criteria.andVersionGreaterThan(indicatorDimensionRelation.getVersion());
        criteria.andIsDeleteEqualTo(DeleteStatusEnum.NOT_DELETED.getCode());
        return indicatorDimensionRelationPOMapper.deleteByExample(example);
    }

    @Override
    public int deleteRelationByTopicId(Long reportId, Long topicId, String dimensionId, Long version) {
        IndicatorDimensionRelationPOExample example = new IndicatorDimensionRelationPOExample();
        example.createCriteria()
                .andReportIdEqualTo(reportId)
                .andTopicIdEqualTo(topicId)
                .andDimensionIdEqualTo(dimensionId)
                .andVersionEqualTo(version);
        return indicatorDimensionRelationPOMapper.deleteByExample(example);
    }

    private void setCreateInfo(IndicatorDimensionRelationPO indicatorDimensionRelation){
        indicatorDimensionRelation.setCreatedMis(WutongUserUtils.getUser());
        indicatorDimensionRelation.setCreatedTime(TimeUtils.getCurrentJavaDate());
        indicatorDimensionRelation.setIsDelete(DeleteStatusEnum.NOT_DELETED.getCode());
        setUpdateInfo(indicatorDimensionRelation);
    }

    private void setUpdateInfo(IndicatorDimensionRelationPO indicatorDimensionRelation){
        indicatorDimensionRelation.setLastUpdateMis(WutongUserUtils.getUser());
        indicatorDimensionRelation.setUpdateTime(TimeUtils.getCurrentJavaDate());
    }
}
