package com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ext;

import com.facebook.swift.codec.ThriftField;
import com.fasterxml.jackson.annotation.JsonFormat;
import java.util.Date;
import lombok.Data;

/**
 * Description:
 *
 * @author fuzhengwei02@meituan.com
 * @date 2022-05-09
 */
@Data
public class ReportTopicIndicatorInfoExtPO {

    /**
     * 当前 id
     */
    private Long curId;

    /**
     * 父节点 id。为 info_id
     */
    private Long parentId;

    /**
     * 报表 id
     */
    private Long reportId;

    /**
     * 版本号。格式 yyyyMMddHHmmss
     */
    private Long version;

    /**
     * 主题 id
     */
    private Long topicId;

    /**
     * 模块 id
     */
    private Long moduleId;

    /**
     * 模块名称
     */
    private String moduleName;

    /**
     * 指标 id
     */
    private String indicatorId;

    /**
     * 指标名
     */
    private String indicatorName;

    /**
     * 指标别名
     */
    private String indicatorAlias;

    /**
     * 指标标签
     */
    private String indicatorTag;

    /**
     * 值保留小数。默认值0
     */
    private Integer valueDigit;

    /**
     * 值数据格式
     */
    private String valueType;

    /**
     * 比率值保留小数。默认值0
     */
    private Integer rateValueDigit;

    /**
     * 比率值数据格式
     */
    private String rateValueType;

    /**
     * 是否含有完成率。0没有，1有。默认 0
     */
    private String isHasCompletionRate;

    /**
     * 排序
     */
    private Integer orderNum;

    /**
     * 是否在线。0为下线，1为在线
     */
    private Short isOnline;

    /**
     * 数值单位
     */
    private String valueUnit;

    /**
     * 同环比数值单位
     */
    private String rateValueUnit;

    /**
     * 是否千分位分隔
     */
    private Short ksSeparation;

    /**
     *  应用类型
     */
    private Integer appSource;

    /**
     *  应用ID
     */
    private Long appId;

    /**
     * 目标值指标应用类型
     */
    private Integer targetAppType;

    /**
     * 指标目标值应用ID
     */
    private Long targetAppId;

    /**
     * 指标层级
     */
    private Integer nodeLevel;

    /**
     * 是否降维。1-是，0-否
     */
    private Integer dimReduce;

    /**
     * 降维维度ID
     */
    private String dimReduceDimId;

    /**
     * 降维维度名称
     */
    private String dimReduceDimName;

    /**
     * YOY显示规则
     */
    private Integer yoyDisplayRule;

    /**
     * 查询策略
     */
    private Integer queryStrategy;
}
