package com.sankuai.tripdatecenter.databp.fenghuang.dao.ba;

import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ba.BaTopicIndicatorPO;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ba.ext.BaTopicIndicatorExtPO;

import java.util.List;

/**
 * Description:
 *
 * @author mayuzhe@meituan.com
 * @date 2023/3/1
 */
public interface BaTopicIndicatorDAO {
    /**
     * 删除模块下全部指标
     *
     * @param moduleId 模块 id
     */
    void deleteModuleIndicators(long moduleId);

    /**
     * 添加指标
     *
     * @param baTopicIndicatorPO 数据
     * @return
     */
    void insertIndicator(BaTopicIndicatorPO baTopicIndicatorPO);

    /**
     * 指标修改
     *
     * @param baTopicIndicatorPO
     */
    void updateIndicator(BaTopicIndicatorPO baTopicIndicatorPO);

    /**
     * 指标删除
     *
     * @param moduleId
     * @param indicatorId
     */
    void deleteIndicator(long moduleId, String indicatorId);

    /**
     * 查询指标列表
     *
     * @param moduleId 模块 id
     * @return
     */
    List<BaTopicIndicatorExtPO> selectIndicatorsByModuleId(Long moduleId);

    /**
     * 查询指标详情
     *
     * @param topicId 主题 id
     * @return
     */
    BaTopicIndicatorPO selectIndicatorByIndicatorId(Long topicId, String indicatorId);

    /**
     * 查询漏斗图指标详情
     * @param topicId
     * @return
     */
    List<BaTopicIndicatorExtPO> selectFunnelIndicatorsByTopicId(Long topicId);

    /**
     * 查询重点指标详情
     * @param topicId
     * @return
     */
    List<BaTopicIndicatorPO> selectKeyIndicatorsByTopicId(Long topicId);

    /**
     * 查询指标列表
     *
     * @param topicId 主题 id
     * @return
     */
    List<BaTopicIndicatorExtPO> selectIndicatorsByTopicId(Long topicId);


    /**
     * 指标更新顺序
     *
     * @param baTopicIndicatorPOS
     */
    void batchUpdateOrder(List<BaTopicIndicatorPO> baTopicIndicatorPOS);
}
