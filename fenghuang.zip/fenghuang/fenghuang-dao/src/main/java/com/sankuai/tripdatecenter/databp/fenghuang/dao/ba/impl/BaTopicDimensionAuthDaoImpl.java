package com.sankuai.tripdatecenter.databp.fenghuang.dao.ba.impl;

import com.dianping.lion.client.util.CollectionUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.TimeUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.WutongUserUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.ba.BaTopicDimensionAuthDao;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.mapper.ba.auto.BaTopicDimensionAuthPOMapper;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ba.BaTopicDimensionAuthPO;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ba.example.BaTopicDimensionAuthPOExample;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.List;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2023/5/16 17:53
 */
@Repository
@Slf4j
public class BaTopicDimensionAuthDaoImpl implements BaTopicDimensionAuthDao {
    @Resource
    private BaTopicDimensionAuthPOMapper baTopicDimensionAuthPOMapper;

    @Override
    public int insertBaTopicDimensionAuthPO(List<BaTopicDimensionAuthPO> baTopicDimensionAuthPOList) {
        int successCount = baTopicDimensionAuthPOList.stream().mapToInt(po -> {
            setCreateInfo(po);
            return baTopicDimensionAuthPOMapper.insertSelective(po);
        }).sum();
        return successCount;
    }

    @Override
    public int deleteBaTopicDimensionAuthByTopicId(Long topicId) {
        BaTopicDimensionAuthPOExample example = new BaTopicDimensionAuthPOExample();
        example.createCriteria().andTopicIdEqualTo(topicId);
        return baTopicDimensionAuthPOMapper.deleteByExample(example);
    }

    @Override
    public List<BaTopicDimensionAuthPO> selectBaTopicDimensionAuthByTopicId(Long topicId) {
        BaTopicDimensionAuthPOExample example = new BaTopicDimensionAuthPOExample();
        example.createCriteria()
                .andTopicIdEqualTo(topicId)
                .andIsDeleteEqualTo((short) 0);
        return baTopicDimensionAuthPOMapper.selectByExample(example);
    }

    @Override
    public BaTopicDimensionAuthPO selectByTopicIdAndDimensionId(Long topicId, String dimensionId) {
        BaTopicDimensionAuthPOExample example = new BaTopicDimensionAuthPOExample();
        example.createCriteria()
                .andTopicIdEqualTo(topicId)
                .andDimensionIdEqualTo(dimensionId)
                .andIsDeleteEqualTo((short) 0);
        List<BaTopicDimensionAuthPO> pos = baTopicDimensionAuthPOMapper.selectByExample(example);
        if(CollectionUtils.isEmpty(pos)){
            return null;
        }
        return pos.get(0);
    }

    private void setCreateInfo(BaTopicDimensionAuthPO baTopicDimensionAuthPO) {
        baTopicDimensionAuthPO.setIsDelete((short) 0);
        baTopicDimensionAuthPO.setCreatedMis(WutongUserUtils.getUser());
        baTopicDimensionAuthPO.setCreatedTime(TimeUtils.getCurrentJavaDate());
        setUpdateInfo(baTopicDimensionAuthPO);
    }

    private void setUpdateInfo(BaTopicDimensionAuthPO baTopicDimensionAuthPO) {
        baTopicDimensionAuthPO.setLastUpdateMis(WutongUserUtils.getUser());
        baTopicDimensionAuthPO.setUpdateTime(TimeUtils.getCurrentJavaDate());
    }
}
