package com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ext;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class BdQueryParamPO {

    private String login;

    private Integer bdId;

}