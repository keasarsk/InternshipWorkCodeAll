package com.sankuai.tripdatecenter.databp.fenghuang.dao.po;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class ModulePO {
    /**
     * 自增主键
     */
    private Long id;

    /**
     * 主题 id
     */
    private Long moduleId;

    /**
     * 版本号。格式 yyyyMMddHHmmss
     */
    private Long version;

    /**
     * 报表 id
     */
    private Long reportId;

    /**
     * 主题 id
     */
    private Long topicId;

    /**
     * 模块名称
     */
    private String moduleName;

    /**
     * 排序
     */
    private Integer orderNum;

    /**
     * 是否删除。0为未删除，1为删除
     */
    private Short isDelete;

    /**
     * 编辑人
     */
    private String createdMis;

    /**
     * 最新编辑人
     */
    private String lastUpdateMis;

    /**
     * 创建时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date createdTime;

    /**
     * 最后修改时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date updateTime;
}