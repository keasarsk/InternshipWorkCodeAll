package com.sankuai.tripdatecenter.databp.fenghuang.dao.ba;

import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ba.BaTopicDimensionEnumPO;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ba.ext.BaTopicDimensionEnumExtPO;

import java.util.List;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2022/4/28 6:37 下午
 */
public interface BaTopicDimensionEnumDao {
    List<BaTopicDimensionEnumPO> selectListById(Long topicId, String dimensionId);
    List<BaTopicDimensionEnumExtPO> selectEnumListAndRelatedDimensionById(Long topicId, String dimensionId);
    int insertBaDimensionEnums(List<BaTopicDimensionEnumPO> topicDimensionEnumPOS);
    int deleteBaDimensionEnumByTopicId(Long topicId, String dimensionId);
}
