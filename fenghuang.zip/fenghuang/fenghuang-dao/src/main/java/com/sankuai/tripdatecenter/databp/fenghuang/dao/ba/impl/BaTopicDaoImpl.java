package com.sankuai.tripdatecenter.databp.fenghuang.dao.ba.impl;

import com.sankuai.hbdata.commonutils.common.BeanCopyUtils;
import com.sankuai.hbdata.commonutils.common.CollectionUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.TimeUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.WutongUserUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.ba.BaTopicDao;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.mapper.auto.TopicPOMapper;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.mapper.ba.auto.BaTopicPOMapper;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.mapper.ba.ext.BaTopicPOMapperExt;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.TopicPO;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ba.BaTopicPO;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ba.example.BaTopicPOExample;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ba.ext.BaTopicExtPO;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.example.TopicPOExample;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.List;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2023/2/28 19:19
 */
@Repository
public class BaTopicDaoImpl implements BaTopicDao {
    @Resource
    private BaTopicPOMapper baTopicPOMapper;
    @Resource
    private BaTopicPOMapperExt baTopicPOMapperExt;
    @Resource
    private TopicPOMapper topicPOMapper;

    @Override
    public BaTopicExtPO selectByTopicId(Long topicId) {
        BaTopicExtPO baTopicPO = baTopicPOMapperExt.selectByTopicId(topicId);
        return baTopicPO;
    }

    @Override
    public List<BaTopicExtPO> selectByReportId(Long reportId, String businessId) {
        return baTopicPOMapperExt.selectByReportId(reportId, businessId);
    }

    @Override
    public BaTopicPO selectConfigByTopicId(Long topicId) {
        BaTopicPOExample example = new BaTopicPOExample();
        example.createCriteria().andTopicIdEqualTo(topicId)
                .andIsDeleteEqualTo((short) 0);
        List<BaTopicPO> baTopicPOList = baTopicPOMapper.selectByExample(example);
        if (CollectionUtils.isEmpty(baTopicPOList)) {
            return null;
        }
        return baTopicPOList.stream().findFirst().get();
    }

    @Override
    public int insertBaTopic(BaTopicPO baTopicPO) {
        setCreateInfo(baTopicPO);
        return baTopicPOMapper.insertSelective(baTopicPO);
    }

    @Override
    public int updateBaTopic(BaTopicExtPO baTopicPO) {
        BaTopicPOExample baExample = new BaTopicPOExample();
        baExample.createCriteria()
                .andTopicIdEqualTo(baTopicPO.getTopicId())
                .andIsDeleteEqualTo((short) 0);
        setUpdateInfo(baTopicPO);
        TopicPO topicPO = new TopicPO();
        BeanCopyUtils.copyProperties(baTopicPO, topicPO);
        topicPO.setId(null);
        TopicPOExample example = new TopicPOExample();
        example.createCriteria()
                .andTopicIdEqualTo(baTopicPO.getTopicId())
                .andIsDeleteEqualTo((short) 0);
        topicPOMapper.updateByExampleSelective(topicPO, example);
        return baTopicPOMapper.updateByExampleSelective(baTopicPO, baExample);
    }

    private void setCreateInfo(BaTopicPO baTopicPO) {
        baTopicPO.setIsDelete((short) 0);
        baTopicPO.setCreatedMis(WutongUserUtils.getUser());
        baTopicPO.setCreatedTime(TimeUtils.getCurrentJavaDate());
        setUpdateInfo(baTopicPO);
    }

    private void setUpdateInfo(BaTopicPO baTopicPO) {
        baTopicPO.setLastUpdateMis(WutongUserUtils.getUser());
        baTopicPO.setUpdateTime(TimeUtils.getCurrentJavaDate());
    }
}
