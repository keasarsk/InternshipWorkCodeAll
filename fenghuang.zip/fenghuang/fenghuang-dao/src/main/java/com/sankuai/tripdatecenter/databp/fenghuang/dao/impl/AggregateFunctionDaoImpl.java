package com.sankuai.tripdatecenter.databp.fenghuang.dao.impl;

import com.sankuai.tripdatecenter.databp.fenghuang.dao.AggregateFunctionDao;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.mapper.auto.AggregateFunctionPOMapper;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.mapper.auto.DatasourcePOMapper;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.AggregateFunctionPO;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.example.AggregateFunctionPOExample;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.List;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2022/7/4 4:12 下午
 */
@Repository
public class AggregateFunctionDaoImpl implements AggregateFunctionDao {
    @Resource
    private AggregateFunctionPOMapper aggregateFunctionPOMapper;

    @Override
    public List<AggregateFunctionPO> selectAggregateFunctionList() {
        AggregateFunctionPOExample example = new AggregateFunctionPOExample();
        return aggregateFunctionPOMapper.selectByExample(example);
    }
}
