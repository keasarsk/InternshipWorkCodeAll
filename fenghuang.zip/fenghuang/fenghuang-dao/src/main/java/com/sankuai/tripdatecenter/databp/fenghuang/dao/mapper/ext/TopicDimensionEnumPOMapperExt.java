package com.sankuai.tripdatecenter.databp.fenghuang.dao.mapper.ext;

import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.TopicDimensionEnumPO;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2022/4/28 6:50 下午
 */
public interface TopicDimensionEnumPOMapperExt {
    int insertBatch(@Param("dimensionEnums") List<TopicDimensionEnumPO> dimensionEnums);
}
