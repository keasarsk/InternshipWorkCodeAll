package com.sankuai.tripdatecenter.databp.fenghuang.dao.po;

import java.util.Date;
import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class DatasourcePO {
    /**
     * 自增主键
     */
    private Long id;

    /**
     * 数据源 id
     */
    private Long datasourceId;

    /**
     * 数据源名字
     */
    private String datasourceName;

    /**
     * 数据源类型。MySQL、Doris、Kylin、ES
     */
    private String datasourceType;

    /**
     * 连接地址
     */
    private String jdbcUrl;

    /**
     * 用户名
     */
    private String username;

    /**
     * psw
     */
    private String psw;

    /**
     * 驱动类
     */
    private String driverClassName;

    /**
     * 是否删除。0为未删除，1为删除
     */
    private Short isDelete;

    /**
     * 编辑人
     */
    private String createdMis;

    /**
     * 最新编辑人
     */
    private String lastUpdateMis;

    /**
     * 创建时间
     */
    private Date createdTime;

    /**
     * 最后修改时间
     */
    private Date updateTime;

    /**
     * 业务线ID
     */
    private String businessId;

    /**
     * 参数配置
     */
    private String params;
}