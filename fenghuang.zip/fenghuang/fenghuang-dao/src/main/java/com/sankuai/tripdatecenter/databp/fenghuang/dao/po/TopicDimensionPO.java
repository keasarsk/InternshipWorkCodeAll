package com.sankuai.tripdatecenter.databp.fenghuang.dao.po;

import java.util.Date;
import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class TopicDimensionPO {
    /**
     * 自增主键
     */
    private Long id;

    /**
     * 维度 id
     */
    private String dimensionId;

    /**
     * 报表 id
     */
    private Long reportId;

    /**
     * 版本号。格式 yyyyMMddHHmmss
     */
    private Long version;

    /**
     * 主题 id
     */
    private Long topicId;

    /**
     * 排序字段
     */
    private Integer orderNum;

    /**
     * 组件类型
     */
    private String compType;

    /**
     * 是否删除。0为未删除，1为删除
     */
    private Short isDelete;

    /**
     * 编辑人
     */
    private String createdMis;

    /**
     * 最新编辑人
     */
    private String lastUpdateMis;

    /**
     * 创建时间
     */
    private Date createdTime;

    /**
     * 最后修改时间
     */
    private Date updateTime;

    /**
     * 维度别名
     */
    private String dimensionAlias;
}