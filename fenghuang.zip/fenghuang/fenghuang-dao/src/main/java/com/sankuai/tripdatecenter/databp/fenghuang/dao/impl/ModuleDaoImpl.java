package com.sankuai.tripdatecenter.databp.fenghuang.dao.impl;

import com.sankuai.tripdatecenter.databp.fenghuang.common.enums.DeleteStatusEnum;
import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.FhIdUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.TimeUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.WutongUserUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.ModuleDao;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.mapper.auto.ModulePOMapper;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.mapper.ext.ModulePOMapperExt;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ModulePO;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.example.ModulePOExample;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.List;

import static com.sankuai.tripdatecenter.databp.fenghuang.common.constant.BizConstant.ORDER_STR;
import static com.sankuai.tripdatecenter.databp.fenghuang.common.constant.NumberConstant.ZERO;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2022/4/22 5:52 下午
 */
@Repository
public class ModuleDaoImpl implements ModuleDao {
    @Resource
    private ModulePOMapper modulePOMapper;
    @Resource
    private ModulePOMapperExt modulePOMapperExt;

    @Override
    public List<ModulePO> selectListByTopicId(Long topicId, Long version) {
        ModulePOExample example = new ModulePOExample();
        example.createCriteria()
                .andTopicIdEqualTo(topicId)
                .andVersionEqualTo(version)
                .andIsDeleteEqualTo(DeleteStatusEnum.NOT_DELETED.getCode());
        example.setOrderByClause(ORDER_STR);
        List<ModulePO> modulePOS = modulePOMapper.selectByExample(example);
        if(modulePOS == null){
            return Collections.EMPTY_LIST;
        }
        return modulePOS;
    }

    @Override
    public int selectMaxOrder(Long topicId, Long version) {
        Integer orderNum = modulePOMapperExt.selectMaxOrderNum(topicId, version);
        if (orderNum == null) {
            orderNum = ZERO;
        }
        return orderNum;
    }

    @Override
    public int insertModule(ModulePO modulePO) {
        setCreateInfo(modulePO);
        return modulePOMapper.insert(modulePO);
    }

    @Override
    public int updateByIdAndVersion(ModulePO modulePO) {
        setUpdateInfo(modulePO);
        ModulePOExample example = new ModulePOExample();
        ModulePOExample.Criteria criteria = example.createCriteria();
        if(modulePO.getTopicId() != null){
            criteria.andTopicIdEqualTo(modulePO.getTopicId());
        }
        if(modulePO.getModuleId() != null){
            criteria.andModuleIdEqualTo(modulePO.getModuleId());
        }
        if(modulePO.getVersion() != null){
            criteria.andVersionEqualTo(modulePO.getVersion());
        }
        if(modulePO.getReportId() != null){
            criteria.andReportIdEqualTo(modulePO.getReportId());
        }
        return modulePOMapper.updateByExampleSelective(modulePO, example);
    }

    @Override
    public void batchUpdateOrder(List<ModulePO> modulePOS) {
        modulePOMapperExt.updateModuleOrderBatch(modulePOS);
    }

    private void setCreateInfo(ModulePO modulePO) {
        modulePO.setCreatedTime(TimeUtils.getCurrentJavaDate());
        modulePO.setCreatedMis(WutongUserUtils.getUser());
        modulePO.setModuleId(FhIdUtils.genFhUnifiedId());
        modulePO.setIsDelete(DeleteStatusEnum.NOT_DELETED.getCode());
        setUpdateInfo(modulePO);
    }

    private void setUpdateInfo(ModulePO modulePO) {
        modulePO.setUpdateTime(TimeUtils.getCurrentJavaDate());
        modulePO.setLastUpdateMis(WutongUserUtils.getUser());
    }
}
