package com.sankuai.tripdatecenter.databp.fenghuang.dao.impl;

import com.sankuai.tripdatecenter.databp.fenghuang.common.exception.FHBaseException;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.TemplateDao;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.mapper.auto.TemplatePOMapper;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.mapper.ext.TemplatePOMapperExt;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.TemplatePO;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.example.TemplatePOExample;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.List;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2023/2/28 17:49
 */
@Repository
public class TemplateDaoImpl implements TemplateDao {
    @Resource
    private TemplatePOMapper templatePOMapper;

    @Resource
    private TemplatePOMapperExt templatePOMapperExt;

    @Override
    public List<TemplatePO> selectTemplate() throws FHBaseException {
        TemplatePOExample example = new TemplatePOExample();
        example.createCriteria().andIsDeleteEqualTo((short) 0);
        return templatePOMapper.selectByExample(example);
    }

    @Override
    public List<TemplatePO> selectTemplateByType(String templateType) throws FHBaseException {
        TemplatePOExample example = new TemplatePOExample();
        example.createCriteria()
                .andIsDeleteEqualTo((short) 0)
                .andTemplateTypeEqualTo(templateType);
        return templatePOMapper.selectByExample(example);
    }

    @Override
    public TemplatePO selectTemplateByTopicId(long topicId) throws FHBaseException {
        return templatePOMapperExt.getTemplateByTopicId(topicId);
    }
}
