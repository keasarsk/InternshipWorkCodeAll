package com.sankuai.tripdatecenter.databp.fenghuang.dao.po;

import java.util.Date;
import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class AggregateFunctionPO {
    /**
     * 自增主键
     */
    private Long id;

    /**
     * 聚合方式
     */
    private String aggregateFunction;

    /**
     * 描述信息
     */
    private String definitionInfo;

    /**
     * 创建时间
     */
    private Date createdTime;
}