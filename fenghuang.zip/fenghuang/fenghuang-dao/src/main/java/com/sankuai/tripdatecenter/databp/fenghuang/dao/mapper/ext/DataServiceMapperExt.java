package com.sankuai.tripdatecenter.databp.fenghuang.dao.mapper.ext;

import com.sankuai.tripdatecenter.databp.fenghuang.common.domain.request.IndicatorRequestParam;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.DimensionPO;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.IndicatorPO;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.TmpAppPO;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ext.ReportTopicIndicatorInfoExtPO;
import java.util.List;
import org.apache.ibatis.annotations.Param;

/**
 * description 数据服务化相关查询
 *
 * @author fuzhengwei02
 * @createTime 2022/4/11 3:47 下午
 */
public interface DataServiceMapperExt {

    IndicatorPO selectIndicatorInfoByIndicatorId(@Param("indicatorId")String indicatorId, @Param("businessId")String businessId);

    List<IndicatorPO> selectIndicatorInfoByIndicatorIds(@Param("indicatorIds")List<String> indicatorIds, @Param("businessId")String businessId);

    List<IndicatorPO> selectIndicatorInfoByIndicatorIdsOfOrigin(@Param("indicatorIds")List<String> indicatorIds, @Param("businessId")String businessId);

    List<IndicatorPO> selectIndicatorInfoByIndicatorIdsOfTempApp(@Param("indicatorIds")List<String> indicatorIds, @Param("tempAppId")Long tempAppId, @Param("version")Long version, @Param("businessId")String businessId);

    List<IndicatorPO> selectIndicatorInfoByIndicatorIdsOfUploadApp(@Param("indicatorIds")List<String> indicatorIds, @Param("businessId")String businessId);

    List<ReportTopicIndicatorInfoExtPO> selectReportTopicIndicatorInfos(@Param("reportId")Long reportId, @Param("topicId")Long topicId, @Param("version")Long version, @Param("checkedIndicatorIds")List<String> checkedIndicatorIds, @Param("businessId")String businessId);

    TmpAppPO getTmpAppByCondition(@Param("tmpAppId")Long tmpAppId, @Param("version")Long version, @Param("businessId")String businessId);

    List<String> getIndicatorIdsByReportIdAndTopicId(@Param("reportId")Long reportId, @Param("topicId")Long topicId, @Param("version")Long version);

    Integer checkIndicatorDimensionIdAndEnumValue(@Param("reportId")Long reportId, @Param("topicId")Long topicId, @Param("version")Long version, @Param("indicatorId")String indicatorId, @Param("dimensionId")String dimensionId, @Param("dimensionEnumValue")String dimensionEnumValue);

}
