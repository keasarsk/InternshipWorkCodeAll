package com.sankuai.tripdatecenter.databp.fenghuang.dao;

import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ModulePO;

import java.util.List;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2022/4/22 5:51 下午
 */
public interface ModuleDao {
    List<ModulePO> selectListByTopicId(Long topicId, Long version);

    int selectMaxOrder(Long topicId, Long version);

    int insertModule(ModulePO modulePO);

    int updateByIdAndVersion(ModulePO modulePO);

    void batchUpdateOrder(List<ModulePO> modulePOS);
}
