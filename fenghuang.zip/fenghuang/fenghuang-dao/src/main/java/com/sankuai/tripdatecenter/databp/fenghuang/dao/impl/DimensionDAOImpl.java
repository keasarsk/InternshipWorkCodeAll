package com.sankuai.tripdatecenter.databp.fenghuang.dao.impl;

import com.dianping.cat.util.StringUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.common.enums.AppTypeEnum;
import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.FhIdUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.TimeUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.WutongUserUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.DimensionDAO;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.mapper.auto.DimensionPOMapper;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.mapper.ext.DimensionPOMapperExt;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.DimensionPO;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.example.DimensionPOExample;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import static com.sankuai.tripdatecenter.databp.fenghuang.common.constant.NumberConstant.ZERO;
import static com.sankuai.tripdatecenter.databp.fenghuang.common.constant.SymbolConstant.PERCENT;

/**
 * Description:
 *
 * @author mayuzhe@meituan.com
 * @date 2022/4/18
 */
@Repository
public class DimensionDAOImpl implements DimensionDAO {
    @Resource
    private DimensionPOMapper dimensionPOMapper;
    @Resource
    private DimensionPOMapperExt dimensionPOMapperExt;

    @Override
    public void insertDimension(DimensionPO dimensionPO, String businessId) {
        Date curDate = TimeUtils.getCurrentJavaDate();
        String mis = WutongUserUtils.getUser();
        if(dimensionPO.getVersion() == null){
            long version = FhIdUtils.genFhUnifiedId();
            dimensionPO.setVersion(version);
        }
        dimensionPO.setCreatedTime(curDate);
        dimensionPO.setCreatedMis(mis);
        dimensionPO.setUpdateTime(curDate);
        dimensionPO.setLastUpdateMis(mis);
        dimensionPO.setIsDelete((short) 0);
        dimensionPO.setBusinessId(businessId);
        if (dimensionPO.getAppType() == null) {
            // 默认为起源维度
            dimensionPO.setAppType("1");
        }
        if (dimensionPO.getDimensionType() == null) {
            dimensionPO.setDimensionType("");
        }
        if (dimensionPO.getDimensionComment() == null) {
            dimensionPO.setDimensionComment("");
        }
        if (dimensionPO.getAppId() == null) {
            dimensionPO.setAppId(0L);
        }
        dimensionPOMapper.insertSelective(dimensionPO);
    }

    @Override
    public DimensionPO selectByDimensionId(String dimensionId, String businessId) {
        DimensionPOExample example = this.createCommonExample();
        example.getOredCriteria().get(ZERO).andDimensionIdEqualTo(dimensionId).andAppTypeEqualTo(AppTypeEnum.ORIGIN.getCode()).andBusinessIdEqualTo(businessId);
        List<DimensionPO> list = dimensionPOMapper.selectByExample(example);
        if (list.isEmpty()) {
            return null;
        }
        return list.get(0);
    }

    @Override
    public List<DimensionPO> selectDimensionList(String dimName, String businessId) {
        DimensionPOExample example = this.createCommonExample();
        example.getOredCriteria().get(ZERO).andAppTypeEqualTo(AppTypeEnum.ORIGIN.getCode()).andBusinessIdEqualTo(businessId);
        if(!StringUtils.isEmpty(dimName)){
            example.getOredCriteria().get(ZERO).andDimensionNameLike(PERCENT.concat(dimName).concat(PERCENT));
        }
        return dimensionPOMapper.selectByExample(example);
    }

    @Override
    public List<DimensionPO> selectListByTmpAppID(Long tmpAppId, Long version, String businessId) {
        DimensionPOExample dimensionExample = createCommonExample();
        dimensionExample.getOredCriteria().get(ZERO).andAppIdEqualTo(tmpAppId).andBusinessIdEqualTo(businessId);
        if (version != null && version != ZERO) {
            dimensionExample.getOredCriteria().get(ZERO).andVersionEqualTo(version);
        }
        List<DimensionPO> dimensionPOS = dimensionPOMapper.selectByExample(dimensionExample);
        if (dimensionPOS == null) {
            return Collections.EMPTY_LIST;
        }
        return dimensionPOS;
    }

    @Override
    public int updateDimensionById(DimensionPO dimensionPO, String businessId) {
        DimensionPOExample dimensionExample = createCommonExample();
        dimensionExample.getOredCriteria().get(ZERO).andAppIdEqualTo(dimensionPO.getAppId()).andBusinessIdEqualTo(businessId);
        if(!StringUtils.isEmpty(dimensionPO.getDimensionCode())){
            dimensionExample.getOredCriteria().get(ZERO).andDimensionCodeEqualTo(dimensionPO.getDimensionCode());
        }
        if (dimensionPO.getVersion() != null && dimensionPO.getVersion() != ZERO) {
            dimensionExample.getOredCriteria().get(ZERO).andVersionEqualTo(dimensionPO.getVersion());
        }
        return dimensionPOMapper.updateByExampleSelective(dimensionPO, dimensionExample);
    }

    @Override
    public int batchUpdateDimensionList(List<DimensionPO> dimensions, Long tmpAppId, Long version, String businessId) {
        return dimensionPOMapperExt.updateDeleted(dimensions, version, tmpAppId, businessId);
    }

    /**
     * 创建公共 example
     *
     * @return
     */
    private DimensionPOExample createCommonExample() {
        DimensionPOExample example = new DimensionPOExample();
        DimensionPOExample.Criteria criteria = example.createCriteria();
        criteria.andIsDeleteEqualTo((short) 0);
        return example;
    }

    @Override
    public int deleteDimension(List<String> dimensionIds, String businessId) {
        DimensionPOExample example = new DimensionPOExample();
        DimensionPOExample.Criteria criteria = example.createCriteria();
        criteria.andIsDeleteEqualTo((short) ZERO);
        criteria.andDimensionIdIn(dimensionIds);
        criteria.andBusinessIdEqualTo(businessId);
        int deleteNum = dimensionPOMapper.deleteByExample(example);
        return deleteNum;
    }
}
