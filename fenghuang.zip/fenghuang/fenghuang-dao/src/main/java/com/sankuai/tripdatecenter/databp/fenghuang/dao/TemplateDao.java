package com.sankuai.tripdatecenter.databp.fenghuang.dao;

import com.sankuai.tripdatecenter.databp.fenghuang.common.exception.FHBaseException;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.TemplatePO;

import java.util.List;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2023/2/28 17:47
 */
public interface TemplateDao {
    /**
     * 查询所有模板
     *
     * @return
     * @throws FHBaseException
     */
    List<TemplatePO> selectTemplate() throws FHBaseException;

    /**
     * 查询指定类型模板
     *
     * @return
     * @throws FHBaseException
     */
    List<TemplatePO> selectTemplateByType(String templateType) throws FHBaseException;

    TemplatePO selectTemplateByTopicId(long topicId) throws FHBaseException;
}
