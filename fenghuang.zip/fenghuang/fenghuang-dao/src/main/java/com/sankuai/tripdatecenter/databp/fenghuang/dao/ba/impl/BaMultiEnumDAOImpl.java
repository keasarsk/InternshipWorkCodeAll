package com.sankuai.tripdatecenter.databp.fenghuang.dao.ba.impl;

import com.sankuai.tripdatecenter.databp.fenghuang.common.enums.DeleteStatusEnum;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.ba.BaMultiEnumDAO;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.mapper.ba.auto.BaMultiEnumPOMapper;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ba.BaModulePO;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ba.BaMultiEnumPO;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ba.example.BaMultiEnumPOExample;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ba.example.BaTopicIndicatorPOExample;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.List;

/**
 * Description:
 *
 * @author mayuzhe@meituan.com
 * @date 2023/3/2
 */
@Repository
public class BaMultiEnumDAOImpl implements BaMultiEnumDAO {
    @Resource
    private BaMultiEnumPOMapper baMultiEnumPOMapper;

    @Override
    public List<BaMultiEnumPO> getMultiEnumListByMultiType(String multiConfigType) {
        BaMultiEnumPOExample example = this.createCommonExample();
        example.getOredCriteria().get(0)
                .andMultiConfigTypeEqualTo(multiConfigType);
        List<BaMultiEnumPO> baMultiEnumPOS = baMultiEnumPOMapper.selectByExample(example);
        if(baMultiEnumPOS == null){
            return Collections.EMPTY_LIST;
        }
        return baMultiEnumPOS;
    }

    /**
     * 创建公共 example
     *
     * @return
     */
    private BaMultiEnumPOExample createCommonExample() {
        BaMultiEnumPOExample example = new BaMultiEnumPOExample();
        BaMultiEnumPOExample.Criteria criteria = example.createCriteria();
        criteria.andIsDeleteEqualTo((short) 0);
        return example;
    }
}
