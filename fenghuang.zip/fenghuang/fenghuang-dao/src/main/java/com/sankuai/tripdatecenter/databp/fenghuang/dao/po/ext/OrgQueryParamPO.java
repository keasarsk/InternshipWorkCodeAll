package com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ext;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class OrgQueryParamPO {

    private Integer regionId;

    private Integer subRegionId;

    private Integer groupId;

}