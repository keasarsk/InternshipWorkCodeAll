package com.sankuai.tripdatecenter.databp.fenghuang.dao.ba.impl;

import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.TimeUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.WutongUserUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.ba.BaTopicIndicatorReduceDimEnumDAO;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.mapper.ba.auto.BaTopicIndicatorReduceDimEnumPOMapper;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ba.BaTopicIndicatorReduceDimEnumPO;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ba.example.BaTopicIndicatorReduceDimEnumPOExample;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

/**
 * Description:
 *
 * @author mayuzhe@meituan.com
 * @date 2023/3/1
 */
@Repository
public class BaTopicIndicatorReduceDimEnumDAOImpl implements BaTopicIndicatorReduceDimEnumDAO {
    @Resource
    private BaTopicIndicatorReduceDimEnumPOMapper baTopicIndicatorReduceDimEnumPOMapper;

    @Override
    public void deleteReduceDimEnum(long moduleId, String indicatorId) {
        BaTopicIndicatorReduceDimEnumPOExample example = this.createCommonExample();
        example.getOredCriteria().get(0)
                .andModuleIdEqualTo(moduleId)
                .andIndicatorIdEqualTo(indicatorId);
        baTopicIndicatorReduceDimEnumPOMapper.deleteByExample(example);
    }

    @Override
    public void insertConfig(BaTopicIndicatorReduceDimEnumPO reduceDimEnumPO) {
        this.setDefaultValue(reduceDimEnumPO);
        baTopicIndicatorReduceDimEnumPOMapper.insertSelective(reduceDimEnumPO);
    }

    @Override
    public List<BaTopicIndicatorReduceDimEnumPO> getReduceDimEnumsList(long moduleId, String indicatorId, String dimId) {
        BaTopicIndicatorReduceDimEnumPOExample example = this.createCommonExample();
        example.getOredCriteria().get(0)
                .andModuleIdEqualTo(moduleId)
                .andIndicatorIdEqualTo(indicatorId)
                .andDimensionIdEqualTo(dimId);
        return baTopicIndicatorReduceDimEnumPOMapper.selectByExample(example);
    }

    /**
     * 创建公共 example
     *
     * @return
     */
    private BaTopicIndicatorReduceDimEnumPOExample createCommonExample() {
        BaTopicIndicatorReduceDimEnumPOExample example = new BaTopicIndicatorReduceDimEnumPOExample();
        BaTopicIndicatorReduceDimEnumPOExample.Criteria criteria = example.createCriteria();
        criteria.andIsDeleteEqualTo((short) 0);
        return example;
    }

    private void setDefaultValue(BaTopicIndicatorReduceDimEnumPO reduceDimEnumPO) {
        Date curDate = TimeUtils.getCurrentJavaDate();
        String mis = WutongUserUtils.getFhUserInfo().getMisId();
        reduceDimEnumPO.setCreatedMis(mis);
        reduceDimEnumPO.setLastUpdateMis(mis);
        reduceDimEnumPO.setUpdateTime(curDate);
        reduceDimEnumPO.setCreatedTime(curDate);
        reduceDimEnumPO.setIsDelete((short) 0);
    }
}
