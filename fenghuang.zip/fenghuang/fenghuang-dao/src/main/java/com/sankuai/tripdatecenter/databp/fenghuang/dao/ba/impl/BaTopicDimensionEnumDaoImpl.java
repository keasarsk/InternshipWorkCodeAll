package com.sankuai.tripdatecenter.databp.fenghuang.dao.ba.impl;

import com.sankuai.tripdatecenter.databp.fenghuang.common.enums.DeleteStatusEnum;
import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.TimeUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.WutongUserUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.ba.BaTopicDimensionEnumDao;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.mapper.ba.auto.BaTopicDimensionEnumPOMapper;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.mapper.ba.ext.BaTopicDimensionEnumPOMapperExt;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ba.BaTopicDimensionEnumPO;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ba.example.BaTopicDimensionEnumPOExample;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ba.ext.BaTopicDimensionEnumExtPO;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.List;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2022/4/28 6:41 下午
 */
@Repository
public class BaTopicDimensionEnumDaoImpl implements BaTopicDimensionEnumDao {
    @Resource
    private BaTopicDimensionEnumPOMapper baTopicDimensionEnumPOMapper;
    @Resource
    private BaTopicDimensionEnumPOMapperExt baTopicDimensionEnumPOMapperExt;

    @Override
    public List<BaTopicDimensionEnumPO> selectListById(Long topicId, String dimensionId) {
        BaTopicDimensionEnumPOExample example = new BaTopicDimensionEnumPOExample();
        example.createCriteria()
                .andTopicIdEqualTo(topicId)
                .andDimensionIdEqualTo(dimensionId)
                .andIsDeleteEqualTo(DeleteStatusEnum.NOT_DELETED.getCode());
        List<BaTopicDimensionEnumPO> topicDimensionEnumPOS = baTopicDimensionEnumPOMapper.selectByExample(example);
        if (topicDimensionEnumPOS == null) {
            return Collections.EMPTY_LIST;
        }
        return topicDimensionEnumPOS;
    }

    @Override
    public List<BaTopicDimensionEnumExtPO> selectEnumListAndRelatedDimensionById(Long topicId, String dimensionId) {
        return baTopicDimensionEnumPOMapperExt.selectEnumListAndDimRelation(topicId, dimensionId);
    }

    @Override
    public int insertBaDimensionEnums(List<BaTopicDimensionEnumPO> topicDimensionEnumPOS) {
        topicDimensionEnumPOS.stream().forEach(enumPO -> {
            setCreateInfo(enumPO);
        });
        return baTopicDimensionEnumPOMapperExt.insertBatch(topicDimensionEnumPOS);
    }

    @Override
    public int deleteBaDimensionEnumByTopicId(Long topicId, String dimensionId) {
        BaTopicDimensionEnumPOExample example = new BaTopicDimensionEnumPOExample();
        example.createCriteria()
                .andTopicIdEqualTo(topicId)
                .andDimensionIdEqualTo(dimensionId);
        return baTopicDimensionEnumPOMapper.deleteByExample(example);
    }

    private void setCreateInfo(BaTopicDimensionEnumPO topicDimensionEnumPO) {
        topicDimensionEnumPO.setCreatedMis(WutongUserUtils.getUser());
        topicDimensionEnumPO.setCreatedTime(TimeUtils.getCurrentJavaDate());
        topicDimensionEnumPO.setIsDelete(DeleteStatusEnum.NOT_DELETED.getCode());
        setUpdateInfo(topicDimensionEnumPO);
    }

    private void setUpdateInfo(BaTopicDimensionEnumPO topicDimensionEnumPO) {
        topicDimensionEnumPO.setLastUpdateMis(WutongUserUtils.getUser());
        topicDimensionEnumPO.setUpdateTime(TimeUtils.getCurrentJavaDate());
    }
}
