package com.sankuai.tripdatecenter.databp.fenghuang.dao.po;

import java.util.Date;
import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class MetaReportPO {
    /**
     * 自增主键
     */
    private Long id;

    /**
     * 报表id
     */
    private String reportId;

    /**
     * 数值类型report_id，对应fenghuang_info_report表中report_id
     */
    private Long reportIdNum;

    /**
     * 主题id
     */
    private String topicId;

    private Long topicIdNum;

    /**
     * 查询标识
     */
    private String queryId;

    /**
     * 创建时间
     */
    private Date createdTime;

    /**
     * 创建人
     */
    private String createdMis;

    /**
     * 更新时间
     */
    private Date updateTime;

    /**
     * 更新人
     */
    private String updateMis;

    /**
     * 版本
     */
    private Short version;

    /**
     * 在线状态，1：在线，0：不在线
     */
    private Short isOnline;

    /**
     * 是否删除，0：否，1：是
     */
    private Short isDelete;

    /**
     * 报表名称
     */
    private String reportName;

    /**
     * 描述信息
     */
    private String desc;

    /**
     * Sql接受人
     */
    private String sqlReceiver;

    /**
     * 插件配置
     */
    private String pluginConfig;

    private String reportConfig;
}