package com.sankuai.tripdatecenter.databp.fenghuang.dao.ba.impl;


import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.TimeUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.WutongUserUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.ba.BaTopicIndicatorDAO;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.mapper.ba.auto.BaRelationIndicatorDimensionPOMapper;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.mapper.ba.auto.BaTopicIndicatorPOMapper;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.mapper.ba.ext.BaTopicIndicatorPOMapperExt;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.mapper.ext.TopicIndicatorPOMapperExt;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ba.BaTopicIndicatorPO;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ba.example.BaRelationIndicatorDimensionPOExample;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ba.example.BaTopicIndicatorPOExample;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ba.ext.BaTopicIndicatorExtPO;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.example.IndicatorDimensionRelationPOExample;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

/**
 * Description:
 *
 * @author mayuzhe@meituan.com
 * @date 2023/3/1
 */
@Repository
public class BaTopicIndicatorDAOImpl implements BaTopicIndicatorDAO {
    @Resource
    private BaTopicIndicatorPOMapper baTopicIndicatorPOMapper;
    @Resource
    private BaTopicIndicatorPOMapperExt baTopicIndicatorPOMapperExt;

    private final static String ORDER_PHASE = "order_num asc";

    @Override
    public void deleteModuleIndicators(long moduleId) {
        BaTopicIndicatorPOExample example = this.createCommonExample();
        example.getOredCriteria().get(0)
                .andModuleIdEqualTo(moduleId);
        baTopicIndicatorPOMapper.deleteByExample(example);
    }

    @Override
    public void insertIndicator(BaTopicIndicatorPO baTopicIndicatorPO) {
        this.setDefaultValue(baTopicIndicatorPO);
        baTopicIndicatorPOMapper.insertSelective(baTopicIndicatorPO);
    }

    @Override
    public void updateIndicator(BaTopicIndicatorPO baTopicIndicatorPO) {
        BaTopicIndicatorPOExample example = this.createCommonExample();
        example.getOredCriteria().get(0)
                .andModuleIdEqualTo(baTopicIndicatorPO.getModuleId())
                .andIndicatorIdEqualTo(baTopicIndicatorPO.getIndicatorId());
        this.updateByExampleSelective(baTopicIndicatorPO, example);
    }

    @Override
    public void deleteIndicator(long moduleId, String indicatorId) {
        BaTopicIndicatorPOExample example = this.createCommonExample();
        example.getOredCriteria().get(0)
                .andModuleIdEqualTo(moduleId)
                .andIndicatorIdEqualTo(indicatorId);
        baTopicIndicatorPOMapper.deleteByExample(example);
    }

    @Override
    public List<BaTopicIndicatorExtPO> selectIndicatorsByModuleId(Long moduleId) {
        return baTopicIndicatorPOMapperExt.selectIndicatorsByModuleId(moduleId);
    }

    @Override
    public BaTopicIndicatorPO selectIndicatorByIndicatorId(Long topicId, String indicatorId) {
        BaTopicIndicatorPOExample example = createCommonExample();
        example.getOredCriteria()
                .stream()
                .findFirst().get()
                .andTopicIdEqualTo(topicId)
                .andIndicatorIdEqualTo(indicatorId);
        List<BaTopicIndicatorPO> topicIndicatorPOS = baTopicIndicatorPOMapper.selectByExample(example);
        if(CollectionUtils.isEmpty(topicIndicatorPOS)){
            return null;
        }
        return topicIndicatorPOS.stream().findFirst().get();
    }

    @Override
    public List<BaTopicIndicatorExtPO> selectFunnelIndicatorsByTopicId(Long topicId) {
        return baTopicIndicatorPOMapperExt.selectFunnelIndicatorsByTopicId(topicId);
    }

    @Override
    public List<BaTopicIndicatorPO> selectKeyIndicatorsByTopicId(Long topicId) {
        BaTopicIndicatorPOExample example = createCommonExample();
        example.getOredCriteria()
                .stream()
                .findFirst().get()
                .andTopicIdEqualTo(topicId)
                .andIsKeyEqualTo((short)1);
        return baTopicIndicatorPOMapper.selectByExample(example);
    }

    @Override
    public List<BaTopicIndicatorExtPO> selectIndicatorsByTopicId(Long topicId) {
        return baTopicIndicatorPOMapperExt.selectIndicatorsByTopicId(topicId);
    }

    @Override
    public void batchUpdateOrder(List<BaTopicIndicatorPO> baTopicIndicatorPOS) {
        baTopicIndicatorPOS.forEach(this::setUpdateValue);
        baTopicIndicatorPOMapperExt.updateIndicatorOrderBatch(baTopicIndicatorPOS);
    }

    /**
     * 创建公共 example
     *
     * @return
     */
    private BaTopicIndicatorPOExample createCommonExample() {
        BaTopicIndicatorPOExample example = new BaTopicIndicatorPOExample();
        BaTopicIndicatorPOExample.Criteria criteria = example.createCriteria();
        criteria.andIsDeleteEqualTo((short) 0);
        return example;
    }

    private void setDefaultValue(BaTopicIndicatorPO baTopicIndicatorPO) {
        Date curDate = TimeUtils.getCurrentJavaDate();
        String mis = WutongUserUtils.getFhUserInfo().getMisId();
        baTopicIndicatorPO.setCreatedMis(mis);
        baTopicIndicatorPO.setLastUpdateMis(mis);
        baTopicIndicatorPO.setUpdateTime(curDate);
        baTopicIndicatorPO.setCreatedTime(curDate);
        baTopicIndicatorPO.setIsDelete((short) 0);
    }

    private void setUpdateValue(BaTopicIndicatorPO baTopicIndicatorPO) {
        Date curDate = TimeUtils.getCurrentJavaDate();
        String mis = WutongUserUtils.getFhUserInfo().getMisId();
        baTopicIndicatorPO.setLastUpdateMis(mis);
        baTopicIndicatorPO.setUpdateTime(curDate);
    }

    /**
     * 封装更新。修改更新人mis、更新时间
     *
     * @param po
     * @param example
     * @return
     */
    private int updateByExampleSelective(BaTopicIndicatorPO po, BaTopicIndicatorPOExample example) {
        po.setLastUpdateMis(WutongUserUtils.getUser());
        po.setUpdateTime(TimeUtils.getCurrentJavaDate());
        return baTopicIndicatorPOMapper.updateByExampleSelective(po, example);
    }
}
