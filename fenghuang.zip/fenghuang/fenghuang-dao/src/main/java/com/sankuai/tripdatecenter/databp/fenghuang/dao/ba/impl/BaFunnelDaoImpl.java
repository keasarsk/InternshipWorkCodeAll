package com.sankuai.tripdatecenter.databp.fenghuang.dao.ba.impl;

import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.TimeUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.WutongUserUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.ba.BaFunnelDao;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.mapper.ba.auto.BaTopicFunnelIndicatorPOMapper;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.mapper.ba.ext.BaTopicFunnelIndicatorPOMapperExt;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ba.BaTopicFunnelIndicatorPO;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ba.BaTopicIndicatorPO;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ba.example.BaTopicFunnelIndicatorPOExample;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.List;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2023/2/28 19:56
 */
@Repository
public class BaFunnelDaoImpl implements BaFunnelDao {

    @Resource
    private BaTopicFunnelIndicatorPOMapper baTopicFunnelIndicatorPOMapper;
    @Resource
    private BaTopicFunnelIndicatorPOMapperExt baTopicFunnelIndicatorPOMapperExt;

    @Override
    public int batchUpdateIndicatorOrder(List<BaTopicFunnelIndicatorPO> funnelIndicatorPOS) {
        funnelIndicatorPOS.stream().forEach(funnelIndicatorPO -> setUpdateInfo(funnelIndicatorPO));
        return baTopicFunnelIndicatorPOMapperExt.batchUpdateIndicatorOrder(funnelIndicatorPOS);
    }

    @Override
    public int batchInsertFunnelIndicator(List<BaTopicFunnelIndicatorPO> funnelIndicatorPOS) {
        funnelIndicatorPOS.stream().forEach(funnelIndicatorPO -> setCreateInfo(funnelIndicatorPO));
        return baTopicFunnelIndicatorPOMapperExt.batchInsertFunnelIndicator(funnelIndicatorPOS);
    }

    @Override
    public int deleteFunnelIndicatorByTopicId(Long topicId) {
        BaTopicFunnelIndicatorPOExample example = new BaTopicFunnelIndicatorPOExample();
        example.createCriteria()
                .andTopicIdEqualTo(topicId);
        return baTopicFunnelIndicatorPOMapper.deleteByExample(example);
    }

    @Override
    public List<BaTopicIndicatorPO> getFunnelByTopicId(Long topicId) {
        return baTopicFunnelIndicatorPOMapperExt.selectFunnelByTopicId(topicId);
    }

    /**
     * 填充创建用户信息
     *
     * @param funnelIndicatorPO
     */
    private void setCreateInfo(BaTopicFunnelIndicatorPO funnelIndicatorPO) {
        funnelIndicatorPO.setIsDelete((short) 0);
        funnelIndicatorPO.setCreatedMis(WutongUserUtils.getUser());
        funnelIndicatorPO.setCreatedTime(TimeUtils.getCurrentJavaDate());
        setUpdateInfo(funnelIndicatorPO);
    }

    /**
     * 填充更新用户信息
     *
     * @param funnelIndicatorPO
     */
    private void setUpdateInfo(BaTopicFunnelIndicatorPO funnelIndicatorPO) {
        funnelIndicatorPO.setLastUpdateMis(WutongUserUtils.getUser());
        funnelIndicatorPO.setUpdateTime(TimeUtils.getCurrentJavaDate());
    }
}
