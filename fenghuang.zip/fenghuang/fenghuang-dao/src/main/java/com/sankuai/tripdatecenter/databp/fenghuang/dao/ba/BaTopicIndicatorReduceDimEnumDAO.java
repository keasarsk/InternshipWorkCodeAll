package com.sankuai.tripdatecenter.databp.fenghuang.dao.ba;

import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ba.BaTopicIndicatorReduceDimEnumPO;

import java.util.List;

/**
 * Description:
 *
 * @author mayuzhe@meituan.com
 * @date 2023/3/1
 */
public interface BaTopicIndicatorReduceDimEnumDAO {
    /**
     * 删除模块下全部指标的降维配置
     *
     * @param moduleId    模块id
     * @param indicatorId 指标id
     */
    void deleteReduceDimEnum(long moduleId, String indicatorId);

    /**
     * 添加降维配置
     *
     * @param reduceDimEnumPO 数据
     * @return
     */
    void insertConfig(BaTopicIndicatorReduceDimEnumPO reduceDimEnumPO);

    List<BaTopicIndicatorReduceDimEnumPO> getReduceDimEnumsList(long moduleId, String indicatorId, String dimId);
}
