package com.sankuai.tripdatecenter.databp.fenghuang.dao.mapper.ext;

import com.sankuai.tripdatecenter.databp.fenghuang.common.domain.request.TmpAppRequestParam;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ext.TmpAppExtPO;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * description 临时应用相关Mapper
 *
 * @author nixuefeng
 * @createTime 2022/4/11 3:47 下午
 */
public interface TmpAppPOMapperExt {

    List<TmpAppExtPO> selectTmpApp(@Param("param") TmpAppRequestParam param);

    TmpAppExtPO selectTmpAppByAppIdAndVersion(@Param("tmpAppId") Long tmpAppId,@Param("version") Long version, @Param("businessId") String businessId);

    Long selectMaxTmpAppVersion(@Param("tmpAppId") Long tmpAppId,  @Param("businessId") String businessId);
}
