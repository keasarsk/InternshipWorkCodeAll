package com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ba;

import java.util.Date;
import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class BaTopicIndicatorPO {
    /**
     * 自增主键
     */
    private Long id;

    /**
     * 报表 id
     */
    private Long reportId;

    /**
     * 主题 id
     */
    private Long topicId;

    /**
     * 指标模块
     */
    private Long moduleId;

    /**
     * 业务线id
     */
    private String businessId;

    /**
     * 指标 id
     */
    private String indicatorId;

    /**
     * 指标别名
     */
    private String indicatorAlias;

    /**
     * 指标标签
     */
    private String indicatorTag;

    /**
     * 值保留小数
     */
    private Integer valueDigit;

    /**
     * 比率值保留小数
     */
    private Integer rateValueDigit;

    /**
     * 值数据格式
     */
    private String valueType;

    /**
     * 比率值数据格式
     */
    private String rateValueType;

    /**
     * 指标排序
     */
    private Integer orderNum;

    /**
     * 应用来源
     */
    private Integer appSource;

    /**
     * 应用ID
     */
    private Long appId;

    /**
     * 数值单位
     */
    private String valueUnit;

    /**
     * 比率值数值单位
     */
    private String rateValueUnit;

    /**
     * 千分位分隔符
     */
    private Short ksSeparation;

    /**
     * 比率红绿规则
     */
    private Short yoyDisplay;

    /**
     * 是关键指标。0否，1是
     */
    private Short isKey;

    /**
     * 是否支持趋势分析。0不支持，1支持
     */
    private Short isTrend;

    /**
     * 开启降维分析。0不开启，1开启
     */
    private Short isDimReduce;

    /**
     * 是否支持明细数据
     */
    private Short isDetail;

    /**
     * 是否删除。0为未删除，1为删除
     */
    private Short isDelete;

    /**
     * 编辑人
     */
    private String createdMis;

    /**
     * 最新编辑人
     */
    private String lastUpdateMis;

    /**
     * 创建时间
     */
    private Date createdTime;

    /**
     * 最后修改时间
     */
    private Date updateTime;
}