package com.sankuai.tripdatecenter.databp.fenghuang.dao;

import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.IndicatorPO;

import java.util.List;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2022/4/24 7:44 下午
 */
public interface IndicatorDao {
    List<IndicatorPO> selectListByTopicId(Long reportId, Long topicId, Long version, String businessId);

    List<IndicatorPO> selectListByTmpAppId(Long tmpAppId, Long version, String businessId);

    List<IndicatorPO> selectListByTmpAppId(List<String> indicatorCodes, Long tmpAppId, Long version, String businessId);

    List<IndicatorPO> selectList(String indicatorCodeOrName, String indicatorId, Integer appType, Long appId, String businessId);

    List<String> selectIndicatorCodeByOnlineApp(List<IndicatorPO> indicators, Long tmpAppId, String businessId);

    boolean isExistIndicator(String indicatorCode, String businessId);

    int batchInsert(List<IndicatorPO> indicatorPOS, String businessId);

    int batchDelete(List<IndicatorPO> indicatorPOS, String businessId);

    int insert(IndicatorPO indicatorPO, String businessId);

    int updateByTmpAppId(IndicatorPO indicatorPO, String businessId);

    int batchUpdateDelete(List<IndicatorPO> needDelete, Long tmpAppId, Long version, String businessId);

    int deleteIndicator(List<String> indicatorIds, String businessId);
}
