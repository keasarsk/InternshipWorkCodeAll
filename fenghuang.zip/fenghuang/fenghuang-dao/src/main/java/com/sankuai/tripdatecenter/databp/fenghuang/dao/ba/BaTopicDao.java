package com.sankuai.tripdatecenter.databp.fenghuang.dao.ba;

import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ba.BaTopicPO;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ba.ext.BaTopicExtPO;

import java.util.List;

/**
 * Description:
 *
 * @author mayuzhe@meituan.com
 * @date 2022/4/11
 */
public interface BaTopicDao {
    /**
     * 查询主题详情
     *
     * @return
     */
    BaTopicExtPO selectByTopicId(Long topicId);

    /**
     * 查询主题列表
     *
     * @return
     */
    List<BaTopicExtPO> selectByReportId(Long reportId, String businessId);

    /**
     * 查询主题配置信息
     * @param topicId
     * @return
     */
    BaTopicPO selectConfigByTopicId(Long topicId);


    /**
     * 新增主题信息
     *
     * @param baTopicPO 数据
     * @return
     */
    int insertBaTopic(BaTopicPO baTopicPO);

    /**
     * 创建主题信息
     *
     * @param baTopicPO 数据
     * @return
     */
    int updateBaTopic(BaTopicExtPO baTopicPO);

}
