package com.sankuai.tripdatecenter.databp.fenghuang.dao;

import com.sankuai.tripdatecenter.databp.fenghuang.common.domain.request.TmpAppRequestParam;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ext.TmpAppExtPO;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.TmpAppPO;

import java.util.List;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2022/4/22 2:10 下午
 */
public interface TmpAppDao {
    List<TmpAppExtPO> selectList(TmpAppRequestParam requestParam);
    TmpAppExtPO selectDetail(Long tmpAppId, Long version, String businessId);
    Long selectMaxVersion(Long tmpAppId, String businessId);
    int updateByIdAndVersion(TmpAppPO tmpAppPO, String businessId);
    int insertTmpApp(TmpAppPO tmpAppPO, String businessId);

}
