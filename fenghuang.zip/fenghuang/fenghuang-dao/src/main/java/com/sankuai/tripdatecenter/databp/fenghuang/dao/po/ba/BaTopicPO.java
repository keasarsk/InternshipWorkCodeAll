package com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ba;

import java.util.Date;
import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class BaTopicPO {
    /**
     * 自增主键
     */
    private Long id;

    /**
     * 业务线id
     */
    private String businessId;

    /**
     * 主题 id
     */
    private Long topicId;

    /**
     * 是否开启漏斗。0为否，1为开启
     */
    private Short isFunnel;

    private Short isPoiSearch;

    /**
     * Poi搜索时对应的维度
     */
    private String poiDimensionId;

    /**
     * 是否开启地域信息（省份-城市）级联筛选器。1：开启
     */
    private Short isLocation;

    /**
     * 是否开启战略等级（战略等级-细分）级联筛选器
     */
    private Short isStrategyRank;

    /**
     * 是否支持Deal搜索
     */
    private Short isDealSearch;

    /**
     * 是否支持供应商搜索
     */
    private Short isPartnerSearch;

    /**
     * 是否开启地域（含大区）组件
     */
    private Short isRegionLocation;

    /**
     * 是否删除。0为未删除，1为删除
     */
    private Short isDelete;

    /**
     * 编辑人
     */
    private String createdMis;

    /**
     * 最新编辑人
     */
    private String lastUpdateMis;

    /**
     * 创建时间
     */
    private Date createdTime;

    /**
     * 最后修改时间
     */
    private Date updateTime;
}