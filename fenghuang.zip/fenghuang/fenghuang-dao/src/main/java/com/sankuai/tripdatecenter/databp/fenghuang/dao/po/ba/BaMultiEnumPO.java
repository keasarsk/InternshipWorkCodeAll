package com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ba;

import java.util.Date;
import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class BaMultiEnumPO {
    /**
     * 自增主键
     */
    private Long id;

    /**
     * 多选配置类型
     */
    private String multiConfigType;

    /**
     * 多选配置key
     */
    private String multiKey;

    /**
     * 多选配置name
     */
    private String multiName;

    /**
     * 是否删除。0为未删除，1为删除
     */
    private Short isDelete;

    /**
     * 编辑人
     */
    private String createdMis;

    /**
     * 最新编辑人
     */
    private String lastUpdateMis;

    /**
     * 创建时间
     */
    private Date createdTime;

    /**
     * 最后修改时间
     */
    private Date updateTime;
}