package com.sankuai.tripdatecenter.databp.fenghuang.dao.ba.impl;

import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.TimeUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.WutongUserUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.ba.BaRelationTopicDimensionEnumDao;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.mapper.ba.auto.BaRelationTopicDimensionEnumPOMapper;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.mapper.ba.ext.BaRelationTopicDimensionEnumPOMapperExt;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ba.BaRelationTopicDimensionEnumPO;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ba.example.BaRelationTopicDimensionEnumPOExample;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ba.ext.BaRelationTopicDimensionEnumExtPO;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.List;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2023/3/3 18:37
 */
@Repository
public class BaRelationTopicDimensionEnumDaoImpl implements BaRelationTopicDimensionEnumDao {
    @Resource
    private BaRelationTopicDimensionEnumPOMapper enumPOMapper;
    @Resource
    private BaRelationTopicDimensionEnumPOMapperExt enumPOMapperExt;

    @Override
    public int batchSaveDimensionRelation(List<BaRelationTopicDimensionEnumPO> relationTopicDimensionEnumPOS) {
        /**
         * 追加初始化信息
         */
        relationTopicDimensionEnumPOS.stream().forEach(po -> setCreateInfo(po));
        return enumPOMapperExt.batchInsertDimensionRelation(relationTopicDimensionEnumPOS);
    }

    @Override
    public int deleteDimensionRelationById(Long topicId, String dimensionId, String businessId) {
        BaRelationTopicDimensionEnumPOExample example = new BaRelationTopicDimensionEnumPOExample();
        example.createCriteria()
                .andBusinessIdEqualTo(businessId)
                .andTopicIdEqualTo(topicId)
                .andDimensionIdEqualTo(dimensionId);
        return enumPOMapper.deleteByExample(example);
    }

    @Override
    public List<BaRelationTopicDimensionEnumExtPO> selectByDimensionId(Long topicId, String dimensionId, String businessId) {
        return enumPOMapperExt.selectExtPOById(topicId, dimensionId, businessId);
    }

    @Override
    public List<BaRelationTopicDimensionEnumExtPO> selectByDimensionEnumCode(Long topicId, String dimensionId, String businessId, String dimensionEnumCode) {
        return enumPOMapperExt.selectExtPOByEnumCode(topicId, dimensionId, businessId, dimensionEnumCode);
    }

    @Override
    public List<BaRelationTopicDimensionEnumExtPO> selectEnumListByRelation(Long topicId, String dimensionId, String enumCode, String relationDimensionId) {
        return enumPOMapperExt.selectRelationEnumList(topicId, dimensionId, enumCode, relationDimensionId);
    }

    private void setCreateInfo(BaRelationTopicDimensionEnumPO relationTopicDimensionEnumPO) {
        relationTopicDimensionEnumPO.setCreatedMis(WutongUserUtils.getUser());
        relationTopicDimensionEnumPO.setCreatedTime(TimeUtils.getCurrentJavaDate());
        relationTopicDimensionEnumPO.setIsDelete((short) 0);
        setUpdateInfo(relationTopicDimensionEnumPO);
    }

    private void setUpdateInfo(BaRelationTopicDimensionEnumPO relationTopicDimensionEnumPO) {
        relationTopicDimensionEnumPO.setLastUpdateMis(WutongUserUtils.getUser());
        relationTopicDimensionEnumPO.setUpdateTime(TimeUtils.getCurrentJavaDate());
    }
}
