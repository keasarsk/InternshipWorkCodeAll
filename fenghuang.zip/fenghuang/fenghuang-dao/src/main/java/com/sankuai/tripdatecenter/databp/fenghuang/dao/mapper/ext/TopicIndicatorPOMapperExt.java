package com.sankuai.tripdatecenter.databp.fenghuang.dao.mapper.ext;

import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ext.TopicIndicatorExtPO;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * Description:
 *
 * @author mayuzhe@meituan.com
 * @date 2022/4/22
 */
public interface TopicIndicatorPOMapperExt {
    List<TopicIndicatorExtPO> selectIndicatorsByRTMIIds(@Param("reportId") Long reportId, @Param("version") Long version, @Param("moduleId") Long moduleId);

    List<String> selectTopicIndicatorsDuplicate(@Param("reportId") Long reportId, @Param("topicId") Long topicId, @Param("version") Long version);

    int insertBatch(@Param("topicIndicators") List<TopicIndicatorExtPO> topicIndicators);
}
