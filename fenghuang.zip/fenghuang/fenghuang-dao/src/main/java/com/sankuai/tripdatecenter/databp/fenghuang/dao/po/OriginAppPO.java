package com.sankuai.tripdatecenter.databp.fenghuang.dao.po;

import java.util.Date;
import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class OriginAppPO {
    /**
     * 自增主键
     */
    private Long id;

    /**
     * 版本号。固定:1
     */
    private Long version;

    /**
     * 起源应用id
     */
    private Integer appId;

    /**
     * 起源应用名称
     */
    private String appName;

    /**
     * 备注
     */
    private String appComment;

    /**
     * 数据源DSN
     */
    private String dsn;

    /**
     * 是否删除。0为未删除，1为删除
     */
    private Long isDelete;

    /**
     * 编辑人
     */
    private String createdMis;

    /**
     * 最新编辑人
     */
    private String lastUpdateMis;

    /**
     * 创建时间
     */
    private Date createdTime;

    /**
     * 最后修改时间
     */
    private Date updateTime;
}