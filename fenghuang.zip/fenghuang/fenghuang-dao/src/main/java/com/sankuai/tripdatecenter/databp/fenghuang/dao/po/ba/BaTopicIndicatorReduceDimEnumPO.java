package com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ba;

import java.util.Date;
import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class BaTopicIndicatorReduceDimEnumPO {
    /**
     * 自增主键
     */
    private Long id;

    /**
     * 报表 id
     */
    private Long reportId;

    /**
     * 主题 id
     */
    private Long topicId;

    /**
     * 指标模块
     */
    private Long moduleId;

    /**
     * 业务线id
     */
    private String businessId;

    /**
     * 指标id
     */
    private String indicatorId;

    /**
     * 维度id
     */
    private String dimensionId;

    /**
     * 维度name
     */
    private String dimensionName;

    /**
     * 维度枚举code
     */
    private String dimensionEnumCode;

    /**
     * 维度枚举alias
     */
    private String dimensionEnumAlias;

    /**
     * 排序
     */
    private Integer orderNum;

    /**
     * 是否删除。0为未删除，1为删除
     */
    private Short isDelete;

    /**
     * 编辑人
     */
    private String createdMis;

    /**
     * 最新编辑人
     */
    private String lastUpdateMis;

    /**
     * 创建时间
     */
    private Date createdTime;

    /**
     * 最后修改时间
     */
    private Date updateTime;
}