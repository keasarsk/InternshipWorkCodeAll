package com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ext;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class OrgAreaExtPO {

    private Integer bizUnitId;

    private String  bizUnitName;

    private Integer regionId;

    private String regionName;

    private Integer subRegionId;

    private String subRegionName;

    private Integer groupId;

    private String groupName;

    private Integer cityId;

    private String cityName;

}