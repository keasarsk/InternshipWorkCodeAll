package com.sankuai.tripdatecenter.databp.fenghuang.dao.ba.impl;

import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.TimeUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.WutongUserUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.ba.BaTopicIndicatorMultiConfigDAO;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.mapper.ba.auto.BaTopicIndicatorMultiConfigPOMapper;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ba.BaTopicIndicatorMultiConfigPO;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ba.example.BaTopicIndicatorMultiConfigPOExample;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.Date;
import java.util.List;

/**
 * Description:
 *
 * @author mayuzhe@meituan.com
 * @date 2023/3/1
 */
@Repository
public class BaTopicIndicatorMultiConfigDAOImpl implements BaTopicIndicatorMultiConfigDAO {
    @Resource
    private BaTopicIndicatorMultiConfigPOMapper baTopicIndicatorMultiConfigPOMapper;

    @Override
    public void deleteConfigs(long moduleId, String indicatorId, String multiType) {
        BaTopicIndicatorMultiConfigPOExample example = this.createCommonExample();
        example.getOredCriteria().get(0)
                .andModuleIdEqualTo(moduleId)
                .andIndicatorIdEqualTo(indicatorId)
                .andMultiConfigTypeEqualTo(multiType);
        baTopicIndicatorMultiConfigPOMapper.deleteByExample(example);
    }

    @Override
    public void insertConfig(BaTopicIndicatorMultiConfigPO multiConfigPO) {
        this.setDefaultValue(multiConfigPO);
        baTopicIndicatorMultiConfigPOMapper.insertSelective(multiConfigPO);
    }

    @Override
    public void deleteIndicator(long moduleId, String indicatorId) {
        BaTopicIndicatorMultiConfigPOExample example = this.createCommonExample();
        example.getOredCriteria().get(0)
                .andModuleIdEqualTo(moduleId)
                .andIndicatorIdEqualTo(indicatorId);
        baTopicIndicatorMultiConfigPOMapper.deleteByExample(example);
    }

    @Override
    public List<BaTopicIndicatorMultiConfigPO> getIndicatorMultiConfig(long moduleId, String indicatorId, String multiType) {
        BaTopicIndicatorMultiConfigPOExample example = this.createCommonExample();
        example.getOredCriteria().get(0)
                .andModuleIdEqualTo(moduleId)
                .andIndicatorIdEqualTo(indicatorId)
                .andMultiConfigTypeEqualTo(multiType);
        List<BaTopicIndicatorMultiConfigPO> configPOS = baTopicIndicatorMultiConfigPOMapper.selectByExample(example);
        if(configPOS == null){
            return Collections.EMPTY_LIST;
        }
        return configPOS;
    }

    /**
     * 创建公共 example
     *
     * @return
     */
    private BaTopicIndicatorMultiConfigPOExample createCommonExample() {
        BaTopicIndicatorMultiConfigPOExample example = new BaTopicIndicatorMultiConfigPOExample();
        BaTopicIndicatorMultiConfigPOExample.Criteria criteria = example.createCriteria();
        criteria.andIsDeleteEqualTo((short) 0);
        example.setOrderByClause("order_num asc");
        return example;
    }

    private void setDefaultValue(BaTopicIndicatorMultiConfigPO multiConfigPO) {
        Date curDate = TimeUtils.getCurrentJavaDate();
        String mis = WutongUserUtils.getFhUserInfo().getMisId();
        multiConfigPO.setCreatedMis(mis);
        multiConfigPO.setLastUpdateMis(mis);
        multiConfigPO.setUpdateTime(curDate);
        multiConfigPO.setCreatedTime(curDate);
        multiConfigPO.setIsDelete((short) 0);
    }
}
