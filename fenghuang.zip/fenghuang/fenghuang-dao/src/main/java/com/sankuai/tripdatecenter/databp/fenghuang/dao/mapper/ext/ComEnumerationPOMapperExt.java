package com.sankuai.tripdatecenter.databp.fenghuang.dao.mapper.ext;


import com.dianping.zebra.dao.datasource.ZebraRouting;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ext.ComEnumerationExtPO;
import org.apache.ibatis.annotations.Param;

import java.util.List;


@ZebraRouting("dataSource_mysql_data_center_data")
public interface ComEnumerationPOMapperExt {

    List<ComEnumerationExtPO> queryEnumByDimensionIds(@Param("dimensionIds")List<String> dimensionIds);

}