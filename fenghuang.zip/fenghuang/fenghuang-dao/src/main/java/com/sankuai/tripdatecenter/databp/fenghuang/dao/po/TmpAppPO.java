package com.sankuai.tripdatecenter.databp.fenghuang.dao.po;

import java.util.Date;
import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class TmpAppPO {
    /**
     * 自增主键
     */
    private Long id;

    /**
     * 临时应用id
     */
    private Long tmpappId;

    /**
     * 版本号。格式 yyyyMMddHHmmss
     */
    private Long version;

    /**
     * 临时应用名称
     */
    private String tmpappName;

    /**
     * 数据源（查询引擎）
     */
    private Long datasourceId;

    /**
     * 定义
     */
    private String definitionInfo;

    /**
     * 用途
     */
    private String useInfo;

    /**
     * 备注
     */
    private String tmpappComment;

    /**
     * 是否在线。0为下线，1为在线
     */
    private Short isOnline;

    /**
     * 是否删除。0为未删除，1为删除
     */
    private Short isDelete;

    /**
     * 编辑人
     */
    private String createdMis;

    /**
     * 最新编辑人
     */
    private String lastUpdateMis;

    /**
     * 创建时间
     */
    private Date createdTime;

    /**
     * 最后修改时间
     */
    private Date updateTime;

    private String tableName;

    private Integer tmpappType;

    /**
     * 业务线ID
     */
    private String businessId;

    /**
     * sql模板
     */
    private String sqlTemplate;
}