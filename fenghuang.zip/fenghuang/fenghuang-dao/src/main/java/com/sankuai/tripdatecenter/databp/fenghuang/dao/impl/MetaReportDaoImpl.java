package com.sankuai.tripdatecenter.databp.fenghuang.dao.impl;

import com.sankuai.tripdatecenter.databp.fenghuang.common.enums.DeleteStatusEnum;
import com.sankuai.tripdatecenter.databp.fenghuang.common.enums.OnlineStatusEnum;
import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.TimeUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.WutongUserUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.MetaReportDao;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.mapper.auto.MetaReportPOMapper;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.MetaReportPO;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.example.MetaReportPOExample;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.List;

import static com.sankuai.tripdatecenter.databp.fenghuang.common.constant.NumberConstant.ZERO;
import static com.sankuai.tripdatecenter.databp.fenghuang.common.constant.SymbolConstant.PERCENT;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2022/9/22 20:01
 */
@Repository
public class MetaReportDaoImpl implements MetaReportDao {
    @Resource
    private MetaReportPOMapper metaReportPOMapper;

    @Override
    public List<MetaReportPO> selectList(MetaReportPO metaReportPO) {
        MetaReportPOExample example = new MetaReportPOExample();
        MetaReportPOExample.Criteria criteria = example.createCriteria();
        criteria.andIsDeleteEqualTo(DeleteStatusEnum.NOT_DELETED.getCode());
        if (metaReportPO.getCreatedMis() != null) {
            criteria.andCreatedMisEqualTo(metaReportPO.getCreatedMis());
        }
        if (metaReportPO.getReportId() != null) {
            criteria.andReportIdEqualTo(metaReportPO.getReportId());
        }
        if (metaReportPO.getVersion() != null) {
            criteria.andVersionEqualTo(metaReportPO.getVersion());
        }
        if (metaReportPO.getReportName() != null) {
            String reportName = PERCENT.concat(metaReportPO.getReportName()).concat(PERCENT);
            criteria.andReportNameLike(reportName);
        }
        if (metaReportPO.getIsOnline() != null) {
            criteria.andIsOnlineEqualTo(metaReportPO.getIsOnline());
        }
        List<MetaReportPO> reportPOS = metaReportPOMapper.selectByExample(example);
        if(reportPOS == null){
            return Collections.EMPTY_LIST;
        }
        return reportPOS;
    }

    @Override
    public Short selectMaxVersion(String reportId, String topicId) {
        MetaReportPOExample example = new MetaReportPOExample();
        MetaReportPOExample.Criteria criteria = example.createCriteria();
        criteria.andReportIdEqualTo(reportId);
        criteria.andTopicIdEqualTo(topicId);
        example.setOrderByClause("version desc limit 1");
        List<MetaReportPO> metaReportPOS = metaReportPOMapper.selectByExample(example);
        if(CollectionUtils.isEmpty(metaReportPOS)){
            return null;
        }else {
            return metaReportPOS.stream().findFirst().get().getVersion();
        }
    }

    @Override
    public int insertMetaReport(MetaReportPO metaReportPO) {
        setCreateInfo(metaReportPO);
        return metaReportPOMapper.insertSelective(metaReportPO);
    }

    @Override
    public int updateByIdAndVersion(MetaReportPO metaReportPO) {
        setUpdateInfo(metaReportPO);
        MetaReportPOExample example = new MetaReportPOExample();
        MetaReportPOExample.Criteria criteria = example.createCriteria();
        criteria.andReportIdEqualTo(metaReportPO.getReportId());
        criteria.andTopicIdEqualTo(metaReportPO.getTopicId());
        criteria.andVersionEqualTo(metaReportPO.getVersion());
        return metaReportPOMapper.updateByExampleSelective(metaReportPO, example);
    }

    @Override
    public Short getOnlineVersion(String reportId) {
        MetaReportPOExample example = new MetaReportPOExample();
        MetaReportPOExample.Criteria criteria = example.createCriteria();
        criteria.andIsDeleteEqualTo(DeleteStatusEnum.NOT_DELETED.getCode());
        criteria.andReportIdEqualTo(reportId);
        criteria.andIsOnlineEqualTo(OnlineStatusEnum.ONLINE.getCode());
        List<MetaReportPO> reportPOS = metaReportPOMapper.selectByExample(example);
        if(CollectionUtils.isEmpty(reportPOS)){
            return null;
        }else if(reportPOS.size() > 1){
            throw new RuntimeException("online version should be only 1. reportId : " + reportId);
        }else {
            return reportPOS.get(0).getVersion();
        }
    }

    private void setCreateInfo(MetaReportPO metaReportPO){
        metaReportPO.setIsOnline(OnlineStatusEnum.OFFLINE.getCode());
        metaReportPO.setCreatedMis(WutongUserUtils.getUser());
        metaReportPO.setCreatedTime(TimeUtils.getCurrentJavaDate());
        metaReportPO.setIsDelete(DeleteStatusEnum.NOT_DELETED.getCode());
        setUpdateInfo(metaReportPO);
    }

    private void setUpdateInfo(MetaReportPO metaReportPO){
        metaReportPO.setUpdateTime(TimeUtils.getCurrentJavaDate());
        metaReportPO.setUpdateMis(WutongUserUtils.getUser());
    }
}
