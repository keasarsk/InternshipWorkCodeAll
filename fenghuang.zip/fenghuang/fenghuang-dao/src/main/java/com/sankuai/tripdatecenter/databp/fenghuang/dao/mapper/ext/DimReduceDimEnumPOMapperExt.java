package com.sankuai.tripdatecenter.databp.fenghuang.dao.mapper.ext;

import org.apache.ibatis.annotations.Param;

public interface DimReduceDimEnumPOMapperExt {

    int deleteTopicIndicatorDimReduce(@Param("reportId") Long reportId, @Param("topicId") Long topicId, @Param("version") Long version, @Param("indicatorId") String indicatorId);

}