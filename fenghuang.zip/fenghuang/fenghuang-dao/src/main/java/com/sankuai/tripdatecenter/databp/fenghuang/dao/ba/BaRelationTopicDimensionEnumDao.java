package com.sankuai.tripdatecenter.databp.fenghuang.dao.ba;

import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ba.BaRelationTopicDimensionEnumPO;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ba.ext.BaRelationTopicDimensionEnumExtPO;

import java.util.List;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2023/3/3 17:18
 */
public interface BaRelationTopicDimensionEnumDao {

    int batchSaveDimensionRelation(List<BaRelationTopicDimensionEnumPO> relationTopicDimensionEnumPOS);

    int deleteDimensionRelationById(Long topicId, String dimensionId, String businessId);

    List<BaRelationTopicDimensionEnumExtPO> selectByDimensionId(Long topicId, String dimensionId, String businessId);

    List<BaRelationTopicDimensionEnumExtPO> selectByDimensionEnumCode(Long topicId, String dimensionId, String businessId, String dimensionEnumCode);

    List<BaRelationTopicDimensionEnumExtPO> selectEnumListByRelation(Long topicId, String dimensionId, String enumCode, String relationDimensionId);
}
