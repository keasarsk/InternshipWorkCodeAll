package com.sankuai.tripdatecenter.databp.fenghuang.dao.po;

import java.util.Date;
import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class BusinessLinePO {
    private Long id;

    private String businessId;

    private String businessName;

    private Long isDelete;

    private String createdMis;

    private String lastUpdateMis;

    private Date createdTime;

    private Date updateTime;

    private Integer originBusiLineId;

    private String originAdminMis;
}