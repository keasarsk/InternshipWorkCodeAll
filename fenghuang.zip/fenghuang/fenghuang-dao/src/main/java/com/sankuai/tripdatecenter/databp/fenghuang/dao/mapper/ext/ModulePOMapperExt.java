package com.sankuai.tripdatecenter.databp.fenghuang.dao.mapper.ext;

import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ModulePO;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.TopicPO;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * description 报表相关Mapper
 *
 * @author nixuefeng
 * @createTime 2022/4/19 8:04 下午
 */
public interface ModulePOMapperExt {
    Integer selectMaxOrderNum(@Param("topicId") Long topicId, @Param("version") Long version);

    void updateModuleOrderBatch(@Param("modules") List<ModulePO> modules);

}
