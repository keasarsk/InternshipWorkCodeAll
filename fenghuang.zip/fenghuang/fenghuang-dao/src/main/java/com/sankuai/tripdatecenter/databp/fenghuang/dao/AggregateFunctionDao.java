package com.sankuai.tripdatecenter.databp.fenghuang.dao;

import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.AggregateFunctionPO;

import java.util.List;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2022/7/4 4:10 下午
 */
public interface AggregateFunctionDao {
    /**
     * 查询聚合方式集合
     *
     * @return
     */
    List<AggregateFunctionPO> selectAggregateFunctionList();
}
