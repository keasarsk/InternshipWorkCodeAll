package com.sankuai.tripdatecenter.databp.fenghuang.dao.ba;

import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ba.BaTopicFunnelIndicatorPO;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ba.BaTopicIndicatorPO;

import java.util.List;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2023/2/28 19:52
 */
public interface BaFunnelDao {
    /**
     * 批量更新指标顺序
     *
     * @param funnelIndicatorPOS
     * @return
     */
    int batchUpdateIndicatorOrder(List<BaTopicFunnelIndicatorPO> funnelIndicatorPOS);

    /**
     * 批量存储漏斗图指标信息
     *
     * @param funnelIndicatorPOS
     * @return
     */
    int batchInsertFunnelIndicator(List<BaTopicFunnelIndicatorPO> funnelIndicatorPOS);

    /**
     * 删除历史漏斗图指标配置
     * @param topicId 主题id
     * @return
     */
    int deleteFunnelIndicatorByTopicId(Long topicId);

    /**
     * 根据TopicId获取漏斗图指标
     * @param topicId
     * @return
     */
    List<BaTopicIndicatorPO> getFunnelByTopicId(Long topicId);
}
