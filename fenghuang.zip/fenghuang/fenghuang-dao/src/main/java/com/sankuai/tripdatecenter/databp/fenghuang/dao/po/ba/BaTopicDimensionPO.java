package com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ba;

import java.util.Date;
import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class BaTopicDimensionPO {
    /**
     * 自增主键
     */
    private Long id;

    /**
     * 维度 id
     */
    private String dimensionId;

    /**
     * 主题id
     */
    private Long topicId;

    /**
     * 业务线id
     */
    private String businessId;

    /**
     * 报表 id
     */
    private Long reportId;

    /**
     * 筛选器排序
     */
    private Integer orderNum;

    /**
     * 筛选器类型
     */
    private String compType;

    /**
     * 维度别名
     */
    private String dimensionAlias;

    /**
     * 是否删除。0为未删除，1为删除
     */
    private Short isDelete;

    /**
     * 编辑人
     */
    private String createdMis;

    /**
     * 最新编辑人
     */
    private String lastUpdateMis;

    /**
     * 创建时间
     */
    private Date createdTime;

    /**
     * 最后修改时间
     */
    private Date updateTime;
}