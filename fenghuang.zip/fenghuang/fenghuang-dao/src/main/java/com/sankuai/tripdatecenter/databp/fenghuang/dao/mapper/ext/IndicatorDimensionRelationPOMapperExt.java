package com.sankuai.tripdatecenter.databp.fenghuang.dao.mapper.ext;

import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.IndicatorDimensionRelationPO;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2022/4/25 4:41 下午
 */
public interface IndicatorDimensionRelationPOMapperExt {
    int insertBatch(@Param("relations") List<IndicatorDimensionRelationPO> relations);
}
