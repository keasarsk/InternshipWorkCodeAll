package com.sankuai.tripdatecenter.databp.fenghuang.dao;

import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.IndicatorDimensionRelationPO;

import java.util.List;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2022/4/24 4:40 下午
 */
public interface IndicatorDimensionRelationDao {
    List<IndicatorDimensionRelationPO> selectListById(Long reportId, Long topicId, String dimensionId, Long version);
    int insertRelation(IndicatorDimensionRelationPO indicatorDimensionRelation);
    int insertRelations(List<IndicatorDimensionRelationPO> indicatorDimensionRelations);
    int deleteRelation(IndicatorDimensionRelationPO indicatorDimensionRelation);
    int deleteRelationByTopicId(Long reportId, Long topicId, String dimensionId, Long version);
}
