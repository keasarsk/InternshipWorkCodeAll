package com.sankuai.tripdatecenter.databp.fenghuang.dao.po;

import java.util.Date;
import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class TmpappFieldMapping {
    private Long id;

    private String indDimCode;

    private String fieldName;

    private Long appId;

    private Long isDelete;

    private String createdMis;

    private String lastUpdateMis;

    private Date createdTime;

    private Date updateTime;
}