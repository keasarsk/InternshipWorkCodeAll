package com.sankuai.tripdatecenter.databp.fenghuang.dao.po;

import java.util.Date;
import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class TaskPO {
    private Long id;

    private Short taskType;

    private String taskName;

    private String taskTopic;

    /**
     * 计划运行时间
     */
    private String planExecTime;

    private Date createTime;

    private String createMis;

    private Short status;

    private Short isDelete;

    private String taskConfig;
}