package com.sankuai.tripdatecenter.databp.fenghuang.dao;

import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.MetaReportPO;

import java.util.List;

/**
 * description 凤凰定制化报表元数据配置
 *
 * @author nixuefeng
 * @createTime 2022/9/22 19:58
 */
public interface MetaReportDao {
    List<MetaReportPO> selectList(MetaReportPO metaReportPO);

    Short selectMaxVersion(String reportId, String topicId);

    int insertMetaReport(MetaReportPO metaReportPO);

    int updateByIdAndVersion(MetaReportPO metaReportPO);

    Short getOnlineVersion(String reportId);
}
