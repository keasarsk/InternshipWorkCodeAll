package com.sankuai.tripdatecenter.databp.fenghuang.dao.ba.impl;

import com.sankuai.tripdatecenter.databp.fenghuang.common.enums.DeleteStatusEnum;
import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.TimeUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.WutongUserUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.ba.BaIndicatorDimensionRelationDao;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.mapper.ba.auto.BaRelationIndicatorDimensionPOMapper;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.mapper.ba.ext.BaRelationIndicatorDimensionPOMapperExt;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.IndicatorDimensionRelationPO;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ba.BaRelationIndicatorDimensionPO;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ba.example.BaRelationIndicatorDimensionPOExample;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.example.IndicatorDimensionRelationPOExample;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.List;

/**
 * Description:
 *
 * @author mayuzhe@meituan.com
 * @date 2023/3/2
 */
@Repository
public class BaIndicatorDimensionRelationDaoImpl implements BaIndicatorDimensionRelationDao {
    @Resource
    private BaRelationIndicatorDimensionPOMapper baRelationIndicatorDimensionPOMapper;
    @Resource
    private BaRelationIndicatorDimensionPOMapperExt baRelationIndicatorDimensionPOMapperExt;

    @Override
    public int deleteRelationByTopicId(Long reportId, Long topicId, String dimensionId) {
        BaRelationIndicatorDimensionPOExample example = new BaRelationIndicatorDimensionPOExample();
        example.createCriteria()
                .andReportIdEqualTo(reportId)
                .andTopicIdEqualTo(topicId)
                .andDimensionIdEqualTo(dimensionId);
        return baRelationIndicatorDimensionPOMapper.deleteByExample(example);
    }

    @Override
    public int insertRelations(List<BaRelationIndicatorDimensionPO> baRelationIndicatorDimensionPOS) {
        baRelationIndicatorDimensionPOS.forEach(this::setCreateInfo);
        return baRelationIndicatorDimensionPOMapperExt.insertBatch(baRelationIndicatorDimensionPOS);
    }

    @Override
    public List<BaRelationIndicatorDimensionPO> selectListById(Long reportId, Long topicId, String dimensionId) {
        BaRelationIndicatorDimensionPOExample example = new BaRelationIndicatorDimensionPOExample();
        example.createCriteria()
                .andReportIdEqualTo(reportId)
                .andTopicIdEqualTo(topicId)
                .andDimensionIdEqualTo(dimensionId)
                .andIsDeleteEqualTo(DeleteStatusEnum.NOT_DELETED.getCode());
        List<BaRelationIndicatorDimensionPO> baRelationIndicatorDimensionPOS = baRelationIndicatorDimensionPOMapper.selectByExample(example);
        if(baRelationIndicatorDimensionPOS == null){
            return Collections.EMPTY_LIST;
        }
        return baRelationIndicatorDimensionPOS;
    }

    @Override
    public List<BaRelationIndicatorDimensionPO> selectListByTopicId(Long topicId) {
        BaRelationIndicatorDimensionPOExample example = new BaRelationIndicatorDimensionPOExample();
        example.createCriteria()
                .andTopicIdEqualTo(topicId)
                .andIsDeleteEqualTo(DeleteStatusEnum.NOT_DELETED.getCode());
        List<BaRelationIndicatorDimensionPO> baRelationIndicatorDimensionPOS = baRelationIndicatorDimensionPOMapper.selectByExample(example);
        if(baRelationIndicatorDimensionPOS == null){
            return Collections.EMPTY_LIST;
        }
        return baRelationIndicatorDimensionPOS;
    }

    private void setCreateInfo(BaRelationIndicatorDimensionPO baRelationIndicatorDimensionPO){
        baRelationIndicatorDimensionPO.setCreatedMis(WutongUserUtils.getUser());
        baRelationIndicatorDimensionPO.setCreatedTime(TimeUtils.getCurrentJavaDate());
        baRelationIndicatorDimensionPO.setIsDelete(DeleteStatusEnum.NOT_DELETED.getCode());
        setUpdateInfo(baRelationIndicatorDimensionPO);
    }

    private void setUpdateInfo(BaRelationIndicatorDimensionPO baRelationIndicatorDimensionPO){
        baRelationIndicatorDimensionPO.setLastUpdateMis(WutongUserUtils.getUser());
        baRelationIndicatorDimensionPO.setUpdateTime(TimeUtils.getCurrentJavaDate());
    }
}
