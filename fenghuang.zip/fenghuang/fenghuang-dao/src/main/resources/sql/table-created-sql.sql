-- 数据源信息表
create table fenghuang_info_datasource
(
    id                bigint           not null comment '自增主键'
        primary key,
    datasource_id     bigint           not null comment '数据源 id',
    datasource_name   varchar(100)     not null comment '数据源名字',
    datasource_type   varchar(20)      not null comment '数据源类型。MySQL、Doris、Kylin、ES',
    jdbc_url          varchar(100)     not null comment '连接地址',
    username          varchar(20)      null comment '用户名',
    psw               varchar(50)      null comment 'psw',
    driver_class_name varchar(50)      null comment '驱动类',
    params            json             null comment '参数配置',
    is_delete         smallint default 0 not null comment '是否删除。0为未删除，1为删除',
    created_mis       varchar(50)      not null comment '编辑人',
    last_update_mis   varchar(30)      not null comment '最新编辑人',
    created_time      datetime         not null comment '创建时间',
    update_time       datetime         not null comment '最后修改时间',
    constraint fenghuang_info_datasource_datasource_id_uindex
        unique (datasource_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    comment '数据源信息表';

-- 维度信息表
create table fenghuang_info_dimension
(
    id                bigint           not null comment '自增主键'
        primary key,
    dimension_id      varchar(55)      not null comment '维度 id',
    version           bigint(14)       not null comment '版本号。格式 yyyyMMddHHmmss',
    app_id            bigint           not null comment '应用 id',
    app_type          char default '1' not null comment '应用类型。起源1，临时应用2。默认为1',
    dimension_code    varchar(50)      not null comment '维度 code',
    dimension_name    varchar(50)      not null comment '维度名',
    dimension_type    varchar(30)      not null comment '维度类型',
    dimension_comment varchar(500)     null comment '维度注释',
    is_delete         smallint default 0 not null comment '是否删除。0为未删除，1为删除',
    created_mis       varchar(50)      not null comment '编辑人',
    last_update_mis   varchar(30)      not null comment '最新编辑人',
    created_time      datetime         not null comment '创建时间',
    update_time       datetime         not null comment '最后修改时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    comment '维度信息表';

-- 指标信息表
create table fenghuang_info_indicator
(
    id                 bigint           not null comment '自增主键'
        primary key,
    indicator_id       varchar(55)      not null comment '指标 id。指标 code + appType。',
    version            bigint(14)       not null comment '版本号。格式 yyyyMMddHHmmss',
    app_id             bigint           not null comment '应用 id',
    app_type           char             not null comment '应用类型。起源1，临时应用2。',
    indicator_code     varchar(50)      not null comment '指标 code',
    indicator_name     varchar(50)      not null comment '指标名',
    indicator_type     varchar(30)      not null comment '指标类型',
    aggregate_function varchar(30)      not null comment '聚合方式',
    indicator_comment  varchar(500)     null comment '指标注释',
    is_delete          smallint default 0 not null comment '是否删除。0为未删除，1为删除',
    created_mis        varchar(50)      not null comment '编辑人',
    last_update_mis    varchar(30)      not null comment '最新编辑人',
    created_time       datetime         not null comment '创建时间',
    update_time        datetime         not null comment '最后修改时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    comment '指标信息表';

-- 模块信息表
create table fenghuang_info_module
(
    id              bigint           not null comment '自增主键'
        primary key,
    module_id       bigint           not null comment '主题 id',
    version         bigint(14)       not null comment '版本号。格式 yyyyMMddHHmmss',
    report_id       bigint           not null comment '报表 id',
    topic_id        bigint           not null comment '主题 id',
    module_name     varchar(50)      not null comment '模块名称',
    order_num       int              not null comment '排序',
    is_delete       smallint default 0 not null comment '是否删除。0为未删除，1为删除',
    created_mis     varchar(50)      not null comment '编辑人',
    last_update_mis varchar(30)      not null comment '最新编辑人',
    created_time    datetime         not null comment '创建时间',
    update_time     datetime         not null comment '最后修改时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    comment '模块信息表';

-- 报表信息表
create table fenghuang_info_report
(
    id              bigint           not null comment '自增主键'
        primary key,
    report_id       bigint           not null comment '报表 id',
    version         bigint(14)       not null comment '版本号。格式 yyyyMMddHHmmss',
    report_name     varchar(50)      not null comment '报表名称',
    is_online       smallint default 0 not null comment '是否在线。0为下线，1为在线',
    is_delete       smallint default 0 not null comment '是否删除。0为未删除，1为删除',
    created_mis     varchar(50)      not null comment '编辑人',
    last_update_mis varchar(30)      not null comment '最新编辑人',
    created_time    datetime         not null comment '创建时间',
    update_time     datetime         not null comment '最后修改时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    comment '报表信息表';

-- 模板信息表
create table fenghuang_info_template
(
    id              bigint           not null comment '自增主键'
        primary key,
    template_id     bigint           not null comment '模板 id',
    version         bigint(14)       not null comment '版本号。格式 yyyyMMddHHmmss',
    template_code   varchar(50)      not null comment '模板 code',
    template_name   varchar(50)      not null comment '模板名称',
    is_online       smallint default 0 not null comment '是否在线。0为下线，1为在线',
    is_delete       smallint default 0 not null comment '是否删除。0为未删除，1为删除',
    created_mis     varchar(50)      not null comment '编辑人',
    last_update_mis varchar(30)      not null comment '最新编辑人',
    created_time    datetime         not null comment '创建时间',
    update_time     datetime         not null comment '最后修改时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    comment '模板信息表';

-- 临时应用信息表
create table fenghuang_info_tmpapp
(
    id              bigint auto_increment comment '自增主键'
        primary key,
    tmpapp_id       bigint             not null comment '临时应用id',
    version         bigint(14)         not null comment '版本号。格式 yyyyMMddHHmmss',
    tmpapp_name     varchar(50)        not null comment '临时应用名称',
    datasource_id   bigint             not null comment '数据源（查询引擎）',
    definition_info varchar(500)       null comment '定义',
    use_info        varchar(500)       null comment '用途',
    tmpapp_comment  varchar(500)       null comment '备注',
    sql_template    varchar(10000)     not null comment 'sql模板',
    is_online       smallint default 0 not null comment '是否在线。0为下线，1为在线',
    is_delete       smallint default 0 not null comment '是否删除。0为未删除，1为删除',
    created_mis     varchar(30)        not null comment '编辑人',
    last_update_mis varchar(30)        not null comment '最新编辑人',
    created_time    datetime           not null comment '创建时间',
    update_time     datetime           not null comment '最后修改时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    comment '临时应用信息表';

-- 主题信息表
create table fenghuang_info_topic
(
    id              bigint           not null comment '自增主键'
        primary key,
    topic_id        bigint           not null comment '主题 id',
    version         bigint(14)       not null comment '版本号。格式 yyyyMMddHHmmss',
    report_id       bigint           not null comment '报表 id',
    topic_name      varchar(50)      not null comment '主题名称',
    order_num       int              not null comment '排序',
    is_online       smallint default 0 not null comment '是否在线。0为下线，1为在线',
    is_delete       smallint default 0 not null comment '是否删除。0为未删除，1为删除',
    created_mis     varchar(50)      not null comment '编辑人',
    last_update_mis varchar(30)      not null comment '最新编辑人',
    created_time    datetime         not null comment '创建时间',
    update_time     datetime         not null comment '最后修改时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    comment '主题信息表';

-- 主题维度信息表
create table fenghuang_info_topic_dimension
(
    id              bigint           not null comment '自增主键'
        primary key,
    dimension_id    varchar(55)            not null comment '维度 id',
    report_id       bigint           not null comment '报表 id',
    version         bigint(14)       not null comment '版本号。格式 yyyyMMddHHmmss',
    topic_id        bigint           not null comment '主题 id',
    is_delete       smallint default 0 not null comment '是否删除。0为未删除，1为删除',
    created_mis     varchar(50)      not null comment '编辑人',
    last_update_mis varchar(30)      not null comment '最新编辑人',
    created_time    datetime         not null comment '创建时间',
    update_time     datetime         not null comment '最后修改时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    comment '主题维度信息表';

-- 主题指标信息表
create table fenghuang_info_topic_indicator
(
    id                     bigint auto_increment comment '自增主键'
        primary key,
    cur_id                 bigint                       not null comment '当前 id',
    parent_id              bigint                       not null comment '父节点 id。为 cur_id。根节点父 id 为 -1。',
    report_id              bigint                       not null comment '报表 id',
    version                bigint(14)                   not null comment '版本号。格式 yyyyMMddHHmmss',
    topic_id               bigint                       not null comment '主题 id',
    module_id              bigint                       not null comment '模块 id',
    indicator_id           varchar(55)                  not null comment '指标 id',
    indicator_alias        varchar(50) default ''       not null comment '指标别名',
    indicator_tag          varchar(50) default ''       not null comment '指标标签',
    value_digit            int         default 0        not null comment '值保留小数。默认值0',
    value_type             varchar(20) default 'String' not null comment '值数据格式',
    rate_value_digit       int         default 0        not null comment '比率值保留小数。默认值0',
    rate_value_type        varchar(20) default 'String' not null comment '比率值数据格式',
    is_has_completion_rate char        default '0'      not null comment '是否含有完成率。0没有，1有。默认 0',
    node_level             int         default 1        not null comment '节点深度。从1开始',
    order_num              int                          not null comment '排序',
    is_online              smallint    default 0        not null comment '是否在线。0为下线，1为在线',
    is_delete              smallint    default 0        not null comment '是否删除。0为未删除，1为删除',
    created_mis            varchar(50)                  not null comment '编辑人',
    last_update_mis        varchar(50)                  not null comment '最新编辑人',
    created_time           datetime                     not null comment '创建时间',
    update_time            datetime                     not null comment '最后修改时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    comment '主题指标信息表';

-- 指标支持维度配置表
create table fenghuang_relation_indicator_dimension
(
    id              bigint           not null comment '自增主键'
        primary key,
    report_id       bigint           not null comment '关联的报表id',
    version         bigint(14)       not null comment '版本号。格式 yyyyMMddHHmmss',
    topic_id        bigint           not null comment '主题 id',
    dimension_type  varchar(30)           not null comment '维度类型',
    dimension_id    varchar(55)      not null comment '维度 id',
    indicator_id    varchar(55)      not null comment '指标 id',
    is_delete       smallint default 0 not null comment '是否删除。0为未删除，1为删除',
    created_mis     varchar(50)      not null comment '编辑人',
    last_update_mis varchar(30)      not null comment '最新编辑人',
    created_time    datetime         not null comment '创建时间',
    update_time     datetime         not null comment '最后修改时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    comment '指标支持维度配置表';

-- 起源应用信息表
REATE TABLE `fenghuang_info_origin_app` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `version` bigint(14) NOT NULL COMMENT '版本号。固定:1',
  `app_id` bigint(20) NOT NULL COMMENT '起源应用id',
  `app_name` varchar(50) CHARACTER SET utf8mb4  NOT NULL COMMENT '起源应用名称',
  `app_comment` varchar(500) CHARACTER SET utf8mb4  DEFAULT NULL COMMENT '备注',
  `dsn` varchar(200) CHARACTER SET utf8mb4  NOT NULL COMMENT '数据源DSN',
  `is_delete` smallint(6) NOT NULL DEFAULT '0' COMMENT '是否删除。0为未删除，1为删除',
  `created_mis` varchar(30) CHARACTER SET utf8mb4   NOT NULL COMMENT '编辑人',
  `last_update_mis` varchar(30) CHARACTER SET utf8mb4   NOT NULL COMMENT '最新编辑人',
  `created_time` datetime NOT NULL COMMENT '创建时间',
  `update_time` datetime NOT NULL COMMENT '最后修改时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COMMENT='起源应用信息表';
