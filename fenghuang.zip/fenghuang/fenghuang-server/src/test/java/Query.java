import org.junit.Test;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2022/4/28 5:10 下午
 */
public class Query {
    @Test
    public void requestTest(){
        String requestStr = "{\"historyDate\":{\"data\":{\"start\":\"20220202\",\"end\":\"20220207\",\"type\":\"WEEK\"},\"type\":\"DATE\"},\"contrastList\":{\"data\":[{\"value\":\"1\"}],\"type\":\"RADIO\"},\"city\":{\"data\":[{\"children\":[{\"children\":[{\"value\":\"001\"}],\"value\":\"01\"}],\"value\":\"0\"}],\"type\":\"CASCADER\"},\"currentDate\":{\"data\":{\"start\":\"20220202\",\"end\":\"20220207\",\"type\":\"WEEK\"},\"type\":\"DATE\"},\"busList\":{\"data\":[{\"value\":\"1\"},{\"value\":\"2\"}],\"type\":\"CHECKBOX\"}}";
//        QueryRequest queryRequest = JSONObject.parseObject(requestStr,QueryRequest.class);
//        String jsonStr = JSONObject.toJSON(queryRequest).toString();
//        System.out.println(jsonStr);
//        QueryRequest queryRequest1 = JSONObject.parseObject(jsonStr,QueryRequest.class);
//        System.out.println(JsonUtils.toJson(queryRequest1));

    }
}
