package tmpapp;

import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.FhIdUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.server.service.impl.TmpAppServiceImpl;
import org.junit.Test;
import org.springframework.util.StringUtils;

import java.util.List;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2022/4/7 8:07 下午
 */
public class TmpAppTest {
    @Test
    public void mathTest(){
        long count = 11;
        int pageSize = 10;
        System.out.println((int)Math.ceil((double) count/pageSize));
    }

    @Test
    public void testSqlParse(){
        TmpAppServiceImpl tmpAppService = new TmpAppServiceImpl();
        String sql = "select dt,\n" +
                "       poi_aor_id,\n" +
                "       poi_aor_name,\n" +
                "       poi_aor_type,\n" +
                "       cxr,\n" +
                "       old_user_rate,\n" +
                "       new_user_rate,\n" +
                "       new_cat_user_rate,\n" +
                "       remain_user_cnt,\n" +
                "       new_user_cac,\n" +
                "       prod_quality_refund_rate,\n" +
                "       ncr_shortage_refund_ord_num_rate,\n" +
                "       ncr_abnor_refund_ord_num_rate,\n" +
                "       avg_disc_price_rate,\n" +
                "       deal_first_category_num,\n" +
                "       deal_second_category_num,\n" +
                "       deal_third_category_num,\n" +
                "       product_cnt,\n" +
                "       poi_first_category_cnt,\n" +
                "       poi_second_category_cnt,\n" +
                "       poi_third_category_cnt,\n" +
                "       ka_poi_rate,\n" +
                "       no_ka_poi_rate,\n" +
                "       reject_order_rate,\n" +
                "       no_accept_order_rate\n" +
                "  from mart_lingshou_test.app_aor_flow_poi_analyse\n" +
                " where dt = 20220317 select a from ";
        List<String> fields = tmpAppService.parseSelectItemBySql(sql);
        fields.stream().forEach(e->System.out.println(e));
    }


    @Test
    public void testId(){
        System.out.println(FhIdUtils.genFhUnifiedId());
    }

    @Test
    public void stringTest(){
        String str = "select dt,\\n       poi_aor_id,\\n       poi_aor_name,\\n       poi_aor_type,\\n       cxr,\\n       old_user_rate,\\n       new_user_rate,\\n       new_cat_user_rate,\\n       remain_user_cnt,\\n       new_user_cac,\\n       prod_quality_refund_rate,\\n       ncr_shortage_refund_ord_num_rate,\\n       ncr_abnor_refund_ord_num_rate,\\n       avg_disc_price_rate,\\n       deal_first_category_num,\\n       deal_second_category_num,\\n       deal_third_category_num,\\n       product_cnt,\\n       poi_first_category_cnt,\\n       poi_second_category_cnt,\\n       poi_third_category_cnt,\\n       ka_poi_rate,\\n       no_ka_poi_rate,\\n       reject_order_rate,\\n       no_accept_order_rate\\n  from mart_lingshou_test.app_aor_flow_poi_analyse\\n where dt = 20220317\\n";
        System.out.println(StringUtils.delete(str,"\\n"));;
    }

}


