package tmpapp;

import org.junit.Test;

import static com.sankuai.tripdatecenter.databp.fenghuang.common.constant.NumberConstant.ONE;
import static com.sankuai.tripdatecenter.databp.fenghuang.common.constant.NumberConstant.ZERO;
import static com.sankuai.tripdatecenter.databp.fenghuang.common.constant.SymbolConstant.CONCAT_UNDERLINE;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2022/4/24 5:55 下午
 */
public class RelationTest {
    @Test
    public void test(){
        String aa = "da_dd_dge_0";
        String bb = aa.substring(ZERO, aa.lastIndexOf(CONCAT_UNDERLINE));
        String cc = aa.substring(aa.lastIndexOf(CONCAT_UNDERLINE)+ONE);
        System.out.println(aa);
        System.out.println(bb);
        System.out.println(cc);

    }
}
