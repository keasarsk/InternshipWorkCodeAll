package common;


/**
 * description
 *
 * @author nixuefeng
 * @createTime 2022/5/11 7:47 下午
 */
public class Test {
    @org.junit.Test
    public void doubleTest(){
        Double d = 0.99;
        System.out.println(d == 0);
        System.out.println(d.intValue() == 0);
        System.out.println(d.doubleValue() == 0);
    }

}
