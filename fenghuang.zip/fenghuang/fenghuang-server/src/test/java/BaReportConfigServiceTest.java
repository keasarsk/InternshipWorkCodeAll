import com.google.common.collect.Lists;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.ba.BaReportConfigService;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.ba.response.BaIndicatorConfigResponse;
import com.sankuai.tripdatecenter.databp.fenghuang.server.ApplicationLoader;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

/**
 * Description:
 *
 * @author mayuzhe@meituan.com
 * @date 2023/3/10
 */
@Slf4j
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = ApplicationLoader.class)
@WebAppConfiguration
public class BaReportConfigServiceTest {
    @Autowired
    private BaReportConfigService baReportConfigService;

    @Test
    public void getTopicIndicators() {
        BaIndicatorConfigResponse baIndicatorConfigResponse = baReportConfigService.getTopicIndicators(2015L);
        System.out.println();
    }

    @Test
    public void getModuleIndicators() {
        BaIndicatorConfigResponse baIndicatorConfigResponse = baReportConfigService.getModuleIndicators(2019L);
        System.out.println();
    }
}
