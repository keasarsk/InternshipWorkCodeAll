package com.sankuai.tripdatecenter.databp.fenghuang.server.service;

import com.meituan.mdp.boot.starter.web.response.BusinessResponseData;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.domain.BusinessLineVO;
import com.sankuai.tripdatecenter.databp.fenghuang.common.domain.user.UserInfo;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.meta.AppDetailVO;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.meta.AppVO;

/**
 * Description: 起源应用接口
 *
 * @author fuzhengwei02
 * @date 2022-06-22
 */
public interface AppMetaService {
    /**
     * 从起源获取应用列表
     *
     * @param pageNum
     * @param pageSize
     * @param appName app名称
     * @param appId appId
     * @return
     */
    BusinessResponseData<AppVO> getAppListFromOrigin(int pageNum, int pageSize, String appName, Integer appId, BusinessLineVO businessLineVO);

    /**
     * 从本地起源应用池获取维度列表
     *
     * @param pageNum
     * @param pageSize
     * @return
     */
    BusinessResponseData<AppVO> getLocalAppList(int pageNum, int pageSize, String appName, Integer appId, BusinessLineVO businessLineVO);

    /**
     * 从起源添加应用
     *
     * @param originAppVO 起源应用
     */
    boolean addAppFromOrigin(AppVO originAppVO, UserInfo userInfo, BusinessLineVO businessLineVO);

    /**
     * 获取本地起源应用详情
     *
     * @param originAppId
     * @return
     */
    AppDetailVO getLocalAppInfo(Integer originAppId, BusinessLineVO businessLineVO);

    /**
     * 删除本地应用
     *
     * @param originAppId
     * @param userInfo
     * @return
     */

    boolean deleteLocalAppInfo(Integer originAppId, UserInfo userInfo, BusinessLineVO businessLineVO);

    void syncAppIndDim(Integer originAppId, BusinessLineVO businessLineVO, Boolean isOverwrite);
}
