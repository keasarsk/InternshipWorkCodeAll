package com.sankuai.tripdatecenter.databp.fenghuang.server.service;

import com.meituan.mdp.boot.starter.web.response.BusinessResponseData;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.report.UploadAppVO;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.request.*;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.tmpapp.IndicatorVO;


/**
 * description
 *
 * @author fuzhengwei02
 * @createTime 2023/2/6 11:40 上午
 */
public interface UploadAppService {

    /**
     * 查询数据应用
     * @param requestParam
     * @return
     */
    BusinessResponseData<UploadAppVO> listUploadApp(UploadAppRequestParam requestParam);

    UploadAppVO getUploadAppById(GetUploadAppRequestParam getUploadAppRequestParam);

    boolean addUploadApp(CreateUploadAppParam createUploadAppParam);

    boolean updateUploadApp(UpdateUploadAppParam updateUploadAppParam);

    boolean removeUploadApp(RemoveUploadAppParam removeUploadAppParam);

    boolean onlineUploadApp(UpdateUploadAppOnlineParam updateUploadAppOnlineParam);

    String addUploadAppIndicator(CreateUploadAppIndicatorParam createUploadAppIndicatorParam);

    boolean updateUploadAppIndicator(UpdateUploadAppIndicatorParam updateUploadAppIndicatorParam);

    boolean deleteUploadAppIndicator(DeleteUploadAppIndicatorParam deleteUploadAppIndicatorParam);

    BusinessResponseData<IndicatorVO> listAppIndicators(ListAppIndicatorRequestParam listAppIndicatorRequestParam);

    IndicatorVO getAppIndicatorById(GetAppIndicatorByIdRequestParam getAppIndicatorByIdRequestParam);

}
