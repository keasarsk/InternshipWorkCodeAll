package com.sankuai.tripdatecenter.databp.fenghuang.server.service;

import com.sankuai.tripdatecenter.databp.fenghuang.client.config.domain.BusinessLineVO;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.datasource.DatasourceDetailVO;

import java.util.List;

/**
 * description 数据源Service接口
 *
 * @author mayuzhe
 * @date 2022-04-11
 */
public interface DatasourceService {
    /**
     * 获取数据源列表
     *
     * @return
     */
    List<DatasourceDetailVO> getDsnList(BusinessLineVO businessLineVO);

    /**
     * 获取数据源详情
     *
     * @param datasourceId 数据源 id
     * @return
     */
    DatasourceDetailVO getDsnDetail(long datasourceId, BusinessLineVO businessLineVO);

    /**
     * 创建数据源详情
     *
     * @param datasourceDetailVO
     * @return
     */
    Long submitDsn(DatasourceDetailVO datasourceDetailVO, BusinessLineVO businessLineVO);

    /**
     * 修改数据源
     *
     * @param datasourceDetailVO
     * @return
     */
    void modifyDsn(DatasourceDetailVO datasourceDetailVO, BusinessLineVO businessLineVO);

    /**
     * 删除数据源
     *
     * @param datasourceId
     * @return
     */
    void deleteDsn(long datasourceId, BusinessLineVO businessLineVO);
}
