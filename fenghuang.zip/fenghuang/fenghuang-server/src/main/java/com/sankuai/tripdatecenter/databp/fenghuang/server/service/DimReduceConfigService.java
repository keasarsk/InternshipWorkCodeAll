package com.sankuai.tripdatecenter.databp.fenghuang.server.service;

import com.sankuai.tripdatecenter.databp.fenghuang.domain.report.DimReduceDimensionEnumsVO;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.report.DimensionEnumVO;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.report.DimensionEnumsVO;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.report.TopicDimensionExtVO;
import java.util.List;
import java.util.Map;

/**
 * description  降维配置相关接口 .
 *
 * @author fuzhengwei02
 * @createTime 2022/9/19 下午8:13
 * @throws
 */
public interface DimReduceConfigService {

    /**
     * 保存降维枚举值信息
     * @param dimReduceDimensionEnumsVO
     */
    boolean saveDimReduceDimensionEnums(DimReduceDimensionEnumsVO dimReduceDimensionEnumsVO);

    /**
     * 获取降维枚举信息
     * @param reportId 报表ID
     * @param topicId  主题ID
     * @param version  版本
     * @param indicatorId 指标ID
     * @param dimensionId 维度ID
     * @return 降维枚举信息
     */
    DimReduceDimensionEnumsVO getDimReduceDimensionEnums(Long reportId, Long topicId, Long version, String indicatorId, String dimensionId);

    /**
     * 获取维度枚举信息
     * @param dimensionId 维度ID
     * @return 降维枚举信息
     */
    DimensionEnumsVO getDimensionEnums(String dimensionId, String businessId);

}
