package com.sankuai.tripdatecenter.databp.fenghuang.server.service;

import com.sankuai.tripdatecenter.databp.fenghuang.common.exception.FHBaseException;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.report.TemplateVO;

import java.util.List;

/**
 * description 模板处理Service接口
 *
 * @author nixuefeng
 * @createTime 2023/2/28 17:32
 */
public interface TemplateService {
    /**
     * 查询模板集合
     * @param topicId
     * @return
     * @throws FHBaseException
     */
    List<TemplateVO> listTemplate(Long topicId) throws FHBaseException;

}
