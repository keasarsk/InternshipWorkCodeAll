package com.sankuai.tripdatecenter.databp.fenghuang.server.controller;

import com.meituan.mdp.boot.starter.web.response.WebResponse;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.BusinessLineService;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.domain.BusinessLineVO;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.datasource.DatasourceDetailVO;
import com.sankuai.tripdatecenter.databp.fenghuang.server.service.DatasourceService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * description 数据源Controller类
 *
 * @author mayuzhe
 * @date 2022-04-08
 */
@RestController
@Api("数据源相关api")
@RequestMapping("/api/fh/dsn")
public class DatasourceController {
    @Autowired
    private DatasourceService datasourceService;

    @Autowired
    private BusinessLineService businessLineService;

    @GetMapping("/list")
    @ApiOperation(value = "数据源列表")
    public WebResponse<List<DatasourceDetailVO>> getDsnList(@RequestParam(required = false) String businessId) {
        BusinessLineVO businessLineVO = businessLineService.getBusinessLineByBusinessId(businessId);
        return WebResponse.buildData(datasourceService.getDsnList(businessLineVO));
    }

    @GetMapping("/detail")
    @ApiOperation(value = "数据源详情")
    public WebResponse<DatasourceDetailVO> getDsnDetail(@RequestParam long datasourceId, @RequestParam(required = false) String businessId) {
        BusinessLineVO businessLineVO = businessLineService.getBusinessLineByBusinessId(businessId);
        return WebResponse.buildData(datasourceService.getDsnDetail(datasourceId, businessLineVO));
    }

    @PostMapping("/submit")
    @ApiOperation(value = "数据源提交")
    public WebResponse<Long> submitDsn(@RequestBody DatasourceDetailVO datasourceDetail, @RequestParam(required = false) String businessId) {
        BusinessLineVO businessLineVO = businessLineService.getBusinessLineByBusinessId(businessId);
        return WebResponse.buildData(datasourceService.submitDsn(datasourceDetail, businessLineVO));
    }

    @GetMapping("/delete")
    @ApiOperation(value = "数据源删除")
    public WebResponse<String> deleteDsn(@RequestParam long datasourceId, @RequestParam(required = false) String businessId) {
        BusinessLineVO businessLineVO = businessLineService.getBusinessLineByBusinessId(businessId);
        datasourceService.deleteDsn(datasourceId, businessLineVO);
        return WebResponse.buildData("200");
    }
}
