package com.sankuai.tripdatecenter.databp.fenghuang.server.service;

import com.sankuai.tripdatecenter.databp.fenghuang.domain.report.DimensionEnumVO;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.report.TopicDimensionExtVO;

import java.util.List;
import java.util.Map;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2022/4/28 7:03 下午
 */
public interface TopicDimensionConfigService {
    /**
     * 根据报表、主题、维度、版本信息获取维度配置信息
     *
     * @param reportId
     * @param topicId
     * @param dimensionId
     * @param version
     * @return
     */
    TopicDimensionExtVO getTopicDimensionConfig(Long reportId, Long topicId, String dimensionId, Long version);

    /**
     * 根据报表、主题、维度、版本信息获取维度枚举信息
     *
     * @param reportId
     * @param topicId
     * @param dimensionId
     * @param version
     * @return
     */
    List<DimensionEnumVO> listTopicDimensionEnum(Long reportId, Long topicId, String dimensionId, Long version);

    /**
     * 保存指标维度矩阵列表
     *
     * @param config
     * @return
     */
    boolean saveTopicDimensionConfig(TopicDimensionExtVO config);

    /**
     * 加载维度对应的起源枚举值名称和是否选中标志
     * @param dimensionId 维度ID
     * @param existEnumMap 维值map
     * @return
     */
    List<DimensionEnumVO> wrapDimensionEnumList(String dimensionId, Map<String,DimensionEnumVO> existEnumMap, String businessId);
}
