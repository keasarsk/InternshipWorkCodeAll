package com.sankuai.tripdatecenter.databp.fenghuang.server.controller;

import io.swagger.annotations.Api;
import org.springframework.web.bind.annotation.*;


/**
 * description
 *
 * @author nixuefeng
 * @createTime 2022/4/28 3:22 下午
 */
@RestController
@Api("filter test")
@RequestMapping("/filter")
public class FilterTestController {
//    @GetMapping("/list")
//    @ApiOperation(value = "协议格式测试")
//    public WebResponse<List<SelectorFilterVo.SelectorItemVo>> getDimData() {
//        List<SelectorFilterVo.SelectorItemVo> items = Lists.newArrayList();
//        SelectorFilterVo.SelectorItemVo a = new SelectorFilterVo.SelectorItemVo("1","美团");
//        items.add(a);
//        SelectorFilterVo.SelectorItemVo b = new SelectorFilterVo.SelectorItemVo("2","点评");
//        items.add(b);
//        SelectorFilterVo.SelectorItemVo c = new SelectorFilterVo.SelectorItemVo("3","分销");
//        items.add(c);
//        return WebResponse.buildData(items);
//    }

//    @PostMapping("/query")
//    @ApiOperation(value = "请求测试")
//    public WebResponse<SelectorFilterVo.SelectorItemVo> queryData(@RequestBody QueryRequest request) {
//        List<SelectorFilterVo.SelectorItemDetailVo> items = Lists.newArrayList();
//        SelectorFilterVo.SelectorItemDetailVo a = new SelectorFilterVo.SelectorItemDetailVo("1","美团");
//        items.add(a);
//        SelectorFilterVo.SelectorItemDetailVo b = new SelectorFilterVo.SelectorItemDetailVo("2","点评");
//        items.add(b);
//        SelectorFilterVo.SelectorItemDetailVo c = new SelectorFilterVo.SelectorItemDetailVo("3","分销");
//        items.add(c);
//        return WebResponse.buildData(items);
//    }
}
