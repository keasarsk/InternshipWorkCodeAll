package com.sankuai.tripdatecenter.databp.fenghuang.server.constant;

/**
 * description 将军令常量
 *
 * @author fuzhengwei02
 * @createTime 2022年06月24日 10:51:00
 */
public class AuthConstants {

    public static final String CONFIG_ADMIN_CODE = "fenghuang_manage_role_admin";


}
