package com.sankuai.tripdatecenter.databp.fenghuang.server.service.impl;

import com.sankuai.hbdata.commonutils.common.BeanCopyUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.BusinessLineService;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.ExMetadataConfigService;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.domain.*;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.request.*;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.response.*;
import com.sankuai.tripdatecenter.databp.fenghuang.common.constant.BizConstant;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.ExReportConfigService;
import com.sankuai.tripdatecenter.databp.fenghuang.common.enums.AppTypeEnum;
import com.sankuai.tripdatecenter.databp.fenghuang.common.enums.DeleteStatusEnum;
import com.sankuai.tripdatecenter.databp.fenghuang.common.enums.ExceptionCodeEnum;
import com.sankuai.tripdatecenter.databp.fenghuang.common.enums.NumberEnum;
import com.sankuai.tripdatecenter.databp.fenghuang.common.enums.YnEnum;
import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.BusinessLineUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.JsonUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.IndicatorReduceDimDao;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.ReportDao;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.mapper.auto.DimReduceDimEnumPOMapper;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.mapper.auto.ModulePOMapper;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.mapper.auto.TopicIndicatorPOMapper;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.mapper.auto.TopicPOMapper;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.mapper.ext.DataServiceMapperExt;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.DimReduceDimEnumPO;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ModulePO;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.TopicIndicatorPO;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.TopicPO;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.example.DimReduceDimEnumPOExample;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.example.ModulePOExample;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.example.TopicIndicatorPOExample;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.example.TopicPOExample;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ext.IndicatorReduceDimExtPO;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ext.ReportTopicIndicatorInfoExtPO;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.report.DimensionEnumVO;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.report.ReportConfigVO;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.report.ReportVO;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.report.TopicDimensionExtVO;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.report.TopicDimensionVO;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.report.TopicExtVO;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.report.TopicVO;
import com.sankuai.tripdatecenter.databp.fenghuang.server.service.DimensionService;
import com.sankuai.tripdatecenter.databp.fenghuang.server.service.ReportService;
import com.sankuai.tripdatecenter.databp.fenghuang.server.service.TopicDimensionConfigService;
import com.sankuai.tripdatecenter.databp.fenghuang.server.service.TopicService;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import javax.annotation.Resource;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * description
 *
 * @author fuzhengwei02
 * @createTime 2022年07月05日 20:41:00
 */
@Slf4j
@Service
public class ExReportConfigServiceImpl implements ExReportConfigService {

    @Resource
    private DimensionService dimensionService;

    @Resource
    private TopicService topicService;

    @Resource
    private TopicDimensionConfigService topicDimensionEnumService;

    @Resource
    private ReportService reportService;

    @Resource
    private TopicPOMapper topicPOMapper;

    @Resource
    private TopicIndicatorPOMapper topicIndicatorPOMapper;

    @Resource
    private ModulePOMapper modulePOMapper;

    @Resource
    private DataServiceMapperExt dataServiceMapperExt;

    @Resource
    private DimReduceDimEnumPOMapper dimReduceDimEnumPOMapper;

    @Resource
    private TopicDimensionConfigService topicDimensionConfigService;

    @Resource
    private ExMetadataConfigService exMetadataConfigService;

    @Autowired
    private BusinessLineService businessLineService;

    @Autowired
    private ReportDao reportDao;

    @Autowired
    private IndicatorReduceDimDao indicatorReduceDimDao;

    @Override
    public LoadReportConfigResponse getReportConfig(LoadReportConfigRequest templateConfigRequest) {
        LoadReportConfigResponse response = new LoadReportConfigResponse();
        Long reportId = templateConfigRequest.getReportId();
        Long version = templateConfigRequest.getVersion();
        if (version == null) {
            log.info("version not set. ready to find online version. reportId :{}", reportId);
            Long onlineVersion = reportService.getOnlineVersion(reportId);
            log.info("find online version :{}, reportId: {}", onlineVersion, reportId);
            if (onlineVersion == null) {
                log.info("no online verison, reportId :{}", reportId);
                response.setSuccess(false);
                response.setCode(ExceptionCodeEnum.EXEC_FAIL_EXCEPTION.getCode());
                return response;
            }
            version = onlineVersion;
        }
        //查询报表下topic
        List<TopicExtVO> topicExts = Lists.newArrayList();
        List<TopicVO> topics = topicService.listTopic(reportId, version);
        for (TopicVO topic : topics) {
            TopicExtVO topicExt = new TopicExtVO();
            BeanUtils.copyProperties(topic, topicExt);
            Long topicId = topic.getTopicId();
            //查询topic下维度信息
            List<TopicDimensionVO> topicDimensions = dimensionService.listDimension(reportId, topicId, version);
            List<TopicDimensionExtVO> topicDimensionExts = Lists.newArrayList();
            for (TopicDimensionVO topicDimension : topicDimensions) {
                TopicDimensionExtVO topicDimensionExt = new TopicDimensionExtVO();
                BeanUtils.copyProperties(topicDimension, topicDimensionExt);
                String dimensionId = topicDimension.getDimensionId();
                //查询维度下属枚举值信息
                List<DimensionEnumVO> dimensionEnums = topicDimensionEnumService.listTopicDimensionEnum(reportId, topicId, dimensionId, version);
                List<DimensionEnumVO> selectedDimensionEnums = Lists.newArrayList();
                for (DimensionEnumVO vo : dimensionEnums) {
                    if (vo.getIsSelected()) selectedDimensionEnums.add(vo);
                }
                topicDimensionExt.setDimensionEnums(selectedDimensionEnums);
                topicDimensionExts.add(topicDimensionExt);
            }
            topicExt.setDimensions(topicDimensionExts);
            topicExts.add(topicExt);
        }
        ReportConfigVO reportConfigVo = new ReportConfigVO();
        reportConfigVo.setTopicInfos(topicExts);
        ReportVO reportVO = reportService.getReportBaseConfig(reportId, version);
        reportConfigVo.setReportInfo(reportVO);
        String reportConfigJson = JsonUtils.toJson(reportConfigVo);
        ReportConfigInfo reportConfigInfo = JsonUtils.string2Class(reportConfigJson, ReportConfigInfo.class);
        response.setSuccess(true);
        response.setCode(ExceptionCodeEnum.SUCCESS.getCode());
        response.setData(reportConfigInfo);
        return response;
    }

    @Override
    public GetReportConfigBaseInfoResponse getReportConfigBaseInfo(GetReportConfigBaseInfoRequest request) {
        ReportVO reportVO = reportService.getReportBaseConfig(request.getReportId(), request.getVersion());
        GetReportConfigBaseInfoResponse response = new GetReportConfigBaseInfoResponse();
        response.setCode(ExceptionCodeEnum.SUCCESS.getCode());
        response.setSuccess(true);
        if (reportVO != null) {
            ReportInfo reportInfo = new ReportInfo();
            BeanUtils.copyProperties(reportVO, reportInfo);
            response.setData(reportInfo);
        }
        return response;
    }

    @Override
    public GetTopicConfigInfoResponse getTopicConfigInfoRequest(GetTopicConfigInfoRequest request) {
        TopicVO topicVO = topicService.getTopic(request.getReportId(), request.getTopicId(), request.getVersion());
        GetTopicConfigInfoResponse response = new GetTopicConfigInfoResponse();
        response.setCode(ExceptionCodeEnum.SUCCESS.getCode());
        response.setSuccess(true);
        if (topicVO != null) {
            TopicBaseInfo topicBaseInfo = new TopicBaseInfo();
            BeanUtils.copyProperties(topicVO, topicBaseInfo);
            response.setData(topicBaseInfo);
        }
        return response;
    }

    @Override
    public IndicatorAppConfigResponse getIndicatorAppConfig(IndicatorAppConfigRequest request) {
        try {
            TopicIndicatorPOExample example = new TopicIndicatorPOExample();
            TopicIndicatorPOExample.Criteria criteria = example.createCriteria();
            criteria.andIsDeleteEqualTo(DeleteStatusEnum.NOT_DELETED.getCode());
            criteria.andIndicatorIdIn(request.getIndicatorIds());
            criteria.andReportIdEqualTo(request.getReportId());
            criteria.andTopicIdEqualTo(request.getTopicId());
            criteria.andVersionEqualTo(request.getVersion());
            criteria.andAppSourceIsNotNull();
            criteria.andAppIdIsNotNull();
            List<TopicIndicatorPO> topicIndicatorPOS = topicIndicatorPOMapper.selectByExample(example);
            Map<String, IndicatorAppConfig> configMapping = Maps.newHashMap();
            for (TopicIndicatorPO topicIndicatorPO : topicIndicatorPOS) {
                String indicatorId = topicIndicatorPO.getIndicatorId();
                IndicatorAppConfig indicatorAppConfig = new IndicatorAppConfig();
                indicatorAppConfig.setTargetAppType(topicIndicatorPO.getTargetAppType());
                indicatorAppConfig.setTargetAppId(topicIndicatorPO.getTargetAppId());
                Integer appType = topicIndicatorPO.getAppSource();
                if (appType == null) {
                    log.info("topic indicator appInfo 未设置:{}", indicatorId);
                    continue;
                }
                indicatorAppConfig.setAppType(String.valueOf(appType));
                AppTypeEnum appTypeEnum = AppTypeEnum.getByCode(String.valueOf(appType));
                switch (appTypeEnum) {
                    case ORIGIN:
                        if (topicIndicatorPO.getAppId() != null) {
                            indicatorAppConfig.setOriginAppId(topicIndicatorPO.getAppId().intValue());
                        }
                        break;
                    case TMP_APP:
                        if (topicIndicatorPO.getAppId() != null) {
                            indicatorAppConfig.setTempAppId(new Long(topicIndicatorPO.getAppId()));
                            indicatorAppConfig.setTempAppVersion(request.getVersion());
                        }
                        break;
                    case UPLOAD_APP:
                        if (topicIndicatorPO.getAppId() != null) {
                            indicatorAppConfig.setUploadAppId(topicIndicatorPO.getAppId());
                        }
                        break;
                    default:
                        throw new RuntimeException("未知应用类型：" + appType);
                }
                configMapping.put(indicatorId, indicatorAppConfig);
            }
            IndicatorAppConfigResponse response = new IndicatorAppConfigResponse();
            response.setSuccess(true);
            response.setCode(ExceptionCodeEnum.SUCCESS.getCode());
            response.setData(configMapping);
            return response;
        } catch (Exception e) {
            IndicatorAppConfigResponse response = new IndicatorAppConfigResponse();
            response.setSuccess(false);
            response.setCode(ExceptionCodeEnum.UNKNOWN_EXCEPTION.getCode());
            response.setMsg(e.getMessage());
            return response;
        }
    }

    @Override
    public QueryReportTopicIndicatorIdsResponse queryReportTopicIndicatorIds(Long reportId, Long topicId, Long version) {
        try {
            QueryReportTopicIndicatorIdsResponse response = new QueryReportTopicIndicatorIdsResponse();
            List<String> indicatorIds = dataServiceMapperExt.getIndicatorIdsByReportIdAndTopicId(reportId, topicId, version);
            response.setSuccess(true);
            response.setCode(ExceptionCodeEnum.SUCCESS.getCode());
            response.setData(indicatorIds);
            return response;
        } catch (Exception e) {
            QueryReportTopicIndicatorIdsResponse failResponse = new QueryReportTopicIndicatorIdsResponse();
            failResponse.setSuccess(false);
            failResponse.setCode(ExceptionCodeEnum.EXEC_FAIL_EXCEPTION.getCode());
            failResponse.setMsg(e.getMessage());
            return failResponse;
        }
    }

    @Override
    public QueryReportTopicIndicatorInfosResponse queryReportTopicIndicatorInfos(Long reportId, Long topicId, Long version, List<String> indicatorIds) {
        try {
            String businessId = BusinessLineUtils.getDefaultBusinessId();
            List<ReportTopicIndicatorInfoExtPO> reportTopicIndicators = dataServiceMapperExt.selectReportTopicIndicatorInfos(reportId, topicId, version, indicatorIds, businessId);
            List<ReportTopicIndicatorInfo> reportTopicIndicatorInfos = Lists.newArrayList();
            if (CollectionUtils.isNotEmpty(reportTopicIndicators)) {
                for (ReportTopicIndicatorInfoExtPO reportTopicIndicator : reportTopicIndicators) {
                    ReportTopicIndicatorInfo reportTopicIndicatorInfo = new ReportTopicIndicatorInfo();
                    BeanUtils.copyProperties(reportTopicIndicator, reportTopicIndicatorInfo);
                    reportTopicIndicatorInfos.add(reportTopicIndicatorInfo);
                }
            }
            QueryReportTopicIndicatorInfosResponse response = new QueryReportTopicIndicatorInfosResponse();
            response.setSuccess(true);
            response.setCode(ExceptionCodeEnum.SUCCESS.getCode());
            response.setData(reportTopicIndicatorInfos);
            return response;
        } catch (Exception e) {
            QueryReportTopicIndicatorInfosResponse failResponse = new QueryReportTopicIndicatorInfosResponse();
            failResponse.setCode(ExceptionCodeEnum.EXEC_FAIL_EXCEPTION.getCode());
            failResponse.setMsg(e.getMessage());
            failResponse.setSuccess(false);
            return failResponse;
        }
    }

    @Override
    public CheckIndicatorDimensionPermissionResponse checkIndicatorDimensionPermission(Long reportId, Long topicId, Long version, List<String> indicatorIds, String dimensionId,
                                                                                       List<String> dimensionEnumValues) {
        try {
            List<String> checkedIndicatorIds = Lists.newArrayList();
            for (String indicatorId : indicatorIds) {
                boolean checked = true;
                for (String dimensionEnumValue : dimensionEnumValues) {
                    boolean pass = checkIndicatorDimensionPermissionSingle(reportId, topicId, version, indicatorId, dimensionId, dimensionEnumValue);
                    if (!pass) {
                        log.info("checkIndicatorDimensionPermissionSingle failed:reportId:{},topicId:{},version:{},indicatorId:{},dimensionId:{},dimensionEnumValue:{}", reportId, topicId, version,
                                indicatorId, dimensionId, dimensionEnumValue);
                        checked = false;
                        break;
                    }
                }
                if (checked) {
                    checkedIndicatorIds.add(indicatorId);
                }
            }
            CheckIndicatorDimensionPermissionResponse response = new CheckIndicatorDimensionPermissionResponse();
            response.setSuccess(true);
            response.setCode(ExceptionCodeEnum.SUCCESS.getCode());
            response.setData(checkedIndicatorIds);
            return response;
        } catch (Exception e) {
            CheckIndicatorDimensionPermissionResponse failResponse = new CheckIndicatorDimensionPermissionResponse();
            failResponse.setCode(ExceptionCodeEnum.EXEC_FAIL_EXCEPTION.getCode());
            failResponse.setSuccess(false);
            failResponse.setMsg(e.getMessage());
            return failResponse;
        }
    }

    private boolean checkIndicatorDimensionPermissionSingle(Long reportId, Long topicId, Long version, String indicatorId, String dimensionId, String dimensionEnumValue) {
        Integer cnt = dataServiceMapperExt.checkIndicatorDimensionIdAndEnumValue(reportId, topicId, version, indicatorId, dimensionId, dimensionEnumValue);
        return cnt > 0;
    }

    @Override
    public QueryReportTopicModuleInfoResponse queryReportTopicModuleInfo(Long reportId, Long topicId, Long version) {
        try {
            ModulePOExample example = new ModulePOExample();
            example.createCriteria()
                    .andReportIdEqualTo(reportId)
                    .andTopicIdEqualTo(topicId)
                    .andVersionEqualTo(version)
                    .andIsDeleteEqualTo(DeleteStatusEnum.NOT_DELETED.getCode());
            example.setOrderByClause(BizConstant.ORDER_STR);
            List<ModulePO> modulePOS = modulePOMapper.selectByExample(example);
            List<ModuleInfo> moduleInfos = Lists.newArrayList();
            if (CollectionUtils.isNotEmpty(modulePOS)) {
                for (ModulePO modulePO : modulePOS) {
                    ModuleInfo moduleInfo = new ModuleInfo();
                    BeanUtils.copyProperties(modulePO, moduleInfo);
                    moduleInfos.add(moduleInfo);
                }
            }
            QueryReportTopicModuleInfoResponse response = new QueryReportTopicModuleInfoResponse();
            response.setCode(ExceptionCodeEnum.SUCCESS.getCode());
            response.setSuccess(true);
            response.setData(moduleInfos);
            return response;
        } catch (Exception e) {
            QueryReportTopicModuleInfoResponse failResponse = new QueryReportTopicModuleInfoResponse();
            failResponse.setSuccess(false);
            failResponse.setCode(ExceptionCodeEnum.EXEC_FAIL_EXCEPTION.getCode());
            return failResponse;
        }
    }

    @Override
    public QueryModuleIndicatorIdsResponse queryModuleRootIndicatorIds(Long reportId, Long topicId, Long moduleId, Long version) {
        try {
            TopicIndicatorPOExample example = new TopicIndicatorPOExample();
            TopicIndicatorPOExample.Criteria criteria = example.createCriteria();
            criteria.andReportIdEqualTo(reportId);
            criteria.andTopicIdEqualTo(topicId);
            criteria.andModuleIdEqualTo(moduleId);
            criteria.andVersionEqualTo(version);
            criteria.andIsDeleteEqualTo(DeleteStatusEnum.NOT_DELETED.getCode());
            criteria.andParentIdEqualTo(BizConstant.INDICATOR_TREE_ROOT_ID);
            example.setOrderByClause(BizConstant.ORDER_STR);
            List<TopicIndicatorPO> indicatorPOS = topicIndicatorPOMapper.selectByExample(example);
            List<String> indicatorIds = Lists.newArrayList();
            if (CollectionUtils.isNotEmpty(indicatorPOS)) {
                for (TopicIndicatorPO indicatorPO : indicatorPOS) {
                    indicatorIds.add(indicatorPO.getIndicatorId());
                }
            }
            QueryModuleIndicatorIdsResponse response = new QueryModuleIndicatorIdsResponse();
            response.setSuccess(true);
            response.setCode(ExceptionCodeEnum.SUCCESS.getCode());
            response.setData(indicatorIds);
            return response;
        } catch (Exception e) {
            QueryModuleIndicatorIdsResponse failResponse = new QueryModuleIndicatorIdsResponse();
            failResponse.setSuccess(false);
            failResponse.setCode(ExceptionCodeEnum.EXEC_FAIL_EXCEPTION.getCode());
            failResponse.setMsg(e.getMessage());
            return failResponse;
        }
    }

    @Override
    public QueryModuleIndicatorIdsResponse queryModuleAllIndicatorIds(Long reportId, Long topicId, Long moduleId, Long version) {
        try {
            TopicIndicatorPOExample example = new TopicIndicatorPOExample();
            TopicIndicatorPOExample.Criteria criteria = example.createCriteria();
            criteria.andReportIdEqualTo(reportId);
            criteria.andTopicIdEqualTo(topicId);
            criteria.andModuleIdEqualTo(moduleId);
            criteria.andVersionEqualTo(version);
            criteria.andIsDeleteEqualTo(DeleteStatusEnum.NOT_DELETED.getCode());
            example.setOrderByClause(BizConstant.ORDER_ID_STR);
            List<TopicIndicatorPO> indicatorPOS = topicIndicatorPOMapper.selectByExample(example);
            List<String> indicatorIds = Lists.newArrayList();
            if (CollectionUtils.isNotEmpty(indicatorPOS)) {
                for (TopicIndicatorPO indicatorPO : indicatorPOS) {
                    indicatorIds.add(indicatorPO.getIndicatorId());
                }
            }
            QueryModuleIndicatorIdsResponse response = new QueryModuleIndicatorIdsResponse();
            response.setSuccess(true);
            response.setCode(ExceptionCodeEnum.SUCCESS.getCode());
            response.setData(indicatorIds);
            return response;
        } catch (Exception e) {
            QueryModuleIndicatorIdsResponse failResponse = new QueryModuleIndicatorIdsResponse();
            failResponse.setSuccess(false);
            failResponse.setCode(ExceptionCodeEnum.EXEC_FAIL_EXCEPTION.getCode());
            failResponse.setMsg(e.getMessage());
            return failResponse;
        }
    }

    @Override
    public GetTopicTemplateResponse getTopicTemplate(Long reportId, Long topicId, Long version, String businessId) {
        try {
            TopicPOExample example = new TopicPOExample();
            TopicPOExample.Criteria criteria = example.createCriteria();
            criteria.andIsDeleteEqualTo(DeleteStatusEnum.NOT_DELETED.getCode());
            criteria.andReportIdEqualTo(reportId);
            criteria.andTopicIdEqualTo(topicId);
            criteria.andVersionEqualTo(version);
            criteria.andBusinessIdEqualTo(businessId);
            List<TopicPO> topicList = topicPOMapper.selectByExample(example);
            if (CollectionUtils.isEmpty(topicList) || topicList.size() != NumberEnum.ONE.getCode()) {
                log.info("主题数量不为1 : {}", JsonUtils.toJson(topicList));
                throw new RuntimeException("主题数量不为1, reportId:" + reportId + ", topicId:" + topicId + ", version:" + version);
            }
            GetTopicTemplateResponse response = new GetTopicTemplateResponse();
            response.setCode(ExceptionCodeEnum.SUCCESS.getCode());
            response.setSuccess(true);
            response.setData(topicList.get(0).getTemplateType());
            return response;
        } catch (Exception e) {
            GetTopicTemplateResponse failResponse = new GetTopicTemplateResponse();
            failResponse.setSuccess(false);
            failResponse.setCode(ExceptionCodeEnum.EXEC_FAIL_EXCEPTION.getCode());
            failResponse.setMsg(e.getMessage());
            log.error("getTopicTemplate failed : " + e.getMessage(), e);
            return failResponse;
        }
    }

    private String getReportTopicIndicatorDimReduceDimensionId(Long reportId, Long topicId, Long version, String indicatorId) {
        QueryReportTopicIndicatorInfosResponse queryReportTopicIndicatorInfosResponse = queryReportTopicIndicatorInfos(reportId, topicId, version, Lists.newArrayList(indicatorId));
        if (queryReportTopicIndicatorInfosResponse != null && CollectionUtils.isNotEmpty(queryReportTopicIndicatorInfosResponse.getData())) {
            ReportTopicIndicatorInfo reportTopicIndicatorInfo = queryReportTopicIndicatorInfosResponse.getData().get(0);
            if (reportTopicIndicatorInfo != null && reportTopicIndicatorInfo.getDimReduce() != null && reportTopicIndicatorInfo.getDimReduce().intValue() == (int) YnEnum.Y.getCode()
                    && StringUtils.isNotBlank(reportTopicIndicatorInfo.getDimReduceDimId())) {
                return reportTopicIndicatorInfo.getDimReduceDimId();
            }
            log.info("queryReportTopicIndicatorInfos:{}", JsonUtils.toJson(queryReportTopicIndicatorInfosResponse));
        }
        return null;
    }

    @Override
    public DimReduceDimensionResponse getDimReduceDimensionInfo(DimReduceDimensionRequest request) {
        try {
            Long reportId = request.getReportId();
            Long topicId = request.getTopicId();
            Long version = request.getVersion();
            String indicatorId = request.getIndicatorId();
            String businessId = reportDao.getBusinessIdByReportId(reportId, version);
            String dimensionId = getReportTopicIndicatorDimReduceDimensionId(reportId, topicId, version, indicatorId);
            if (StringUtils.isBlank(dimensionId)) {
                DimReduceDimensionResponse emptyResponse = new DimReduceDimensionResponse();
                emptyResponse.setSuccess(true);
                emptyResponse.setCode(ExceptionCodeEnum.SUCCESS.getCode());
                return emptyResponse;
            }
            DimensionInfoRequest dimensionInfoRequest = new DimensionInfoRequest();
            dimensionInfoRequest.setDimensionIds(Lists.newArrayList(dimensionId));
            dimensionInfoRequest.setBusinessId(businessId);
            DimensionResponse dimensionResponse = exMetadataConfigService.getDimension(dimensionInfoRequest);
            DimensionInfo dimensionInfo = null;
            if (dimensionResponse != null && dimensionResponse.getData() != null && dimensionResponse.getData().size() != 0) {
                dimensionInfo = dimensionResponse.getData().get(dimensionId);
            } else {
                log.info("维度不存在：{}, response: {}", dimensionId, JsonUtils.toJson(dimensionResponse));
                DimReduceDimensionResponse errResponse = new DimReduceDimensionResponse();
                errResponse.setCode(ExceptionCodeEnum.EXEC_FAIL_EXCEPTION.getCode());
                errResponse.setMsg("维度不存在：" + dimensionId);
                errResponse.setSuccess(false);
                return errResponse;
            }

            DimReduceDimEnumPOExample example = new DimReduceDimEnumPOExample();
            DimReduceDimEnumPOExample.Criteria criteria = example.createCriteria();
            criteria.andReportIdEqualTo(reportId);
            criteria.andTopicIdEqualTo(topicId);
            criteria.andVersionEqualTo(version);
            criteria.andDimensionIdEqualTo(dimensionId);
            criteria.andIndicatorIdEqualTo(indicatorId);
            criteria.andIsDeleteEqualTo(DeleteStatusEnum.NOT_DELETED.getCode());
            example.setOrderByClause(" order_num asc ");
            List<DimReduceDimEnumPO> dimEnums = dimReduceDimEnumPOMapper.selectByExample(example);
            Map<String, DimensionEnumVO> existEnumMap = Maps.newHashMap();
            List<DimensionEnumVO> dimensionEnumVOs = Lists.newArrayList();
            if (CollectionUtils.isNotEmpty(dimEnums)) {
                for (DimReduceDimEnumPO dimReduceDimEnumPO : dimEnums) {
                    DimensionEnumVO dimensionEnumVO = new DimensionEnumVO();
                    String dimensionCode = dimReduceDimEnumPO.getDimensionEnumCode();
                    String dimensionName = dimReduceDimEnumPO.getDimensionEnumName();
                    dimensionEnumVO.setDimensionEnumCode(dimensionCode);
                    dimensionEnumVO.setDimensionEnumName(dimensionName);
                    existEnumMap.put(dimensionCode, dimensionEnumVO);
                }
                dimensionEnumVOs = topicDimensionConfigService.wrapDimensionEnumList(dimensionId, existEnumMap, businessId);
            }
            List<DimensionEnumInfo> dimensionEnumInfos = Lists.newArrayList();
            for (DimensionEnumVO dimensionEnumVO : dimensionEnumVOs) {
                if (dimensionEnumVO.getIsSelected()) {
                    DimensionEnumInfo dimensionEnumInfo = new DimensionEnumInfo();
                    BeanUtils.copyProperties(dimensionEnumVO, dimensionEnumInfo);
                    dimensionEnumInfos.add(dimensionEnumInfo);
                }
            }
            DimReduceDimensionResponse response = new DimReduceDimensionResponse();
            response.setSuccess(true);
            response.setCode(ExceptionCodeEnum.SUCCESS.getCode());
            response.setDimensionEnumInfos(dimensionEnumInfos);
            response.setDimensionInfo(dimensionInfo);
            return response;
        } catch (Exception e) {
            DimReduceDimensionResponse errorResponse = new DimReduceDimensionResponse();
            errorResponse.setCode(ExceptionCodeEnum.UNKNOWN_EXCEPTION.getCode());
            errorResponse.setMsg(e.getMessage());
            errorResponse.setSuccess(false);
            return errorResponse;
        }
    }

    @Override
    public DimReduceDimensionListResponse getDimReduceDimensionList(DimReduceDimensionListRequest request) {
        DimReduceDimensionListResponse response = new DimReduceDimensionListResponse();
        response.setSuccess(true);
        Map<String, List<ReduceDimensionInfo>> reduceDimensionMap = Maps.newHashMap();
        response.setDimensionMap(reduceDimensionMap);
        List<IndicatorReduceDimExtPO> reduceDimExtPOS = indicatorReduceDimDao.getReduceDimByTopicId(request.getTopicId());
        if (CollectionUtils.isEmpty(reduceDimExtPOS)) {
            return response;
        }
        // 根据reportId 获取 businessId
        String businessId = reportDao.getBusinessIdByReportId(request.getReportId(), request.getVersion());
        Map<String, List<IndicatorReduceDimExtPO>> indicatorReduceDimPOMap = reduceDimExtPOS.stream().collect(Collectors.groupingBy(IndicatorReduceDimExtPO::getIndicatorId));
        indicatorReduceDimPOMap.forEach((indicatorId, dims) -> {
            if (CollectionUtils.isEmpty(dims)) {
                return;
            }
            List<ReduceDimensionInfo> reduceDims = Lists.newArrayList();
            Map<String, List<IndicatorReduceDimExtPO>> reduceDimPOMap = dims.stream().collect(Collectors.groupingBy(IndicatorReduceDimExtPO::getDimensionId));
            reduceDimPOMap.forEach((dimensionId, enums) -> {
                if (CollectionUtils.isEmpty(enums)) {
                    return;
                }
                // 获取维度信息
                ReduceDimensionInfo reduceDimensionInfo = getDimensionMeta(businessId, dimensionId, enums);
                reduceDims.add(reduceDimensionInfo);
            });
            reduceDimensionMap.put(indicatorId, reduceDims);
        });
        return response;
    }

    private ReduceDimensionInfo getDimensionMeta(String businessId, String dimensionId, List<IndicatorReduceDimExtPO> existEnumList) {
        ReduceDimensionInfo reduceDimensionInfo = new ReduceDimensionInfo();

        DimensionInfoRequest dimensionInfoRequest = new DimensionInfoRequest();
        dimensionInfoRequest.setDimensionIds(Lists.newArrayList(dimensionId));
        dimensionInfoRequest.setBusinessId(businessId);
        DimensionResponse dimensionResponse = exMetadataConfigService.getDimension(dimensionInfoRequest);
        DimensionInfo dimensionInfo = null;
        if (dimensionResponse != null && dimensionResponse.getData() != null && dimensionResponse.getData().size() != 0) {
            dimensionInfo = dimensionResponse.getData().get(dimensionId);
            BeanCopyUtils.copyProperties(dimensionInfo, reduceDimensionInfo);
        } else {
            log.info("维度不存在：{}, response: {}", dimensionId, JsonUtils.toJson(dimensionResponse));
            return null;
        }
        Map<String, DimensionEnumVO> existEnumMap = Maps.newHashMap();
        List<DimensionEnumVO> dimensionEnumVOs = Lists.newArrayList();
        if (CollectionUtils.isNotEmpty(existEnumList)) {
            for (IndicatorReduceDimExtPO dimReduceDimEnumPO : existEnumList) {
                DimensionEnumVO dimensionEnumVO = new DimensionEnumVO();
                String dimensionCode = dimReduceDimEnumPO.getDimensionEnumCode();
                String dimensionName = dimReduceDimEnumPO.getDimensionEnumName();
                dimensionEnumVO.setDimensionEnumCode(dimensionCode);
                dimensionEnumVO.setDimensionEnumName(dimensionName);
                existEnumMap.put(dimensionCode, dimensionEnumVO);
            }
            dimensionEnumVOs = topicDimensionConfigService.wrapDimensionEnumList(dimensionId, existEnumMap, businessId);
        }
        List<DimensionEnumInfo> dimensionEnumInfos = Lists.newArrayList();
        for (DimensionEnumVO dimensionEnumVO : dimensionEnumVOs) {
            if (dimensionEnumVO.getIsSelected()) {
                DimensionEnumInfo dimensionEnumInfo = new DimensionEnumInfo();
                BeanUtils.copyProperties(dimensionEnumVO, dimensionEnumInfo);
                dimensionEnumInfos.add(dimensionEnumInfo);
            }
        }
        reduceDimensionInfo.setDimensionEnumInfos(dimensionEnumInfos);
        return reduceDimensionInfo;
    }

    @Override
    public GetBusinessIdResponse getReportBusinessId(GetBusinessIdRequest request) {
        try {
            Long reportId = request.getReportId();
            Long version = request.getVersion();
            String businessId = reportDao.getBusinessIdByReportId(reportId, version);
            GetBusinessIdResponse response = new GetBusinessIdResponse();
            response.setSuccess(true);
            response.setCode(ExceptionCodeEnum.SUCCESS.getCode());
            response.setBusinessId(businessId);
            return response;
        } catch (Exception e) {
            GetBusinessIdResponse errorResponse = new GetBusinessIdResponse();
            errorResponse.setCode(ExceptionCodeEnum.UNKNOWN_EXCEPTION.getCode());
            errorResponse.setMsg(e.getMessage());
            errorResponse.setSuccess(false);
            return errorResponse;
        }
    }
}
