package com.sankuai.tripdatecenter.databp.fenghuang.server.service;

import com.meituan.mdp.boot.starter.web.response.BusinessResponseData;
import com.sankuai.tripdatecenter.databp.fenghuang.common.domain.request.TmpAppRequestParam;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.tmpapp.IndicatorOrDimVO;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.tmpapp.TmpAppDetailVO;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.tmpapp.TmpAppInfoVO;

import java.util.List;

/**
 * description 临时应用Service接口
 *
 * @author nixuefeng
 * @createTime 2022/4/7 2:23 下午
 */
public interface TmpAppService {
    /**
     * 解析sql中字段内容
     * @param sql
     * @param tmpAppId
     * @param version
     * @return
     */
    List<IndicatorOrDimVO> sqlParseToFields(String sql, Long tmpAppId, Long version, String businessId);

    /**
     * 获取符合请求条件的临时应用
     *
     * @param requestParam
     * @return
     */
    BusinessResponseData<TmpAppInfoVO> listTmpApp(TmpAppRequestParam requestParam);

    /**
     * 根据tmpAppId和version获取临时应用详情
     *
     * @param tmpAppId
     * @param version  非必传
     * @return
     */
    TmpAppDetailVO getTmpAppDetail(Long tmpAppId, Long version, String businessId);

    /**
     * 上线该版本临时应用
     *
     * @param tmpAppId
     * @param version
     * @param isOnline
     * @return
     */
    boolean onlineTmpApp(Long tmpAppId, Long version, Short isOnline, String businessId);

    /**
     * 删除临时应用
     *
     * @param tmpAppId
     * @return
     */
    boolean removeTmpApp(Long tmpAppId, String businessId);

    /**
     * 提交临时应用
     *
     * @param tmpAppDetail
     * @return
     */
    boolean submitTmpApp(TmpAppDetailVO tmpAppDetail, String businessId);

    /**
     * 查询聚合方式枚举类别
     * @return
     */
    List<String> getAggregateFunction();
}
