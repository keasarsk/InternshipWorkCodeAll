package com.sankuai.tripdatecenter.databp.fenghuang.server.controller;

import com.meituan.mdp.boot.starter.web.response.BusinessResponseData;
import com.meituan.mdp.boot.starter.web.response.WebResponse;
import com.sankuai.tripdatecenter.databp.fenghuang.auth.annotation.FhAuth;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.BusinessLineService;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.FhAuthService;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.domain.BusinessLineVO;
import com.sankuai.tripdatecenter.databp.fenghuang.common.enums.ResponseCodeEnum;
import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.JsonUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.WutongUserUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.report.*;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.request.UpdateAssistAdminParam;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.tmpapp.IndicatorVO;
import com.sankuai.tripdatecenter.databp.fenghuang.server.constant.AuthConstants;
import com.sankuai.tripdatecenter.databp.fenghuang.server.controller.vo.ImportTopicParam;
import com.sankuai.tripdatecenter.databp.fenghuang.server.service.*;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.request.ReportRequestParam;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

import javax.annotation.Resource;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * description 报表管理controller
 *
 * @author nixuefeng
 * @createTime 2022/4/18 7:22 下午
 */
@RestController
@Api(description = "报表相关api")
@RequestMapping("/api/fh/report")
@Slf4j
public class ReportController {
    @Autowired
    private IndicatorService indicatorService;

    @Autowired
    private ReportService reportService;

    @Autowired
    private TopicService topicService;

    @Autowired
    private ModuleService moduleService;

    @Autowired
    private DimensionService dimensionService;

    @Autowired
    private IndicatorDimensionRelationService indicatorDimensionRelationService;

    @Autowired
    private TopicDimensionConfigService topicDimensionEnumService;

    @Resource
    private DimReduceConfigService dimReduceConfigService;

    @Autowired
    private BusinessLineService businessLineService;

    @Autowired
    private FhAuthService fhAuthService;

    @PostMapping("/list")
    @FhAuth(resourceCode = {"fenghuang_manage_menu_trip_report_list", "fenghuang_manage_menu_traffic_report_list"}, checkRelation = "OR")
    @ApiOperation(value = "报表列表")
    WebResponse<BusinessResponseData<ReportVO>> listReport(@RequestBody ReportRequestParam requestParam) {
        BusinessLineVO businessLineVO = businessLineService.getBusinessLineByBusinessId(requestParam.getBusinessId());
        requestParam.setBusinessId(businessLineVO.getBusinessId());
        String userMis = WutongUserUtils.getUser();
        Boolean noPermission = fhAuthService.checkPermission(userMis, AuthConstants.CONFIG_ADMIN_CODE);
        requestParam.setRelatedMis(null);
        if (noPermission) {
            requestParam.setRelatedMis(userMis);
        }
        return WebResponse.buildData(reportService.listReport(requestParam));
    }

    @PostMapping("/updateAssistAdmin")
    @ApiOperation(value = "报表协助管理员修改")
    WebResponse<ResponseCodeEnum> updateAssistAdmin(@RequestBody UpdateAssistAdminParam param) {
        log.info("param:{}", JsonUtils.toJson(param));
        BusinessLineVO businessLineVO = businessLineService.getBusinessLineByBusinessId(param.getBusinessId());
        param.setBusinessId(businessLineVO.getBusinessId());
        String operator = WutongUserUtils.getUser();
        if (reportService.updateReportAssistAdmin(param.getReportId(), businessLineVO.getBusinessId(), param.getAssistAdmin(), operator)) {
            return WebResponse.buildData(ResponseCodeEnum.SUCCESS);
        } else {
            return WebResponse.buildError(ResponseCodeEnum.UNKNOWN_ERROR.getCode(), "请检查该报表是否存在，同时检查是否具有该报表管理权限。");
        }
    }

    @PostMapping("/submit")
    @ApiOperation(value = "报表提交")
    WebResponse<ReportVO> submitReport(@RequestBody ReportVO report) {
        BusinessLineVO businessLineVO = businessLineService.getBusinessLineByBusinessId(report.getBusinessId());
        report.setBusinessId(businessLineVO.getBusinessId());
        if (reportService.submitReport(report)) {
            return WebResponse.buildData(report);
        } else {
            return WebResponse.buildError(ResponseCodeEnum.UNKNOWN_ERROR.getCode(), ResponseCodeEnum.UNKNOWN_ERROR.getMessage());
        }
    }

    @GetMapping("/auth/submit")
    @ApiOperation(value = "报表权限编辑")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "reportId", value = "报表Id", dataType = "Long", required = true, paramType = "query"),
            @ApiImplicitParam(name = "version", value = "报表版本", dataType = "Long", required = true, paramType = "query"),
            @ApiImplicitParam(name = "isAuth", value = "是否开启权限控制", dataType = "Boolean", required = true, paramType = "query")
    })
    WebResponse<ResponseCodeEnum> reportAuthSubmit(@RequestParam Long reportId, @RequestParam Long version, @RequestParam Boolean isAuth) {
        if (reportService.submitAuthConfig(reportId, version, isAuth)) {
            return WebResponse.buildData(ResponseCodeEnum.SUCCESS);
        } else {
            return WebResponse.buildError(ResponseCodeEnum.NOT_FOUND.getCode(), ResponseCodeEnum.NOT_FOUND.getMessage());
        }
    }

    @GetMapping("/auth/config")
    @ApiOperation(value = "报表权限获取")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "reportId", value = "报表Id", dataType = "Long", required = true, paramType = "query"),
            @ApiImplicitParam(name = "version", value = "报表版本", dataType = "Long", required = true, paramType = "query")
    })
    WebResponse<Boolean> reportAuthConfig(@RequestParam Long reportId, @RequestParam Long version) {
        return WebResponse.buildData(reportService.getAuthConfig(reportId, version));
    }

    @GetMapping("/online")
    @ApiOperation(value = "报表上线")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "reportId", value = "报表Id", dataType = "Long", required = true, paramType = "query"),
            @ApiImplicitParam(name = "version", value = "报表版本", dataType = "Long", required = true, paramType = "query"),
            @ApiImplicitParam(name = "isOnline", value = "是否上线", dataType = "Short", required = true, paramType = "query"),
            @ApiImplicitParam(name = "businessId", value = "业务线ID", dataType = "String", required = false, paramType = "query")
    })
    WebResponse<ResponseCodeEnum> onlineReport(@RequestParam Long reportId, @RequestParam Long version, @RequestParam Short isOnline, @RequestParam(required = false) String businessId) {
        BusinessLineVO businessLineVO = businessLineService.getBusinessLineByBusinessId(businessId);
        if (reportService.onlineReport(reportId, version, isOnline, businessLineVO.getBusinessId())) {
            return WebResponse.buildData(ResponseCodeEnum.SUCCESS);
        } else {
            return WebResponse.buildError(ResponseCodeEnum.NOT_FOUND.getCode(), ResponseCodeEnum.NOT_FOUND.getMessage());
        }
    }

    @GetMapping("/remove")
    @ApiOperation(value = "报表删除")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "reportId", value = "报表Id", dataType = "Long", required = true, paramType = "query")
    })
    WebResponse<ResponseCodeEnum> removeReport(@RequestParam Long reportId, @RequestParam Long version, @RequestParam(required = false) String businessId) {
        BusinessLineVO businessLineVO = businessLineService.getBusinessLineByBusinessId(businessId);
        if (reportService.removeReport(reportId, version, businessLineVO.getBusinessId())) {
            return WebResponse.buildData(ResponseCodeEnum.SUCCESS);
        } else {
            return WebResponse.buildError(ResponseCodeEnum.NOT_FOUND.getCode(), ResponseCodeEnum.NOT_FOUND.getMessage());
        }
    }

    @GetMapping("/topic/list")
    @ApiOperation(value = "报表主题列表")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "reportId", value = "报表Id", dataType = "Long", required = true, paramType = "query"),
            @ApiImplicitParam(name = "version", value = "报表版本", dataType = "Long", required = true, paramType = "query")
    })
    WebResponse<List<TopicVO>> listTopic(@RequestParam Long reportId, @RequestParam Long version, @RequestParam(required = false) String businessId) {
        BusinessLineVO businessLineVO = businessLineService.getBusinessLineByBusinessId(businessId);
        return WebResponse.buildData(topicService.listTopic(reportId, version));
    }

    @GetMapping("/topic/remove")
    @ApiOperation(value = "报表主题删除接口")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "topicId", value = "报表主题Id", dataType = "Long", required = true, paramType = "query"),
            @ApiImplicitParam(name = "version", value = "报表版本", dataType = "Long", required = true, paramType = "query")
    })
    WebResponse<ResponseCodeEnum> removeTopic(@RequestParam Long topicId, @RequestParam Long version, @RequestParam(required = false) String businessId) {
        BusinessLineVO businessLineVO = businessLineService.getBusinessLineByBusinessId(businessId);
        if (topicService.removeTopic(topicId, version, businessLineVO.getBusinessId())) {
            return WebResponse.buildData(ResponseCodeEnum.SUCCESS);
        } else {
            return WebResponse.buildError(ResponseCodeEnum.NOT_FOUND.getCode(), ResponseCodeEnum.NOT_FOUND.getMessage());
        }
    }

    @PostMapping("/topic/submit")
    @ApiOperation(value = "报表主题提交")
    WebResponse<ResponseCodeEnum> submitTopic(@RequestBody TopicVO topic) {
        if (topicService.submitTopic(topic)) {
            return WebResponse.buildData(ResponseCodeEnum.SUCCESS);
        } else {
            return WebResponse.buildError(ResponseCodeEnum.BAD_REQUEST.getCode(), ResponseCodeEnum.BAD_REQUEST.getMessage());
        }
    }

    @PostMapping("/topic/import")
    @ApiOperation(value = "报表主题导入")
    WebResponse<TopicVO> importTopic(@RequestBody ImportTopicParam importTopicParam) {
        return WebResponse.buildData(topicService.copyTopic(importTopicParam));
    }

    @PostMapping("/topic/update/name")
    @ApiOperation(value = "报表主题名称修改")
    WebResponse<ResponseCodeEnum> updateTopicName(@RequestBody TopicVO topic) {
        BusinessLineVO businessLineVO = businessLineService.getBusinessLineByBusinessId(topic.getBusinessId());
        topic.setBusinessId(businessLineVO.getBusinessId());
        if (topicService.updateTopicName(topic)) {
            return WebResponse.buildData(ResponseCodeEnum.SUCCESS);
        } else {
            return WebResponse.buildError(ResponseCodeEnum.BAD_REQUEST.getCode(), ResponseCodeEnum.BAD_REQUEST.getMessage());
        }
    }

    @PostMapping("/topic/sort")
    @ApiOperation(value = "报表主题排序")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "version", value = "报表版本", dataType = "Long", required = true, paramType = "query")
    })
    WebResponse<ResponseCodeEnum> sortTopic(@RequestBody List<Long> topicIds, @RequestParam Long version, @RequestParam(required = false) String businessId) {
        BusinessLineVO businessLineVO = businessLineService.getBusinessLineByBusinessId(businessId);
        topicService.sortTopic(topicIds, version, businessLineVO.getBusinessId());
        return WebResponse.buildData(ResponseCodeEnum.SUCCESS);
    }


    @GetMapping("/dimension/list")
    @ApiOperation(value = "报表维度列表")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "reportId", value = "报表Id", dataType = "Long", required = true, paramType = "query"),
            @ApiImplicitParam(name = "topicId", value = "主题Id", dataType = "Long", required = true, paramType = "query"),
            @ApiImplicitParam(name = "version", value = "报表版本", dataType = "Long", required = true, paramType = "query")
    })
    WebResponse<List<TopicDimensionVO>> listDimension(@RequestParam Long reportId, @RequestParam Long topicId, @RequestParam Long version) {
        return WebResponse.buildData(dimensionService.listDimension(reportId, topicId, version));
    }

    @GetMapping("/dimension/remove")
    @ApiOperation(value = "报表维度删除接口")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "reportId", value = "报表Id", dataType = "Long", required = true, paramType = "query"),
            @ApiImplicitParam(name = "topicId", value = "主题Id", dataType = "Long", required = true, paramType = "query"),
            @ApiImplicitParam(name = "dimensionId", value = "报表维度Id", dataType = "String", required = true, paramType = "query"),
            @ApiImplicitParam(name = "version", value = "报表版本", dataType = "Long", required = true, paramType = "query")
    })
    WebResponse<ResponseCodeEnum> removeDimension(@RequestParam Long reportId, @RequestParam Long topicId, @RequestParam String dimensionId, @RequestParam Long version) {
        if (dimensionService.removeDimension(reportId, topicId, dimensionId, version)) {
            return WebResponse.buildData(ResponseCodeEnum.SUCCESS);
        } else {
            return WebResponse.buildError(ResponseCodeEnum.NOT_FOUND.getCode(), ResponseCodeEnum.NOT_FOUND.getMessage());
        }
    }

    @PostMapping("/dimension/submit")
    @ApiOperation(value = "报表维度提交")
    WebResponse<ResponseCodeEnum> submitDimension(@RequestBody TopicDimensionVO dimension) {
        if (dimensionService.submitDimension(dimension)) {
            return WebResponse.buildData(ResponseCodeEnum.SUCCESS);
        } else {
            return WebResponse.buildError(ResponseCodeEnum.BAD_REQUEST.getCode(), ResponseCodeEnum.BAD_REQUEST.getMessage());
        }
    }

    @PostMapping("/dimension/sort")
    @ApiOperation(value = "报表维度排序")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "reportId", value = "报表Id", dataType = "Long", required = true, paramType = "query"),
            @ApiImplicitParam(name = "topicId", value = "主题Id", dataType = "Long", required = true, paramType = "query"),
            @ApiImplicitParam(name = "version", value = "报表版本", dataType = "Long", required = true, paramType = "query")
    })
    WebResponse<ResponseCodeEnum> sortDimension(@RequestBody List<String> dimensionIds, Long reportId, Long topicId, @RequestParam Long version) {
        dimensionService.sortDimension(dimensionIds, reportId, topicId, version);
        return WebResponse.buildData(ResponseCodeEnum.SUCCESS);
    }

    @GetMapping("/module/list")
    @ApiOperation(value = "报表模块列表")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "topicId", value = "报表Id", dataType = "Long", required = true, paramType = "query"),
            @ApiImplicitParam(name = "version", value = "报表版本", dataType = "Long", paramType = "query")
    })
    WebResponse<List<ModuleVO>> listModule(@RequestParam Long topicId, @RequestParam Long version) {
        return WebResponse.buildData(moduleService.listModule(topicId, version));
    }

    @GetMapping("/module/remove")
    @ApiOperation(value = "报表模块删除接口")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "moduleId", value = "模块Id", dataType = "Long", required = true, paramType = "query"),
            @ApiImplicitParam(name = "version", value = "报表版本", dataType = "Long", required = true, paramType = "query")
    })
    WebResponse<ResponseCodeEnum> removeModule(@RequestParam Long moduleId, @RequestParam Long version) {
        if (moduleService.removeModule(moduleId, version)) {
            return WebResponse.buildData(ResponseCodeEnum.SUCCESS);
        } else {
            return WebResponse.buildError(ResponseCodeEnum.NOT_FOUND.getCode(), ResponseCodeEnum.NOT_FOUND.getMessage());
        }
    }

    @PostMapping("/module/submit")
    @ApiOperation(value = "报表模块提交")
    WebResponse<ResponseCodeEnum> submitModule(@RequestBody ModuleVO module) {
        if (moduleService.submitModule(module)) {
            return WebResponse.buildData(ResponseCodeEnum.SUCCESS);
        } else {
            return WebResponse.buildError(ResponseCodeEnum.BAD_REQUEST.getCode(), ResponseCodeEnum.BAD_REQUEST.getMessage());
        }
    }

    @PostMapping("/module/sort")
    @ApiOperation(value = "报表模块排序")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "version", value = "报表版本", dataType = "Long", required = true, paramType = "query")
    })
    WebResponse<ResponseCodeEnum> sortModule(@RequestBody List<Long> moduleIds, @RequestParam Long version) {
        moduleService.sortModule(moduleIds, version);
        return WebResponse.buildData(ResponseCodeEnum.SUCCESS);
    }

    @PostMapping("/indicator/submit")
    @ApiOperation(value = "指标提交")
    public WebResponse<ResponseCodeEnum> submitIndicator(@RequestBody IndicatorTreeVO indicatorTreeVO) {
        indicatorService.submitIndicator(indicatorTreeVO);
        return WebResponse.buildData(ResponseCodeEnum.SUCCESS);
    }

    @PostMapping("/indicator/modify/v2")
    @ApiOperation(value = "wbr新版指标编辑接口")
    public WebResponse<ResponseCodeEnum> editIndicatorV2(@RequestBody TopicIndicatorVO topicIndicatorVO) {
        indicatorService.modifyIndicator(topicIndicatorVO);
        return WebResponse.buildData(ResponseCodeEnum.SUCCESS);
    }

    @PostMapping("/indicator/modify")
    @ApiOperation(value = "指标编辑")
    public WebResponse<ResponseCodeEnum> editIndicator(@RequestBody TopicIndicatorVO topicIndicatorVO) {
        indicatorService.modifyIndicator(topicIndicatorVO);
        return WebResponse.buildData(ResponseCodeEnum.SUCCESS);
    }

    @GetMapping("/indicator/offline")
    @ApiOperation(value = "指标下线")
    public WebResponse<ResponseCodeEnum> offlineIndicator(@RequestParam long curId) {
        indicatorService.offlineIndicator(curId);
        return WebResponse.buildData(ResponseCodeEnum.SUCCESS);
    }

    @GetMapping("/indicator/delete")
    @ApiOperation(value = "指标删除")
    public WebResponse<ResponseCodeEnum> deleteIndicator(@RequestParam long curId) {
        indicatorService.deleteIndicator(curId);
        return WebResponse.buildData(ResponseCodeEnum.SUCCESS);
    }

    @GetMapping("/indicator/list/v2")
    @ApiOperation(value = "指标列表")
    public WebResponse<List<TopicIndicatorVO>> treeIndicatorV2(@RequestParam long reportId, @RequestParam long version, @RequestParam long moduleId) {
        return WebResponse.buildData(indicatorService.getIndicatorTree(reportId, version, moduleId));
    }

    @GetMapping("/indicator/list")
    @ApiOperation(value = "指标列表")
    public WebResponse<List<TopicIndicatorVO>> treeIndicator(@RequestParam long reportId, @RequestParam long version, @RequestParam long moduleId) {
        return WebResponse.buildData(indicatorService.getIndicatorTree(reportId, version, moduleId));
    }

    @GetMapping("/indicator/list2")
    @ApiOperation(value = "指标列表")
    public WebResponse<List<IndicatorVO>> listIndicator(@RequestParam long reportId, @RequestParam long version, @RequestParam long topicId) {
        return WebResponse.buildData(indicatorService.getIndicatorListByTopicId(reportId, topicId, version));
    }

    @GetMapping("/relation/list")
    @ApiOperation(value = "指标维度关系列表")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "reportId", value = "报表Id", dataType = "Long", required = true, paramType = "query"),
            @ApiImplicitParam(name = "topicId", value = "主题Id", dataType = "Long", required = true, paramType = "query"),
            @ApiImplicitParam(name = "dimensionId", value = "报表维度Id", dataType = "String", required = true, paramType = "query"),
            @ApiImplicitParam(name = "version", value = "报表版本", dataType = "Long", required = true, paramType = "query")
    })
    public WebResponse<List<RelationVO>> listRelation(@RequestParam Long reportId, @RequestParam Long topicId, @RequestParam String dimensionId, @RequestParam Long version) {
        return WebResponse.buildData(indicatorDimensionRelationService.listIndicatorDimensionRelation(reportId, topicId, dimensionId, version));
    }

    @PostMapping("/relation/submit")
    @ApiOperation(value = "指标维度关系提交")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "reportId", value = "报表Id", dataType = "Long", required = true, paramType = "query"),
            @ApiImplicitParam(name = "topicId", value = "主题Id", dataType = "Long", required = true, paramType = "query"),
            @ApiImplicitParam(name = "dimensionId", value = "报表维度Id", dataType = "String", required = true, paramType = "query"),
            @ApiImplicitParam(name = "version", value = "报表版本", dataType = "Long", required = true, paramType = "query")
    })
    public WebResponse<ResponseCodeEnum> submitRelation(@RequestBody List<RelationVO> relations, @RequestParam Long reportId, @RequestParam Long topicId, @RequestParam String dimensionId, @RequestParam Long version) {
        if (indicatorDimensionRelationService.saveIndicatorDimensionRelation(relations, reportId, topicId, dimensionId, version)) {
            return WebResponse.buildData(ResponseCodeEnum.SUCCESS);
        } else {
            return WebResponse.buildError(ResponseCodeEnum.BAD_REQUEST.getCode(), ResponseCodeEnum.BAD_REQUEST.getMessage());
        }
    }

    @GetMapping("/dimension/config/info")
    @ApiOperation(value = "维度枚举列表")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "reportId", value = "报表Id", dataType = "Long", required = true, paramType = "query"),
            @ApiImplicitParam(name = "topicId", value = "主题Id", dataType = "Long", required = true, paramType = "query"),
            @ApiImplicitParam(name = "dimensionId", value = "报表维度Id", dataType = "String", required = true, paramType = "query"),
            @ApiImplicitParam(name = "version", value = "报表版本", dataType = "Long", required = true, paramType = "query")
    })
    public WebResponse<TopicDimensionExtVO> getConfig(@RequestParam Long reportId, @RequestParam Long topicId, @RequestParam String dimensionId, @RequestParam Long version) {
        return WebResponse.buildData(topicDimensionEnumService.getTopicDimensionConfig(reportId, topicId, dimensionId, version));
    }

    @PostMapping("/dimension/config/submit")
    @ApiOperation(value = "维度枚举提交")
    public WebResponse<ResponseCodeEnum> submitDimensionConfig(@RequestBody TopicDimensionExtVO config) {
        if (topicDimensionEnumService.saveTopicDimensionConfig(config)) {
            return WebResponse.buildData(ResponseCodeEnum.SUCCESS);
        } else {
            return WebResponse.buildError(ResponseCodeEnum.BAD_REQUEST.getCode(), ResponseCodeEnum.BAD_REQUEST.getMessage());
        }
    }

    @GetMapping("/dimension/enums/info")
    @ApiOperation(value = "维度枚举列表")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "dimensionId", value = "维度Id", dataType = "String", required = true, paramType = "query"),
    })
    public WebResponse<DimensionEnumsVO> getDimensionEnumsInfo(@RequestParam String dimensionId, @RequestParam String businessId) {
        return WebResponse.buildData(dimReduceConfigService.getDimensionEnums(dimensionId, businessId));
    }

    @GetMapping("/dimension/dimreduce/info")
    @ApiOperation(value = "降维维度枚举列表")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "reportId", value = "报表Id", dataType = "Long", required = true, paramType = "query"),
            @ApiImplicitParam(name = "topicId", value = "主题Id", dataType = "Long", required = true, paramType = "query"),
            @ApiImplicitParam(name = "version", value = "报表版本", dataType = "Long", required = true, paramType = "query"),
            @ApiImplicitParam(name = "indicatorId", value = "指标Id", dataType = "String", required = true, paramType = "query"),
            @ApiImplicitParam(name = "dimensionId", value = "维度Id", dataType = "String", required = true, paramType = "query"),
    })
    public WebResponse<DimReduceDimensionEnumsVO> getDimReduceDimensionConfig(@RequestParam Long reportId, @RequestParam Long topicId, @RequestParam Long version, @RequestParam String indicatorId, @RequestParam String dimensionId) {
        return WebResponse.buildData(dimReduceConfigService.getDimReduceDimensionEnums(reportId, topicId, version, indicatorId, dimensionId));
    }

    @PostMapping("/dimension/dimreduce/submit")
    @ApiOperation(value = "降维维度枚举提交")
    public WebResponse<ResponseCodeEnum> submitDimReduceDimensionConfig(@RequestBody DimReduceDimensionEnumsVO config) {
        if (dimReduceConfigService.saveDimReduceDimensionEnums(config)) {
            return WebResponse.buildData(ResponseCodeEnum.SUCCESS);
        } else {
            return WebResponse.buildError(ResponseCodeEnum.BAD_REQUEST.getCode(), ResponseCodeEnum.BAD_REQUEST.getMessage());
        }
    }

}
