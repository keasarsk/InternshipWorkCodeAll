package com.sankuai.tripdatecenter.databp.fenghuang.server.controller;

import com.meituan.mdp.boot.starter.web.response.WebResponse;
import com.sankuai.apa.origin.pojo.dim.DimDetail;
import com.sankuai.meituan.auth.util.UserUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.BusinessLineService;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.ExReportConfigService;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.WutongOrgService;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.ba.request.BaReportConfigRequest;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.ba.response.BaReportConfigResponse;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.domain.BusinessLineVO;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.request.DimReduceDimensionListRequest;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.request.GetUserAuthOrgsRequest;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.response.DimReduceDimensionListResponse;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.response.OrgTreeResponse;
import com.sankuai.tripdatecenter.databp.fenghuang.common.domain.filter.WutongOrgFilterVO;
import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.JsonUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.WutongUserUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.server.service.OriginService;
import com.sankuai.tripdatecenter.databp.fenghuang.server.service.ba.impl.BaReportConfigServiceImpl;
import com.sankuai.tripdatecenter.databp.fenghuang.server.task.CraneTask;
import io.swagger.annotations.Api;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * description 数据源Controller类
 *
 * @author mayuzhe
 * @date 2022-04-08
 */
@RestController
@Api("数据源相关api")
@RequestMapping("/test")
public class TestController {
    @Autowired
    private CraneTask craneTask;
    @Autowired
    private OriginService originService;

    @Autowired
    private BusinessLineService businessLineService;

    @Autowired
    private ExReportConfigService exReportConfigService;

    @Autowired WutongOrgService wutongOrgService;

    @GetMapping("/getMis")
    public WebResponse<String> getMis() {
        return WebResponse.buildData(WutongUserUtils.getUser());
    }

    @GetMapping("/getOriginDimDetail")
    public WebResponse<DimDetail> getOriginDimDetail(@RequestParam String dimCode, @RequestParam String businessId) {
        BusinessLineVO businessLineVO = businessLineService.getBusinessLineByBusinessId(businessId);
        DimDetail dimDetail = originService.getDimensionDetail(dimCode, businessLineVO);
        return WebResponse.buildData(dimDetail);
    }

    @GetMapping("/getWutongOrg")
    public WebResponse<List<WutongOrgFilterVO>> getWutongOrg(@RequestParam String mis, @RequestParam String type) {
        String org = wutongOrgService.getUserAuthV2(type, mis);
        List<WutongOrgFilterVO> list = JsonUtils.string2List(org, WutongOrgFilterVO.class);
        return WebResponse.buildData(list);
    }

    //@GetMapping("/test")
    //public WebResponse<DimReduceDimensionListResponse> getWutongOrg() {
    //    DimReduceDimensionListRequest request = new DimReduceDimensionListRequest();
    //    request.setReportId(9044l);
    //    request.setTopicId(9045l);
    //    request.setVersion(1l);
    //    DimReduceDimensionListResponse response = exReportConfigService.getDimReduceDimensionList(request);
    //    return WebResponse.buildData(response);
    //}


    @Autowired
    BaReportConfigServiceImpl baReportConfigServiceImpl;

    @GetMapping("/load")
    public WebResponse<BaReportConfigResponse> load(){
        BaReportConfigRequest request = new BaReportConfigRequest();
        request.setReportId(9201L);
        request.setBusinessId("trip");
        BaReportConfigResponse response = baReportConfigServiceImpl.getBaReportConfig(request);
        return WebResponse.buildData(response);
    }
}
