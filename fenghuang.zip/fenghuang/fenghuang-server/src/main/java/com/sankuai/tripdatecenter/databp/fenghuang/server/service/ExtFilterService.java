package com.sankuai.tripdatecenter.databp.fenghuang.server.service;

/**
 * description 特殊处理逻辑
 *
 * @author nixuefeng
 * @createTime 2023/3/20 17:29
 */
public interface ExtFilterService {
    /**
     * 是否获取维度枚举值
     * @param dimensionId
     * @return
     */
    boolean isQueryEnumByDimensionId(String dimensionId);
}
