package com.sankuai.tripdatecenter.databp.fenghuang.server.service;

import com.sankuai.tripdatecenter.databp.fenghuang.client.config.ba.domain.BaTopicDimensionInfo;

import java.util.List;
import java.util.Map;


/**
 * description 树形筛选器维值获取接口
 *
 * @author nixuefeng
 * @createTime 2023/3/16 20:49
 */
public interface TreeDimensionValueService {
    /**
     * 根据dimensionId获取维值信息
     * @return
     */
    BaTopicDimensionInfo queryEnumsByDimensionIds(String dimensionIds, Map<String, Boolean> authMap);
}
