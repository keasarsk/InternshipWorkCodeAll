package com.sankuai.tripdatecenter.databp.fenghuang.server.constant;

/**
 * description 起源配置
 *
 * @author fuzhengwei02
 * @createTime 2022年06月24日 10:51:00
 */
public class OriginConstants {

    /**
     * 起源配置信息模版版本
     */
    public static final Long ORIGIN_DEFAULT_VERSION = 1L;

    /**
     * 起源单位ID
     */
    public static final Integer ORIGIN_UNIT_ID_PERCENT = 8;
}
