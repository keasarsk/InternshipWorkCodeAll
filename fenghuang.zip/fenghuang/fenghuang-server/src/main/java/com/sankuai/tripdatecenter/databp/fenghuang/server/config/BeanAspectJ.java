package com.sankuai.tripdatecenter.databp.fenghuang.server.config;

import com.meituan.mtrace.Tracer;
import com.sankuai.meituan.auth.util.UserUtils;
import com.sankuai.meituan.auth.vo.User;
import com.sankuai.tripdatecenter.databp.fenghuang.common.constant.BizConstant;
import com.sankuai.tripdatecenter.databp.fenghuang.common.domain.user.FhUserInfo;
import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.JsonUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.WutongUserUtils;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

/**
 * description Bean切面
 *
 * @author fuzhengwei02
 * @createTime 2021年01月14日 16:05:00
 */
@Aspect
@Order(1)
@Component
@Slf4j
public class BeanAspectJ {

    /**
     * 方法环绕拦截
     *
     * @param pjp
     */
    @Around("execution(* com.sankuai.tripdatecenter.databp.fenghuang.server.service..*.*(..))")
    public Object methodAround(ProceedingJoinPoint pjp) {
        try {
            Object target = pjp.getTarget();
            String methodName = pjp.getSignature().getName();
            String className = target.getClass().getName();
            String paramsStr = JsonUtils.toJson(pjp.getArgs());
            FhUserInfo userInfo = WutongUserUtils.getFhUserInfo();
            log.info("classname : {} , method : {} , params : {} , userInfo : {}.", className, methodName, paramsStr, JsonUtils.toJson(userInfo));
            long startTime = System.currentTimeMillis();
            Object result = pjp.proceed();
            long cost = System.currentTimeMillis() - startTime;
            log.info("classname : {}, method : {} , cost : {} , result : {},  userInfo : {}.", className, methodName, cost, JsonUtils.toJson(result), JsonUtils.toJson(userInfo));
            return result;
        } catch (Throwable throwable) {
            log.error("proceed error:" + throwable.getMessage(), throwable);
            throw new RuntimeException(throwable);
        }
    }

    /**
     * 方法环绕拦截
     *
     * @param pjp
     */
    @Around("execution(* com.sankuai.apa.origin.service..*.*(..))")
    public Object originMethodAround(ProceedingJoinPoint pjp) {
        try {
            Object target = pjp.getTarget();
            String methodName = pjp.getSignature().getName();
            String className = target.getClass().getName();
            String paramsStr = JsonUtils.toJson(pjp.getArgs());
            FhUserInfo userInfo = WutongUserUtils.getFhUserInfo();
            log.info("origin method classname : {} , method : {} , params : {} , userInfo : {}.", className, methodName, paramsStr, JsonUtils.toJson(userInfo));
            long startTime = System.currentTimeMillis();
            Object result = pjp.proceed();
            long cost = System.currentTimeMillis() - startTime;
            log.info("origin method classname : {}, method : {} , cost : {} , result : {},  userInfo : {}.", className, methodName, cost, JsonUtils.toJson(result), JsonUtils.toJson(userInfo));
            return result;
        } catch (Throwable throwable) {
            log.error("origin method proceed error:" + throwable.getMessage(), throwable);
            throw new RuntimeException(throwable);
        }
    }



    @Pointcut("within(@org.springframework.web.bind.annotation.RestController *)")
    public void controllerPointCut() {}

    @Before("controllerPointCut()")
    public void methodBefore(JoinPoint pjp) {
        Object target = pjp.getTarget();
        String methodName = pjp.getSignature().getName();
        String className = target.getClass().getName();
        String paramsStr = JsonUtils.toJson(pjp.getArgs());
        String userMis = WutongUserUtils.getUser();
        log.info("classname : {} , method : {} , params : {}, useInfo : {}.", className, methodName, paramsStr, userMis);
        FhUserInfo fhUserInfo = WutongUserUtils.getFhUserInfo();
        if(fhUserInfo != null){
            Tracer.getAllContext().put(BizConstant.FH_SSO_USER_KEY, JsonUtils.toJson(fhUserInfo));
            log.info("用户信息写入Tracer : {}", JsonUtils.toJson(fhUserInfo));
        }
    }
}
