package com.sankuai.tripdatecenter.databp.fenghuang.server.service;

import com.sankuai.tripdatecenter.databp.fenghuang.client.config.domain.BusinessLineVO;
import com.sankuai.tripdatecenter.databp.fenghuang.common.exception.FHErrorException;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.report.TopicDimensionVO;

import java.util.List;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2022/4/21 3:10 下午
 */
public interface DimensionService {
    /**
     * 获取指定版本主题下维度列表
     *
     * @param reportId
     * @param topicId
     * @param version
     * @return
     */
    List<TopicDimensionVO> listDimension(Long reportId, Long topicId, Long version) throws FHErrorException;

    /**
     * 提交维度信息
     *
     * @param dimension
     * @return
     */
    boolean submitDimension(TopicDimensionVO dimension) throws FHErrorException;

    /**
     * 删除维度信息
     *
     * @param dimensionId
     * @param version
     * @return
     * @throws FHErrorException
     */
    boolean removeDimension(Long reportId, Long topicId, String dimensionId, Long version) throws FHErrorException;

    /**
     * 删除报表下所有维度
     *
     * @param reportId
     * @param version
     * @return
     * @throws FHErrorException
     */
    boolean removeDimensions(Long reportId, Long version) throws FHErrorException;

    /**
     * 主题下维度排序
     *
     * @param dimensionIds
     * @param reportId
     * @param topicId
     * @param version
     * @throws FHErrorException
     */
    void sortDimension(List<String> dimensionIds, Long reportId, Long topicId, Long version) throws FHErrorException;

    List<String> checkTopicDimensions(List<String> dimensionIds, BusinessLineVO businessLineVO);

}
