package com.sankuai.tripdatecenter.databp.fenghuang.server.service;

import com.sankuai.tripdatecenter.databp.fenghuang.client.config.request.GetAllAreasRequest;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.request.GetAllOrgsRequest;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.request.GetUserAuthAreasRequest;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.request.GetUserAuthOrgsRequest;
import com.sankuai.tripdatecenter.databp.fenghuang.common.domain.result.DataResult;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.auth.AuthFilterVO;

/**
 * description 组织架构树功能
 *
 * @author fuzhengwei02
 * @createTime 2022年04月28日 14:11:00
 */
public interface CommonOrgService {

    /**
     * 获取所有组织架构树V1(带SKA)
     * @param getAllOrgsRequest
     * @return
     */
    DataResult<AuthFilterVO> getAllOrgsV1(GetAllOrgsRequest getAllOrgsRequest);

    /**
     * 获取所有组织架构树V2（不带SKA）
     * @param getAllOrgsRequest
     * @return
     */
    DataResult<AuthFilterVO> getAllOrgsV2(GetAllOrgsRequest getAllOrgsRequest);

    /**
     * 获取所有组织架构树V1(带SKA)
     * @param getAllOrgsRequest
     * @return
     */
    DataResult<AuthFilterVO> getAllOrgs4mV1(GetAllOrgsRequest getAllOrgsRequest);

    /**
     * 获取所有组织架构树V2（不带SKA）
     * @param getAllOrgsRequest
     * @return
     */
    DataResult<AuthFilterVO> getAllOrgs4mV2(GetAllOrgsRequest getAllOrgsRequest);

    /**
     * 获取所有区域架构树V1(带SKA)
     * @param getAllAreasRequest
     * @return
     */
    DataResult<AuthFilterVO> getAllAreasV1(GetAllAreasRequest getAllAreasRequest);

    /**
     * 获取所有区域架构树V2（不带SKA）
     * @param getAllAreasRequest
     * @return
     */
    DataResult<AuthFilterVO> getAllAreasV2(GetAllAreasRequest getAllAreasRequest);

    /**
     * 获取人员有权限的组织架构树V1(带SKA)
     * @param getUserAuthOrgsRequest
     * @return
     */
    DataResult<AuthFilterVO> getUserAuthOrgsV1(GetUserAuthOrgsRequest getUserAuthOrgsRequest);

    /**
     * 获取人员有权限的组织架构树（不带SKA）
     * @param getUserAuthOrgsRequest
     * @return
     */
    DataResult<AuthFilterVO> getUserAuthOrgsV2(GetUserAuthOrgsRequest getUserAuthOrgsRequest);

    /**
     * 获取人员有权限的区域架构树V1(带SKA)
     * @param getUserAuthAreasRequest
     * @return
     */
    DataResult<AuthFilterVO> getUserAuthAreasV1(GetUserAuthAreasRequest getUserAuthAreasRequest);

    /**
     * 获取人员有权限的区域架构树（不带SKA）
     * @param getUserAuthAreasRequest
     * @return
     */
    DataResult<AuthFilterVO> getUserAuthAreasV2(GetUserAuthAreasRequest getUserAuthAreasRequest);

    /**
     * 更新组织架构树节点
     * @param resourceCode
     * @param authFilterVO
     * @return
     */
    DataResult<Boolean> updateOrgTreeNodes(String resourceCode, AuthFilterVO authFilterVO);

    /**
     * 初始化组织架构树
     */
    void initOrgAreaTreeNode();

    /**
     * 初始化BD授权
     */
    void initBdAuth();

    /**
     * 非BD自动授权
     */
    void initNotBdAuth();

    /**
     * 迁移经营仪表存量权限
     */
    void moveHistoryAuth();

    /**
     * 获取用户权限信息
     * @param misId
     * @param resourceCode
     * @return
     */
    DataResult<AuthFilterVO> getUserAuthResource(String misId, String resourceCode);

}
