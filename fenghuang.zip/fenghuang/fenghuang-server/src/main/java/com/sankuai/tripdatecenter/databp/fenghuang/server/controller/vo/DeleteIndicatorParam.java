package com.sankuai.tripdatecenter.databp.fenghuang.server.controller.vo;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
public class DeleteIndicatorParam implements Serializable {

    private List<String> indicatorIds;

    private String businessId;

}
