package com.sankuai.tripdatecenter.databp.fenghuang.server.utils;

import com.dianping.cat.util.StringUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.common.enums.AppTypeEnum;
import com.sankuai.tripdatecenter.databp.fenghuang.common.enums.FieldTypeEnum;
import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.WutongUserUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.DimensionPO;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.IndicatorPO;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.tmpapp.IndicatorOrDimVO;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.Date;

import com.sankuai.tripdatecenter.databp.fenghuang.common.constant.SymbolConstant;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2022/4/6 8:29 下午
 */
@Data
@ToString
@NoArgsConstructor
public class IndicatorOrDimVOUtil {

    public static IndicatorOrDimVO buildIndicatorOrDimVOByIndicator(IndicatorPO indicatorPO){
        IndicatorOrDimVO indicatorOrDimVO = new IndicatorOrDimVO();
        indicatorOrDimVO.setId(indicatorPO.getIndicatorId());
        indicatorOrDimVO.setFieldCode(indicatorPO.getIndicatorCode());
        indicatorOrDimVO.setShowName(indicatorPO.getIndicatorName());
        indicatorOrDimVO.setFieldType(FieldTypeEnum.INDICATOR.getCode());
        indicatorOrDimVO.setAggregateType(indicatorPO.getAggregateFunction());
        indicatorOrDimVO.setDesc(indicatorPO.getIndicatorComment());
        return indicatorOrDimVO;
    }

    public static IndicatorPO createIndicatorPO(IndicatorOrDimVO indicatorOrDimVO){
        IndicatorPO indicatorPO = new IndicatorPO();
        if(StringUtils.isEmpty(indicatorOrDimVO.getId())){
            indicatorPO.setIndicatorId(indicatorOrDimVO.getDesc().concat(SymbolConstant.CONCAT_UNDERLINE).concat(AppTypeEnum.TMP_APP.getCode()));
        }else {
            indicatorPO.setIndicatorId(indicatorOrDimVO.getId());
        }
        indicatorPO.setIndicatorCode(indicatorOrDimVO.getFieldCode());
        indicatorPO.setIndicatorName(indicatorOrDimVO.getShowName());
        indicatorPO.setAggregateFunction(indicatorOrDimVO.getAggregateType());
        indicatorPO.setIndicatorComment(indicatorOrDimVO.getDesc());
        indicatorPO.setCreatedTime(new Date());
        indicatorPO.setUpdateTime(new Date());
        indicatorPO.setIndicatorType("");
        indicatorPO.setAppType(AppTypeEnum.TMP_APP.getCode());
        if(StringUtils.isEmpty(indicatorPO.getCreatedMis())){
            indicatorPO.setCreatedMis(WutongUserUtils.getUser());
        }
        indicatorPO.setLastUpdateMis(WutongUserUtils.getUser());
        return indicatorPO;
    }

    public static IndicatorOrDimVO buildIndicatorOrDimVOByDimension(DimensionPO dimensionPO){
        IndicatorOrDimVO indicatorOrDimVO = new IndicatorOrDimVO();
        indicatorOrDimVO.setId(dimensionPO.getDimensionId());
        indicatorOrDimVO.setFieldCode(dimensionPO.getDimensionCode());
        indicatorOrDimVO.setShowName(dimensionPO.getDimensionName());
        indicatorOrDimVO.setFieldType(FieldTypeEnum.DIMENSION.getCode());
        indicatorOrDimVO.setDesc(dimensionPO.getDimensionComment());
        return indicatorOrDimVO;
    }

    public static DimensionPO createDimensionPO(IndicatorOrDimVO indicatorOrDimVO){
        DimensionPO dimensionPO = new DimensionPO();
        if(StringUtils.isEmpty(indicatorOrDimVO.getId())){
            dimensionPO.setDimensionId(indicatorOrDimVO.getFieldCode().concat(SymbolConstant.CONCAT_UNDERLINE).concat(AppTypeEnum.TMP_APP.getCode()));
        }else {
            dimensionPO.setDimensionId(indicatorOrDimVO.getId());
        }
        dimensionPO.setDimensionCode(indicatorOrDimVO.getFieldCode());
        dimensionPO.setAppType(AppTypeEnum.TMP_APP.getCode());
        dimensionPO.setDimensionName(indicatorOrDimVO.getShowName());
        dimensionPO.setDimensionComment(indicatorOrDimVO.getDesc());
        dimensionPO.setCreatedTime(new Date());
        dimensionPO.setUpdateTime(new Date());
        dimensionPO.setDimensionType("");
        if(StringUtils.isEmpty(dimensionPO.getCreatedMis())){
            dimensionPO.setCreatedMis(WutongUserUtils.getUser());
        }
        dimensionPO.setLastUpdateMis(WutongUserUtils.getUser());
        return dimensionPO;
    }
}
