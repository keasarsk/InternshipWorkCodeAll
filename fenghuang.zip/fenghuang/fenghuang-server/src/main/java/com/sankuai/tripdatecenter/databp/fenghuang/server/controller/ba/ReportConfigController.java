package com.sankuai.tripdatecenter.databp.fenghuang.server.controller.ba;

import com.meituan.mdp.boot.starter.web.response.WebResponse;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.ba.BaReportConfigService;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.ba.request.BaReportConfigRequest;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.ba.response.BaReportConfigResponse;
import com.sankuai.tripdatecenter.databp.fenghuang.common.enums.ResponseCodeEnum;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.ba.AuthTopicVO;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.ba.BaTopicVO;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.report.TemplateVO;
import com.sankuai.tripdatecenter.databp.fenghuang.server.service.TemplateService;
import com.sankuai.tripdatecenter.databp.fenghuang.server.service.ba.BaTopicService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * description 经营分析模版报表配置Controller
 *
 * @author nixuefeng
 * @createTime 2023/2/27 10:36
 */
@RestController
@Api(description = "经营分析模版，报表相关api")
@RequestMapping("/api/fh/ba/report")
public class ReportConfigController {

    @Autowired
    private TemplateService templateService;

    @Autowired
    private BaTopicService baTopicService;

    @Autowired
    private BaReportConfigService baReportConfigService;

    @GetMapping("/topic/detail")
    @ApiOperation(value = "报表主题详情接口")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "topicId", value = "报表主题Id", dataType = "Long", required = true, paramType = "query"),
            @ApiImplicitParam(name = "businessId", value = "业务线ID", dataType = "String", required = true, paramType = "query")
    })
    WebResponse<BaTopicVO> detailTopic(@RequestParam long topicId, @RequestParam String businessId) {
        return WebResponse.buildData(baTopicService.queryBaTopicDetail(topicId));
    }

    @PostMapping("/topic/modify")
    @ApiOperation(value = "报表主题提交")
    WebResponse<ResponseCodeEnum> modifyTopic(@RequestBody BaTopicVO baTopicVO) {
        if (baTopicService.modifyBaTopic(baTopicVO)) {
            return WebResponse.buildData(ResponseCodeEnum.SUCCESS);
        } else {
            return WebResponse.buildError(ResponseCodeEnum.UNKNOWN_ERROR.getCode(), "主题信息编辑失败");
        }
    }

    @GetMapping("/template/list")
    @ApiOperation(value = "模板类型")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "topicId", value = "报表主题Id", dataType = "Long", required = true, paramType = "query")
    })
    WebResponse<List<TemplateVO>> queryTemplate(@RequestParam(required = false) Long topicId) {
        return WebResponse.buildData(templateService.listTemplate(topicId));
    }

    @GetMapping("/config/test")
    @ApiOperation(value = "报表配置测试接口")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "topicId", value = "报表Id", dataType = "Long", required = true, paramType = "query"),
            @ApiImplicitParam(name = "moduleId", value = "报表Id", dataType = "Long", required = true, paramType = "query")
    })
    WebResponse<BaReportConfigResponse> queryTemplate(@RequestParam long reportId, @RequestParam String businessId) {
        BaReportConfigRequest request = new BaReportConfigRequest();
        request.setReportId(reportId);
        request.setBusinessId("trip");
        return WebResponse.buildData(baReportConfigService.getBaReportConfig(request));
    }

    @GetMapping("/topic/auth/list")
    @ApiOperation(value = "报表主题列表")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "reportId", value = "报表Id", dataType = "Long", required = true, paramType = "query"),
            @ApiImplicitParam(name = "version", value = "报表版本", dataType = "Long", required = true, paramType = "query")
    })
    WebResponse<List<AuthTopicVO>> listTopic(@RequestParam Long reportId, @RequestParam Long version) {
        return WebResponse.buildData(baTopicService.queryAuthTopicList(reportId, version));
    }
}
