package com.sankuai.tripdatecenter.databp.fenghuang.server.controller.ba;

import com.meituan.mdp.boot.starter.web.response.WebResponse;
import com.sankuai.tripdatecenter.databp.fenghuang.common.enums.ResponseCodeEnum;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.ba.BaDimVO;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.ba.BaTopicIndicatorCollectionVO;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.ba.BaTopicIndicatorVO;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.report.RelationVO;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.tmpapp.DimensionVO;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.tmpapp.IndicatorVO;
import com.sankuai.tripdatecenter.databp.fenghuang.server.service.DimensionMetaService;
import com.sankuai.tripdatecenter.databp.fenghuang.server.service.ba.BaIndicatorService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2023/2/27 14:12
 */
@RestController
@Api(description = "经营分析模版，指标相关api")
@RequestMapping("/api/fh/ba/report/indicator")
public class IndicatorConfigController {
    @Autowired
    private BaIndicatorService baIndicatorService;

    @Autowired
    private DimensionMetaService dimensionMetaService;

    @PostMapping("/sort")
    @ApiOperation(value = "指标排序")
    public WebResponse<ResponseCodeEnum> sortIndicators(@RequestBody List<String> indicatorIds, @RequestParam Long moduleId) {
        baIndicatorService.sortIndicators(indicatorIds, moduleId);
        return WebResponse.buildData(ResponseCodeEnum.SUCCESS);
    }

    @PostMapping("/submit")
    @ApiOperation(value = "指标提交")
    public WebResponse<ResponseCodeEnum> submitIndicator(@RequestBody BaTopicIndicatorCollectionVO baTopicIndicatorCollectionVO) {
        baIndicatorService.submitIndicator(baTopicIndicatorCollectionVO);
        return WebResponse.buildData(ResponseCodeEnum.SUCCESS);
    }

    @PostMapping("/modify")
    @ApiOperation(value = "指标编辑")
    public WebResponse<ResponseCodeEnum> editIndicator(@RequestBody BaTopicIndicatorVO topicIndicatorVO) {
        baIndicatorService.modifyIndicator(topicIndicatorVO);
        return WebResponse.buildData(ResponseCodeEnum.SUCCESS);
    }

    @GetMapping("/remove")
    @ApiOperation(value = "指标删除")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "moduleId", value = "模块Id", dataType = "Long", required = true, paramType = "query"),
            @ApiImplicitParam(name = "indicatorId", value = "指标Id", dataType = "String", required = true, paramType = "query")
    })
    public WebResponse<ResponseCodeEnum> deleteIndicator(@RequestParam long moduleId, @RequestParam String indicatorId) {
        baIndicatorService.deleteIndicator(moduleId, indicatorId);
        return WebResponse.buildData(ResponseCodeEnum.SUCCESS);
    }

    @GetMapping("/list")
    @ApiOperation(value = "指标列表")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "moduleId", value = "模块Id", dataType = "Long", required = true, paramType = "query")
    })
    public WebResponse<List<BaTopicIndicatorVO>> listIndicator(@RequestParam long moduleId) {
        return WebResponse.buildData(baIndicatorService.getIndicatorsByModule(moduleId));
    }

    @GetMapping("/dimEnum/indicator/list")
    @ApiOperation(value = "维度枚举配置指标列表")
    public WebResponse<List<BaTopicIndicatorVO>> listIndicator(@RequestParam long reportId, @RequestParam long topicId) {
        return WebResponse.buildData(baIndicatorService.getIndicatorBaseInfoByTopic(topicId));
    }

    @GetMapping("/relation/list")
    @ApiOperation(value = "指标维度关系列表")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "reportId", value = "报表Id", dataType = "Long", required = true, paramType = "query"),
            @ApiImplicitParam(name = "topicId", value = "主题Id", dataType = "Long", required = true, paramType = "query"),
            @ApiImplicitParam(name = "dimensionId", value = "报表维度Id", dataType = "String", required = true, paramType = "query"),
    })
    public WebResponse<List<RelationVO>> listRelation(@RequestParam Long reportId, @RequestParam Long topicId, @RequestParam String dimensionId) {
        return WebResponse.buildData(baIndicatorService.listIndicatorDimensionRelation(reportId, topicId, dimensionId));
    }

    @PostMapping("/relation/submit")
    @ApiOperation(value = "指标维度关系提交")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "reportId", value = "报表Id", dataType = "Long", required = true, paramType = "query"),
            @ApiImplicitParam(name = "topicId", value = "主题Id", dataType = "Long", required = true, paramType = "query"),
            @ApiImplicitParam(name = "dimensionId", value = "报表维度Id", dataType = "String", required = true, paramType = "query"),
            @ApiImplicitParam(name = "businessId", value = "业务线id", dataType = "String", required = false, paramType = "query")
    })
    public WebResponse<ResponseCodeEnum> submitRelation(@RequestBody List<RelationVO> relations, @RequestParam Long reportId, @RequestParam Long topicId, @RequestParam String dimensionId, @RequestParam(required = false) String businessId) {
        if (baIndicatorService.saveIndicatorDimensionRelation(relations, businessId, reportId, topicId, dimensionId)) {
            return WebResponse.buildData(ResponseCodeEnum.SUCCESS);
        } else {
            return WebResponse.buildError(ResponseCodeEnum.BAD_REQUEST.getCode(), ResponseCodeEnum.BAD_REQUEST.getMessage());
        }
    }

    @GetMapping("/detail/dimension/list")
    @ApiOperation(value = "明细展示获取维度接口")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "appSource", value = "应用Id", dataType = "Int", required = true, paramType = "query"),
            @ApiImplicitParam(name = "appId", value = "应用Id", dataType = "Long", required = true, paramType = "query"),
            @ApiImplicitParam(name = "businessId", value = "业务线Id", dataType = "String", required = true, paramType = "query")
    })
    public WebResponse<List<BaDimVO>> listDimensionByAppId(@RequestParam Integer appSource, @RequestParam Long appId, @RequestParam String businessId) {
        return WebResponse.buildData(dimensionMetaService.getDimensionListByApp(appSource, appId, businessId));
    }
}
