package com.sankuai.tripdatecenter.databp.fenghuang.server.controller;

import com.meituan.mdp.boot.starter.web.response.BusinessResponseData;
import com.meituan.mdp.boot.starter.web.response.WebResponse;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.BusinessLineService;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.domain.BusinessLineVO;
import com.sankuai.tripdatecenter.databp.fenghuang.common.domain.request.IndicatorRequestParam;
import com.sankuai.tripdatecenter.databp.fenghuang.common.enums.ResponseCodeEnum;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.tmpapp.IndicatorVO;
import com.sankuai.tripdatecenter.databp.fenghuang.server.controller.vo.DeleteIndicatorParam;
import com.sankuai.tripdatecenter.databp.fenghuang.server.controller.vo.SaveIndicatorListParam;
import com.sankuai.tripdatecenter.databp.fenghuang.server.service.IndicatorMetaService;
import com.sankuai.tripdatecenter.databp.fenghuang.server.service.IndicatorService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import javafx.print.Collation;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * description 指标元数据相关接口
 *
 * @author nixuefeng
 * @createTime 2022/4/13 11:32 上午
 */

@RestController
@Api(description = "指标元数据相关api")
@RequestMapping("/api/fh/indicator")
public class IndicatorMetaController {

    @Autowired
    private IndicatorMetaService indicatorMetaService;

    @Autowired
    private IndicatorService indicatorService;

    @Autowired
    private BusinessLineService businessLineService;

    @PostMapping("/origin/list")
    @ApiOperation("拉取起源中指标列表")
    WebResponse<BusinessResponseData<IndicatorVO>> listIndicatorMeta(@RequestBody IndicatorRequestParam requestParam) {
        return WebResponse.buildData(indicatorMetaService.listIndicatorFromOrigin(requestParam));
    }

    @PostMapping("/list")
    @ApiOperation("系统收纳指标列表")
    WebResponse<BusinessResponseData<IndicatorVO>> listIndicatorByTmpApp(@RequestBody IndicatorRequestParam requestParam) {
        return WebResponse.buildData(indicatorMetaService.listIndicator(requestParam));
    }

    @PostMapping("/save")
    @ApiOperation("起源中指标同步到凤凰中")
    WebResponse<ResponseCodeEnum> saveIndicatorList(@RequestBody SaveIndicatorListParam param) {
        String businessId = param.getBusinessId();
        List<IndicatorVO> indicators = param.getIndicators();
        BusinessLineVO businessLineVO = businessLineService.getBusinessLineByBusinessId(businessId);
        if(CollectionUtils.isNotEmpty(indicators)){
            if (indicatorMetaService.saveIndicatorMeta(indicators, businessLineVO.getBusinessId())) {
                return WebResponse.buildData(ResponseCodeEnum.SUCCESS);
            }
            return WebResponse.buildError(ResponseCodeEnum.INDICATOR_IS_EXISTED.getCode(), ResponseCodeEnum.INDICATOR_IS_EXISTED.getMessage());
        }
        return WebResponse.buildError(ResponseCodeEnum.UNKNOWN_ERROR.getCode(), "同步指标数量为空");
    }

    @PostMapping("/delete")
    @ApiOperation("起源中指标从凤凰中删除")
    WebResponse<ResponseCodeEnum> deleteIndicator(@RequestBody DeleteIndicatorParam param) {
        String businessId = param.getBusinessId();
        List<String> indicatorIds = param.getIndicatorIds();
        BusinessLineVO businessLineVO = businessLineService.getBusinessLineByBusinessId(businessId);
        // 检查待删指标是否被报表使用 fenghuang_info_topic_indicator
        List<String> existIndicatorReportId = indicatorService.checkTopicIndicators(indicatorIds);
        if (existIndicatorReportId.size() == 0){
            // 没有被使用，本地池中删除 fenghuang_info_indicator
            if (indicatorMetaService.deleteIndicatorMeta(indicatorIds, businessLineVO.getBusinessId())) {
                return WebResponse.buildData(ResponseCodeEnum.SUCCESS);
            }
            return WebResponse.buildError(ResponseCodeEnum.UNKNOWN_ERROR.getCode(), ResponseCodeEnum.UNKNOWN_ERROR.getMessage());
        }
        else {
            String msg = ResponseCodeEnum.INDICATOR_DELETE_FAILED.getMessage();
            StringBuilder reportIds = new StringBuilder();
            if(existIndicatorReportId.size() > 3){
                for(int i = 0;i < 3;i++){
                    if(i != 2)  reportIds.append(existIndicatorReportId.get(i)).append(",");
                    else reportIds.append(existIndicatorReportId.get(i));
                }
                reportIds.append("...");
            }
            else{
                for(int i = 0;i < existIndicatorReportId.size();i++){
                    if(i != existIndicatorReportId.size()-1)    reportIds.append(existIndicatorReportId.get(i)).append(",");
                    else reportIds.append(existIndicatorReportId.get(i));
                }
            }
            return WebResponse.buildError(ResponseCodeEnum.INDICATOR_DELETE_FAILED.getCode(), msg.replace("{}",reportIds.toString()));
        }
    }


}
