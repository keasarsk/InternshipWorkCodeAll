package com.sankuai.tripdatecenter.databp.fenghuang.server.utils;

import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ext.TmpAppExtPO;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.tmpapp.TmpAppInfoVO;
import lombok.Data;
import lombok.ToString;

/**
 * description 临时应用VO
 * @author nixuefeng
 * @createTime 2022/4/6 8:18 下午
 */
@Data
@ToString
public class TmpAppInfoVOUtil {

    public static TmpAppInfoVO buildTmpAppInfoVOByPO(TmpAppExtPO tmpAppPO){
        TmpAppInfoVO tmpAppInfoVO = new TmpAppInfoVO();
        tmpAppInfoVO.setId(tmpAppPO.getId());
        tmpAppInfoVO.setTmpAppId(tmpAppPO.getTmpappId());
        tmpAppInfoVO.setTmpAppName(tmpAppPO.getTmpappName());
        tmpAppInfoVO.setDataSourceId(tmpAppPO.getDatasourceId());
        tmpAppInfoVO.setDataSourceName(tmpAppPO.getDatasourceName());
        tmpAppInfoVO.setDataSourceType(tmpAppPO.getDatasourceType());
        tmpAppInfoVO.setCreatedMis(tmpAppPO.getCreatedMis());
        tmpAppInfoVO.setIsOnline(tmpAppPO.getIsOnline());
        tmpAppInfoVO.setVersion(tmpAppPO.getVersion());
        return tmpAppInfoVO;
    }
}
