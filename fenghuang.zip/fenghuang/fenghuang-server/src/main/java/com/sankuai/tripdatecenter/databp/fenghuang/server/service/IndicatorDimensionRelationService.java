package com.sankuai.tripdatecenter.databp.fenghuang.server.service;

import com.sankuai.tripdatecenter.databp.fenghuang.domain.report.IndicatorDimensionRelationVO;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.report.RelationVO;

import java.util.List;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2022/4/24 4:31 下午
 */
public interface IndicatorDimensionRelationService {
    /**
     * 根据报表、主题、维度、版本信息获取指标维度矩阵
     * @param reportId
     * @param topicId
     * @param dimensionId
     * @param version
     * @return
     */
    List<RelationVO> listIndicatorDimensionRelation(Long reportId, Long topicId, String dimensionId, Long version);

    /**
     * 保存指标维度矩阵列表
     * @param relations
     * @param reportId
     * @param topicId
     * @param dimensionId
     * @param version
     * @return
     */
    boolean saveIndicatorDimensionRelation(List<RelationVO> relations,Long reportId, Long topicId, String dimensionId, Long version);

    /**
     * 删除指标维度矩阵关系
     * @param indicatorDimensionRelation
     * @return
     */
    boolean removeIndicatorDimensionRelation(IndicatorDimensionRelationVO indicatorDimensionRelation);
}
