package com.sankuai.tripdatecenter.databp.fenghuang.server.service;

import com.google.common.collect.Lists;
import com.sankuai.tripdatecenter.databp.fenghuang.common.domain.user.FhUserInfo;
import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.JsonUtils;
import lombok.extern.slf4j.Slf4j;

import java.util.Date;
import java.util.List;

@Slf4j
public abstract class EntityCopier<T>{

    /**
     * 操作时间
     */
    private Date operateDate;

    /**
     * 操作人信息
     */
    private FhUserInfo operateUser;

    /**
     * 旧实体项
     */
    private List<T> _oldItems = Lists.newArrayList();

    /**
     * 新实体项
     */
    private List<T> _newItems = Lists.newArrayList();

    /**
     * 操作人
     * @return
     */
    protected abstract FhUserInfo getOperateUserInfo();

    /**
     * 操作时间
     * @return
     */
    protected abstract Date getOperateTime();

    /**
     * 复制实体名称
     * @return
     */
    protected abstract String getEntityName();

    /**
     * 复制对应表
     * @return
     */
    protected abstract String getTableName();

    /**
     * 需要复制实体列表
     * @return
     */
    protected abstract List<T> getWaitItems();

    /**
     * 生成新实体
     * @return
     */
    protected abstract List<T> generateNewItems(List<T> oldItems);

    /**
     * 新实体保存
     * @return
     */
    protected abstract int batchInsert(List<T> newItems);

    /**
     * 执行复制操作
     * @return 返回新实体信息
     */
    public List<T> execute(){
        String entityName= getEntityName();
        String tableName = getTableName();
        log.info("开始复制实体:{},对应表:{}", entityName, tableName);
        _oldItems = getWaitItems();
        log.info("需要旧实体:{}", JsonUtils.toJson(_oldItems));
        _newItems = generateNewItems(_oldItems);
        log.info("生成新实体:{}", JsonUtils.toJson(_newItems));
        int insertResult = batchInsert(_newItems);
        log.info("最终: 实体 {}， 插入表 {}，{}条记录。", entityName, tableName, insertResult);
        return _newItems;
    }

}
