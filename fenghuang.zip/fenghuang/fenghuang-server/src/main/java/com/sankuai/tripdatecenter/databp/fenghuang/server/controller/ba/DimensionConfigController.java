package com.sankuai.tripdatecenter.databp.fenghuang.server.controller.ba;

import com.meituan.mdp.boot.starter.web.response.WebResponse;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.BusinessLineService;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.domain.BusinessLineVO;
import com.sankuai.tripdatecenter.databp.fenghuang.common.enums.ResponseCodeEnum;
import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.JsonUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.ba.BaAuthTopicVO;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.ba.BaRelationTopicDimensionVO;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.report.*;
import com.sankuai.tripdatecenter.databp.fenghuang.server.service.ba.BaDimensionService;
import com.sankuai.tripdatecenter.databp.fenghuang.server.service.ba.BaTopicDimensionAuthService;
import com.sankuai.tripdatecenter.databp.fenghuang.server.service.ba.BaTopicDimensionRelationService;
import com.sankuai.tripdatecenter.databp.fenghuang.server.service.ba.BaTopicDimensionService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2023/2/27 14:40
 */
@RestController
@Api(description = "经营分析模版，维度相关api")
@RequestMapping("/api/fh/ba/report/dimension")
public class DimensionConfigController {
    @Autowired
    private BusinessLineService businessLineService;
    @Autowired
    private BaDimensionService baDimensionService;
    @Autowired
    private BaTopicDimensionService baTopicDimensionEnumService;
    @Autowired
    private BaTopicDimensionRelationService baTopicDimensionRelationService;
    @Autowired
    private BaTopicDimensionAuthService baTopicDimensionAuthService;


    @GetMapping("/list")
    @ApiOperation(value = "报表维度列表")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "topicId", value = "主题Id", dataType = "Long", required = true, paramType = "query"),
            @ApiImplicitParam(name = "businessId", value = "业务线", dataType = "String", required = false, paramType = "query")
    })
    WebResponse<List<TopicDimensionVO>> listDimension(@RequestParam Long topicId, @RequestParam(required = false) String businessId) {
        BusinessLineVO businessLineVO = businessLineService.getBusinessLineByBusinessId(businessId);
        return WebResponse.buildData(baDimensionService.listDimension(topicId, businessLineVO));
    }

    @GetMapping("/remove")
    @ApiOperation(value = "报表维度删除接口")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "topicId", value = "主题Id", dataType = "Long", required = true, paramType = "query"),
            @ApiImplicitParam(name = "dimensionId", value = "报表维度Id", dataType = "String", required = true, paramType = "query"),
            @ApiImplicitParam(name = "businessId", value = "业务线", dataType = "String", required = false, paramType = "query")
    })
    WebResponse<ResponseCodeEnum> removeDimension(@RequestParam Long topicId, @RequestParam String dimensionId, @RequestParam(required = false) String businessId) {
        BusinessLineVO businessLineVO = businessLineService.getBusinessLineByBusinessId(businessId);
        if (baDimensionService.removeDimension(topicId, dimensionId, businessLineVO)) {
            return WebResponse.buildData(ResponseCodeEnum.SUCCESS);
        } else {
            return WebResponse.buildError(ResponseCodeEnum.NOT_FOUND.getCode(), ResponseCodeEnum.NOT_FOUND.getMessage());
        }
    }

    @PostMapping("/submit")
    @ApiOperation(value = "报表维度提交")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "businessId", value = "业务线", dataType = "String", required = false, paramType = "query")
    })
    WebResponse<ResponseCodeEnum> submitDimension(@RequestBody TopicDimensionVO dimension, @RequestParam(required = false) String businessId) {
        BusinessLineVO businessLineVO = businessLineService.getBusinessLineByBusinessId(businessId);
        if (baDimensionService.submitDimension(dimension, businessLineVO)) {
            return WebResponse.buildData(ResponseCodeEnum.SUCCESS);
        } else {
            return WebResponse.buildError(ResponseCodeEnum.BAD_REQUEST.getCode(), ResponseCodeEnum.BAD_REQUEST.getMessage());
        }
    }

    @PostMapping("/sort")
    @ApiOperation(value = "报表维度排序")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "topicId", value = "主题Id", dataType = "Long", required = true, paramType = "query"),
            @ApiImplicitParam(name = "businessId", value = "业务线", dataType = "String", required = false, paramType = "query")
    })
    WebResponse<ResponseCodeEnum> sortDimension(@RequestBody List<String> dimensionIds, @RequestParam Long topicId, @RequestParam(required = false) String businessId) {
        BusinessLineVO businessLineVO = businessLineService.getBusinessLineByBusinessId(businessId);
        baDimensionService.sortDimension(dimensionIds, topicId, businessLineVO);
        return WebResponse.buildData(ResponseCodeEnum.SUCCESS);
    }

    @GetMapping("/config/detail")
    @ApiOperation(value = "筛选组件配置及维度枚举信息")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "topicId", value = "主题Id", dataType = "Long", required = true, paramType = "query"),
            @ApiImplicitParam(name = "dimensionId", value = "报表维度Id", dataType = "String", required = true, paramType = "query"),
            @ApiImplicitParam(name = "businessId", value = "业务线", dataType = "String", required = false, paramType = "query")
    })
    public WebResponse<TopicDimensionExtVO> getConfig(@RequestParam Long topicId, @RequestParam String dimensionId, @RequestParam(required = false) String businessId) {
        return WebResponse.buildData(baTopicDimensionEnumService.getTopicDimensionConfig(topicId, dimensionId));
    }

    @GetMapping("/date/type")
    @ApiOperation(value = "日期类型接口")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "businessId", value = "业务线", dataType = "String", required = false, paramType = "query")
    })
    public WebResponse<List<DimensionEnumVO>> dateType(@RequestParam(required = false) String businessId) {
        return WebResponse.buildData(baTopicDimensionEnumService.allDateDimensionEnumList());
    }

    @PostMapping("/config/submit")
    @ApiOperation(value = "筛选器组件配置及维度枚举配置提交接口")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "businessId", value = "业务线", dataType = "String", required = false, paramType = "query")
    })
    public WebResponse<ResponseCodeEnum> submitDimensionConfig(@RequestBody TopicDimensionExtVO config, @RequestParam(required = false) String businessId) {
        if (baTopicDimensionEnumService.saveTopicDimensionConfig(config)) {
            return WebResponse.buildData(ResponseCodeEnum.SUCCESS);
        } else {
            return WebResponse.buildError(ResponseCodeEnum.BAD_REQUEST.getCode(), ResponseCodeEnum.BAD_REQUEST.getMessage());
        }
    }

    @GetMapping("/relation/list")
    @ApiOperation(value = "筛选器级联关系")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "topicId", value = "主题Id", dataType = "Long", required = true, paramType = "query"),
            @ApiImplicitParam(name = "dimensionId", value = "报表维度Id", dataType = "String", required = true, paramType = "query"),
            @ApiImplicitParam(name = "businessId", value = "业务线", dataType = "String", required = false, paramType = "query")
    })
    public WebResponse<BaRelationTopicDimensionVO> listRelation(@RequestParam Long topicId, @RequestParam String dimensionId, @RequestParam(required = false) String businessId) {
        return WebResponse.buildData(baTopicDimensionRelationService.getDimensionRelation(topicId, dimensionId, businessId));
    }

    @PostMapping("/relation/submit")
    @ApiOperation(value = "筛选器级联关系提交")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "businessId", value = "业务线", dataType = "String", required = false, paramType = "query")
    })
    public WebResponse<ResponseCodeEnum> submitRelation(@RequestBody BaRelationTopicDimensionVO baRelationTopicDimensionVO, @RequestParam(required = false) String businessId) {
        if (baTopicDimensionRelationService.submitDimensionRelation(baRelationTopicDimensionVO, businessId)) {
            return WebResponse.buildData(ResponseCodeEnum.SUCCESS);
        } else {
            return WebResponse.buildError(ResponseCodeEnum.BAD_REQUEST.getCode(), ResponseCodeEnum.BAD_REQUEST.getMessage());
        }
    }

    @PostMapping("/auth/submit")
    @ApiOperation(value = "权限信息提交接口")
    public WebResponse<ResponseCodeEnum> submitAuthConfig(@RequestBody BaAuthTopicVO baAuthTopicVO) {
        if (baTopicDimensionAuthService.editAuthConfig(baAuthTopicVO)) {
            return WebResponse.buildData(ResponseCodeEnum.SUCCESS);
        } else {
            return WebResponse.buildError(ResponseCodeEnum.BAD_REQUEST.getCode(), ResponseCodeEnum.BAD_REQUEST.getMessage());
        }
    }

    @GetMapping("/auth/config")
    @ApiOperation(value = "权限信息获取接口")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "topicId", value = "主题Id", dataType = "Long", required = true, paramType = "query")
    })
    WebResponse<BaAuthTopicVO> authConfig(@RequestParam Long topicId, @RequestParam(required = false) String businessId) {
        return WebResponse.buildData(baTopicDimensionAuthService.queryAuthConfig(topicId));
    }


}
