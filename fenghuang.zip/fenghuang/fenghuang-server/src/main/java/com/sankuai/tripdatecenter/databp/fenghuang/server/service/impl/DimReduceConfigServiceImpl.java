package com.sankuai.tripdatecenter.databp.fenghuang.server.service.impl;

import com.sankuai.tripdatecenter.databp.fenghuang.client.config.BusinessLineService;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.domain.BusinessLineVO;
import com.sankuai.tripdatecenter.databp.fenghuang.common.constant.*;

import com.google.common.collect.Lists;
import com.sankuai.apa.origin.pojo.dim.DimDict;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.ExMetadataConfigService;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.ExReportConfigService;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.domain.DimensionEnumInfo;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.domain.DimensionInfo;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.request.DimReduceDimensionRequest;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.request.DimensionInfoRequest;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.response.DimReduceDimensionResponse;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.response.DimensionResponse;
import com.sankuai.tripdatecenter.databp.fenghuang.common.enums.DeleteStatusEnum;
import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.JsonUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.WutongUserUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.ReportDao;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.mapper.auto.DimReduceDimEnumPOMapper;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.mapper.ext.DimReduceDimEnumPOMapperExt;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.DimReduceDimEnumPO;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.report.DimReduceDimensionEnumsVO;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.report.DimensionEnumVO;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.report.DimensionEnumsVO;
import com.sankuai.tripdatecenter.databp.fenghuang.server.service.DimReduceConfigService;
import com.sankuai.tripdatecenter.databp.fenghuang.server.service.ExtFilterService;
import com.sankuai.tripdatecenter.databp.fenghuang.server.service.OriginService;
import java.util.Date;
import java.util.List;
import javax.annotation.Resource;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * description 降维配置相关接口实现
 *
 * @author fuzhengwei02
 * @createTime 2022年09月19日 20:15:00
 */
@Service
@Slf4j
public class DimReduceConfigServiceImpl implements DimReduceConfigService {

    @Resource
    private DimReduceDimEnumPOMapper dimReduceDimEnumPOMapper;

    @Resource
    private DimReduceDimEnumPOMapperExt dimReduceDimEnumPOMapperExt;

    @Resource
    private ExReportConfigService exReportConfigService;

    @Resource
    private ExMetadataConfigService exMetadataConfigService;

    @Resource
    private OriginService originService;

    @Autowired
    private BusinessLineService businessLineService;

    @Autowired
    private ExtFilterService extFilterService;

    @Autowired
    private ReportDao reportDao;

    @Override
    public boolean saveDimReduceDimensionEnums(DimReduceDimensionEnumsVO dimReduceDimensionEnumsVO) {
        Long reportId = dimReduceDimensionEnumsVO.getReportId();
        Long topicId = dimReduceDimensionEnumsVO.getTopicId();
        Long version = dimReduceDimensionEnumsVO.getVersion();
        String indicatorId = dimReduceDimensionEnumsVO.getIndicatorId();
        String dimensionId = dimReduceDimensionEnumsVO.getDimensionId();
        String misId = WutongUserUtils.getUser();
        int deleteResult = dimReduceDimEnumPOMapperExt.deleteTopicIndicatorDimReduce(reportId, topicId, version, indicatorId);
        log.info("删除结果{}, reportId:{}, topicId:{}, version:{}, indicatorId:{}, dimensionId:{}", deleteResult, reportId, topicId, version, indicatorId);
        int index = 0;
        if(CollectionUtils.isNotEmpty(dimReduceDimensionEnumsVO.getDimensionEnums())){
            for(DimensionEnumVO dimensionEnumVO : dimReduceDimensionEnumsVO.getDimensionEnums()){
                if(dimensionEnumVO.getIsSelected() != null && dimensionEnumVO.getIsSelected()){
                    DimReduceDimEnumPO dimReduceDimEnumPO = new DimReduceDimEnumPO();
                    dimReduceDimEnumPO.setReportId(reportId);
                    dimReduceDimEnumPO.setTopicId(topicId);
                    dimReduceDimEnumPO.setVersion(version);
                    dimReduceDimEnumPO.setIndicatorId(indicatorId);
                    dimReduceDimEnumPO.setDimensionId(dimensionId);
                    dimReduceDimEnumPO.setOrderNum(index ++);
                    dimReduceDimEnumPO.setCreatedMis(misId);
                    dimReduceDimEnumPO.setCreatedTime(new Date());
                    dimReduceDimEnumPO.setDimensionEnumCode(dimensionEnumVO.getDimensionEnumCode());
                    dimReduceDimEnumPO.setDimensionEnumName(dimensionEnumVO.getDimensionEnumName());
                    dimReduceDimEnumPO.setIsDelete(DeleteStatusEnum.NOT_DELETED.getCode());
                    dimReduceDimEnumPOMapper.insert(dimReduceDimEnumPO);
                }
            }
            log.info("新增 {} 条记录。", index);
        }
        return true;
    }

    @Override
    public DimReduceDimensionEnumsVO getDimReduceDimensionEnums(Long reportId, Long topicId, Long version, String indicatorId, String dimensionId) {
        DimReduceDimensionRequest request = new DimReduceDimensionRequest();
        request.setReportId(reportId);
        request.setTopicId(topicId);
        request.setVersion(version);
        request.setIndicatorId(indicatorId);
        String businessId = reportDao.getBusinessIdByReportId(reportId, version);
        DimReduceDimensionResponse response = exReportConfigService.getDimReduceDimensionInfo(request);
        if(response != null && response.getDimensionInfo() != null){
            DimReduceDimensionEnumsVO dimReduceDimensionEnumsVO = new DimReduceDimensionEnumsVO();
            DimensionInfo dimensionInfo = response.getDimensionInfo();
            dimReduceDimensionEnumsVO.setReportId(reportId);
            dimReduceDimensionEnumsVO.setTopicId(topicId);
            dimReduceDimensionEnumsVO.setVersion(version);
            dimReduceDimensionEnumsVO.setIndicatorId(indicatorId);
            dimReduceDimensionEnumsVO.setDimensionId(dimensionId);
            dimReduceDimensionEnumsVO.setDimensionName(dimensionInfo.getDimensionName());
            if(CollectionUtils.isNotEmpty(response.getDimensionEnumInfos())){
                List<DimensionEnumVO> dimensionEnumVOS = Lists.newArrayList();
                List<DimensionEnumInfo> dimensionEnumInfos = response.getDimensionEnumInfos();
                List<DimDict> dimDicts = getOriginDimDicts(dimensionId, businessId);
                for(DimDict dimDict : dimDicts){
                    String dimCode = dimDict.getDimCode();
                    String dimName = dimDict.getDimName();
                    DimensionEnumVO dimensionEnumVO = new DimensionEnumVO();
                    dimensionEnumVO.setDimensionEnumCode(dimCode);
                    dimensionEnumVO.setOriginDimensionEnumName(dimName);
                    DimensionEnumInfo matchedDimensionEnumInfo = getSelectedDimensionEnumInfo(dimCode, dimensionEnumInfos);
                    if(matchedDimensionEnumInfo != null){
                        dimensionEnumVO.setDimensionEnumName(matchedDimensionEnumInfo.getDimensionEnumName());
                        dimensionEnumVO.setIsSelected(true);
                    }else{
                        dimensionEnumVO.setDimensionEnumName(dimName);
                        dimensionEnumVO.setIsSelected(false);
                    }
                    dimensionEnumVOS.add(dimensionEnumVO);
                }
                dimReduceDimensionEnumsVO.setDimensionEnums(dimensionEnumVOS);
            }
            return dimReduceDimensionEnumsVO;
        }
        log.info("未找到维度信息：{}", JsonUtils.toJson(response));
        return null;
    }

    private DimensionEnumInfo getSelectedDimensionEnumInfo(String dimCode, List<DimensionEnumInfo> dimensionEnumInfos){
        if(CollectionUtils.isNotEmpty(dimensionEnumInfos)){
            for(DimensionEnumInfo dimensionEnumInfo : dimensionEnumInfos){
                if(dimensionEnumInfo.getDimensionEnumCode().equals(dimCode)){
                    return dimensionEnumInfo;
                }
            }
        }
        return null;
    }

    private List<DimDict> getOriginDimDicts(String dimensionId, String businessId){
        BusinessLineVO businessLineVO = businessLineService.getBusinessLineByBusinessId(businessId);
        String dimensionCode = dimensionId.substring(NumberConstant.ZERO, dimensionId.lastIndexOf(SymbolConstant.CONCAT_UNDERLINE));
        List<DimDict> dimDicts = originService.getDimensionDict(dimensionCode, businessLineVO);
        if (CollectionUtils.isEmpty(dimDicts)) {
            log.info("起源中没有配置，维度[{}]的枚举值", dimensionCode);
            dimDicts = Lists.newArrayList();
        }
        return dimDicts;
    }

    @Override
    public DimensionEnumsVO getDimensionEnums(String dimensionId, String businessId) {
        DimensionInfoRequest dimensionInfoRequest = new DimensionInfoRequest();
        dimensionInfoRequest.setDimensionIds(Lists.newArrayList(dimensionId));
        dimensionInfoRequest.setBusinessId(businessId);
        DimensionResponse dimensionResponse = exMetadataConfigService.getDimension(dimensionInfoRequest);
        DimensionInfo dimensionInfo = null;
        if(dimensionResponse != null && dimensionResponse.getData() != null && dimensionResponse.getData().size() != 0){
            dimensionInfo = dimensionResponse.getData().get(dimensionId);
        } else {
            return null;
        }
        DimensionEnumsVO dimensionEnumsVO = new DimensionEnumsVO();
        dimensionEnumsVO.setDimensionId(dimensionId);
        dimensionEnumsVO.setDimensionName(dimensionInfo.getDimensionName());
        List<DimensionEnumVO> dimensionEnumVOS = Lists.newArrayList();
        if(extFilterService.isQueryEnumByDimensionId(dimensionId)){
            List<DimDict> dimDicts = getOriginDimDicts(dimensionId, businessId);
            dimDicts.stream().forEach(dimDict -> {
                String dimEnumCode = dimDict.getDimCode();
                String dimEnumName = dimDict.getDimName();
                DimensionEnumVO enumVO = new DimensionEnumVO();
                enumVO.setDimensionEnumCode(dimEnumCode);
                enumVO.setDimensionEnumName(dimEnumName);
                enumVO.setOriginDimensionEnumName(dimEnumName);
                enumVO.setIsSelected(true);
                dimensionEnumVOS.add(enumVO);
            });
            dimensionEnumsVO.setDimensionEnums(dimensionEnumVOS);
            return dimensionEnumsVO;
        }else{
            dimensionEnumsVO.setDimensionEnums(dimensionEnumVOS);
            return dimensionEnumsVO;
        }
    }
}
