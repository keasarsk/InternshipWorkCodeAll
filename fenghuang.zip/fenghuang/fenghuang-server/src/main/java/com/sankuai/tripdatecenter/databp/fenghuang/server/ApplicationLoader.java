package com.sankuai.tripdatecenter.databp.fenghuang.server;

import com.cip.crane.client.spring.annotation.CraneConfiguration;
import com.sankuai.tripdatecenter.databp.fenghuang.auth.annotation.EnableDataBpAuth;
import com.sankuai.tripdatecenter.databp.fenghuang.cache.annotation.EnableDataBpCache;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import com.meituan.mdp.boot.starter.MdpContextUtils;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ImportResource;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@EnableTransactionManagement
@ComponentScan(value = {"com.sankuai.tripdatecenter.databp.fenghuang.server",
        "com.sankuai.tripdatecenter.databp.fenghuang.dataservice",
        "com.sankuai.tripdatecenter.databp.fenghuang.dao",
        "com.sankuai.tripdatecenter.databp.fenghuang.common"
})
@EnableDataBpCache
@EnableDataBpAuth
@CraneConfiguration
@SpringBootApplication(exclude={DataSourceAutoConfiguration.class})
@ImportResource("classpath:spring/application-context.xml")
@Slf4j
public class ApplicationLoader {

    public static void main(String[] args) {
        SpringApplication application = new SpringApplication(ApplicationLoader.class);
        application.setAdditionalProfiles(MdpContextUtils.getHostEnvStr());
        application.run(args);
        log.info("服务启动完毕。");
    }

}



