package com.sankuai.tripdatecenter.databp.fenghuang.server.controller.vo;

import com.sankuai.tripdatecenter.databp.fenghuang.domain.tmpapp.IndicatorVO;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
public class SaveIndicatorListParam implements Serializable {

    private List<IndicatorVO> indicators;

    private String businessId;
}
