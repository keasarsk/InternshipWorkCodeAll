package com.sankuai.tripdatecenter.databp.fenghuang.server.controller;

import com.meituan.mdp.boot.starter.web.response.BusinessResponseData;
import com.meituan.mdp.boot.starter.web.response.WebResponse;
import com.sankuai.tripdatecenter.databp.fenghuang.common.enums.ResponseCodeEnum;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.report.MetaReportVO;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.report.ReportVO;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.request.ReportRequestParam;
import com.sankuai.tripdatecenter.databp.fenghuang.server.service.MetaReportService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * description 凤凰定制化产品报表元数据
 *
 * @author nixuefeng
 * @createTime 2022/9/22 20:39
 */
@RestController
@Api(description = "定制化报表相关api")
@RequestMapping("/api/fh/biz/report")
public class MetaReportController {

    @Autowired
    private MetaReportService metaReportService;

    @PostMapping("/list")
    @ApiOperation(value = "报表列表")
    WebResponse<BusinessResponseData<MetaReportVO>> listReport(@RequestBody ReportRequestParam requestParam) {
        return WebResponse.buildData(metaReportService.listReport(requestParam));
    }

    @PostMapping("/submit")
    @ApiOperation(value = "报表提交")
    WebResponse<ResponseCodeEnum> submitReport(@RequestBody MetaReportVO report) {
        if (metaReportService.submitReport(report)) {
            return WebResponse.buildData(ResponseCodeEnum.SUCCESS);
        } else {
            return WebResponse.buildError(ResponseCodeEnum.UNKNOWN_ERROR.getCode(), ResponseCodeEnum.UNKNOWN_ERROR.getMessage());
        }
    }

    @GetMapping("/online")
    @ApiOperation(value = "报表上线")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "reportId", value = "报表Id", dataType = "String", required = true, paramType = "query"),
            @ApiImplicitParam(name = "topicId", value = "TabId", dataType = "String", required = true, paramType = "query"),
            @ApiImplicitParam(name = "version", value = "报表版本", dataType = "Short", required = true, paramType = "query"),
            @ApiImplicitParam(name = "isOnline", value = "是否上线", dataType = "Short", required = true, paramType = "query")
    })
    WebResponse<ResponseCodeEnum> onlineReport(@RequestParam String reportId,@RequestParam String topicId, @RequestParam Short version, @RequestParam Short isOnline) {
        if (metaReportService.onlineReport(reportId, topicId, version, isOnline)) {
            return WebResponse.buildData(ResponseCodeEnum.SUCCESS);
        } else {
            return WebResponse.buildError(ResponseCodeEnum.NOT_FOUND.getCode(), ResponseCodeEnum.NOT_FOUND.getMessage());
        }
    }

    @GetMapping("/remove")
    @ApiOperation(value = "报表删除")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "reportId", value = "报表Id", dataType = "String", required = true, paramType = "query"),
            @ApiImplicitParam(name = "topicId", value = "主题Id", dataType = "String", required = true, paramType = "query"),
            @ApiImplicitParam(name = "version", value = "版本信息", dataType = "Short", required = true, paramType = "query")
    })
    WebResponse<ResponseCodeEnum> removeReport(@RequestParam String reportId, @RequestParam String topicId, @RequestParam Short version) {
        if (metaReportService.removeReport(reportId, topicId,version)) {
            return WebResponse.buildData(ResponseCodeEnum.SUCCESS);
        } else {
            return WebResponse.buildError(ResponseCodeEnum.NOT_FOUND.getCode(), ResponseCodeEnum.NOT_FOUND.getMessage());
        }
    }
}
