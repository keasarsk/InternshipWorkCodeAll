package com.sankuai.tripdatecenter.databp.fenghuang.server.controller;

import com.meituan.mdp.boot.starter.web.response.BusinessResponseData;
import com.meituan.mdp.boot.starter.web.response.WebResponse;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.BusinessLineService;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.domain.BusinessLineVO;
import com.sankuai.tripdatecenter.databp.fenghuang.common.domain.user.UserInfo;
import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.WutongUserUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.meta.AppDetailVO;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.meta.AppVO;
import com.sankuai.tripdatecenter.databp.fenghuang.server.service.AppMetaService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * description  应用Controller类
 *
 * @author fuzhengwei02
 * @date 2022-06-24
 */
@RestController
@Api("起源应用数据相关api")
@RequestMapping("/api/fh/app")
public class AppMetaController {
    @Autowired
    private AppMetaService appMetaService;

    @Autowired
    private BusinessLineService businessLineService;

    @GetMapping("/origin/list")
    @ApiOperation("拉取起源中应用列表")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "pageNum", value = "pageNum", dataType = "int", required = true, paramType = "query"),
            @ApiImplicitParam(name = "pageSize", value = "pageSize", dataType = "int", required = true, paramType = "query"),
            @ApiImplicitParam(name = "appName", value = "应用名称", dataType = "String", required = false, paramType = "query"),
            @ApiImplicitParam(name = "appId", value = "应用Id", dataType = "int", required = false, paramType = "query")
    })
    public WebResponse<BusinessResponseData<AppVO>> getOriginAppList(@RequestParam int pageNum, @RequestParam int pageSize, @RequestParam(required = false) String appName, @RequestParam(required = false) Integer appId, @RequestParam String businessId) {
        BusinessLineVO businessLineVO = businessLineService.getBusinessLineByBusinessId(businessId);
        return WebResponse.buildData(appMetaService.getAppListFromOrigin(pageNum, pageSize, appName, appId, businessLineVO));
    }

    @GetMapping("/origin/local/list")
    @ApiOperation("拉取维度池中维度列表")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "pageNum", value = "pageNum", dataType = "int", required = true, paramType = "query"),
            @ApiImplicitParam(name = "pageSize", value = "pageSize", dataType = "int", required = true, paramType = "query"),
            @ApiImplicitParam(name = "appName", value = "应用名称", dataType = "String", required = false, paramType = "query"),
            @ApiImplicitParam(name = "appId", value = "应用Id", dataType = "int", required = false, paramType = "query")
    })
    public WebResponse<BusinessResponseData<AppVO>> getOriginAppLocalList(@RequestParam int pageNum, @RequestParam int pageSize, @RequestParam(required = false) String appName, @RequestParam(required = false) Integer appId, @RequestParam String businessId) {
        BusinessLineVO businessLineVO = businessLineService.getBusinessLineByBusinessId(businessId);
        return WebResponse.buildData(appMetaService.getLocalAppList(pageNum, pageSize, appName, appId, businessLineVO));
    }

    @PostMapping("/origin/local/add")
    @ApiOperation("添加起源应用到本地应用池中")
    public WebResponse<String> addAppToLocalFromOrigin(@RequestParam AppVO originApp, @RequestParam String businessId) {
        BusinessLineVO businessLineVO = businessLineService.getBusinessLineByBusinessId(businessId);
        String misId = WutongUserUtils.getUser();
        UserInfo userInfo = new UserInfo();
        userInfo.setMisId(misId);
        appMetaService.addAppFromOrigin(originApp, userInfo, businessLineVO);
        return WebResponse.buildData("200");
    }

    @PostMapping("/origin/local/delete")
    @ApiOperation("删除起源应用从本地应用池")
    public WebResponse<String> deleteAppFromLocal(@RequestParam Integer originAppId, @RequestParam String businessId) {
        BusinessLineVO businessLineVO = businessLineService.getBusinessLineByBusinessId(businessId);
        String misId = WutongUserUtils.getUser();
        UserInfo userInfo = new UserInfo();
        userInfo.setMisId(misId);
        appMetaService.deleteLocalAppInfo(originAppId, userInfo, businessLineVO);
        return WebResponse.buildData("200");
    }

    @GetMapping("/origin/detail")
    public WebResponse<AppDetailVO> getAppDetail(@RequestParam Integer originAppId, @RequestParam String businessId) {
        BusinessLineVO businessLineVO = businessLineService.getBusinessLineByBusinessId(businessId);
        return WebResponse.buildData(appMetaService.getLocalAppInfo(originAppId, businessLineVO));
    }

    @GetMapping("/sync/indDim")
    public WebResponse<String> syncAppIndDim(@RequestParam Integer originAppId, @RequestParam String businessId, @RequestParam(required = false) Boolean isOverwrite) {
        BusinessLineVO businessLineVO = businessLineService.getBusinessLineByBusinessId(businessId);
        appMetaService.syncAppIndDim(originAppId, businessLineVO, isOverwrite);
        return WebResponse.buildData("200");
    }
}
