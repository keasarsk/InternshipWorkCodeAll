package com.sankuai.tripdatecenter.databp.fenghuang.server.service;

import com.sankuai.tripdatecenter.databp.fenghuang.domain.report.IndicatorTreeVO;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.report.TopicIndicatorVO;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.tmpapp.IndicatorVO;

import java.util.List;

/**
 * Description: 报表指标服务接口
 *
 * @author mayuzhe@meituan.com
 * @date 2022/4/20
 */
public interface IndicatorService {
    /**
     * 指标下线
     *
     * @param curId 节点 id
     */
    void offlineIndicator(long curId);

    /**
     * 指标删除
     *
     * @param curId 节点 id
     */
    void deleteIndicator(long curId);

    /**
     * submit 指标
     *
     * @param indicatorTreeVO
     */
    void submitIndicator(IndicatorTreeVO indicatorTreeVO);

    /**
     * 指标修改
     *
     * @param topicIndicatorVO
     */
    void modifyIndicator(TopicIndicatorVO topicIndicatorVO);

    /**
     * 获取指标树
     *
     * @param reportId 报表 id
     * @param version  版本号
     * @param moduleId 模块 id
     * @return
     */
    List<TopicIndicatorVO> getIndicatorTree(long reportId, long version, long moduleId);

    /**
     * 获取指标树
     *
     * @param reportId 报表 id
     * @param topicId 主题 id
     * @param version  版本号
     * @return
     */
    List<IndicatorVO> getIndicatorListByTopicId(long reportId, long topicId, long version);

    /**
     *
     **/
    List<String> checkTopicIndicators(List<String> indicatorIds);
}
