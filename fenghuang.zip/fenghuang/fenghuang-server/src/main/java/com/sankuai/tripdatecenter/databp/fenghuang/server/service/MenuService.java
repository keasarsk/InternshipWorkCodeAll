package com.sankuai.tripdatecenter.databp.fenghuang.server.service;


import com.sankuai.tripdatecenter.databp.fenghuang.domain.menu.MenuVO;

import java.util.List;

/**
 * description
 *
 * @author
 * @createTime 2022/4/18 7:47 下午
 */
public interface MenuService {

    List<MenuVO> getAuthMenu(String misId, String businessId);

}
