package com.sankuai.tripdatecenter.databp.fenghuang.server.controller;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.meituan.mdp.boot.starter.web.response.WebResponse;
import com.sankuai.tripdatecenter.databp.fenghuang.common.enums.AppTypeEnum;
import com.sankuai.tripdatecenter.databp.fenghuang.common.enums.DataTypeEnum;
import com.sankuai.tripdatecenter.databp.fenghuang.common.enums.DataUnitEnum;
import com.sankuai.tripdatecenter.databp.fenghuang.common.enums.TemplateTypeEnum;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import java.util.List;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * description WEB数据查询Controller类
 *
 * @author fuzhengwei02
 * @createTime 2022/4/6 3:41 下午
 */

@RestController
@Api(description = "枚举值列表")
@RequestMapping("/api/fh/config/enums")
@Slf4j
public class EnumController {

    @GetMapping("/templatetype")
    @ApiOperation(value = "加载WBR模版类型枚举接口")
    @ApiImplicitParams({
    })
    public WebResponse<List<Map<String, String>>> listWbrTemplateType() {
        List<Map<String, String>> wbrTemplateTypes = Lists.newArrayList();
        for(TemplateTypeEnum wbrTemplateEnum : TemplateTypeEnum.values()){
            Map<String, String> templateEnum = Maps.newHashMap();
            templateEnum.put("code", wbrTemplateEnum.getCode());
            templateEnum.put("name", wbrTemplateEnum.getName());
            wbrTemplateTypes.add(templateEnum);
        }
        return WebResponse.buildData(wbrTemplateTypes);
    }

    @GetMapping("/apptype")
    @ApiOperation(value = "加载app类型枚举接口")
    @ApiImplicitParams({
    })
    public WebResponse<List<Map<String, String>>> listAppType() {
        List<Map<String, String>> appTypes = Lists.newArrayList();
        for(AppTypeEnum appTypeEnum : AppTypeEnum.values()){
            Map<String, String> templateEnum = Maps.newHashMap();
            templateEnum.put("code", appTypeEnum.getCode());
            templateEnum.put("name", appTypeEnum.getName());
            appTypes.add(templateEnum);
        }
        return WebResponse.buildData(appTypes);
    }

    @GetMapping("/valuedatatype")
    @ApiOperation(value = "加载数据类型枚举接口")
    @ApiImplicitParams({
    })
    public WebResponse<List<Map<String, String>>> listValueDataType() {
        List<Map<String, String>> valueTypes = Lists.newArrayList();
        for(DataTypeEnum dataTypeEnum : DataTypeEnum.values()){
            Map<String, String> valueType = Maps.newHashMap();
            valueType.put("code", dataTypeEnum.getCode());
            valueType.put("name", dataTypeEnum.getName());
            valueTypes.add(valueType);
        }
        return WebResponse.buildData(valueTypes);
    }

    @GetMapping("/valuedataunit")
    @ApiOperation(value = "加载数据类型枚举接口")
    @ApiImplicitParams({
    })
    public WebResponse<List<Map<String, String>>> listValueDataUnit() {
        List<Map<String, String>> valueUnits = Lists.newArrayList();
        for(DataUnitEnum dataUnitEnum : DataUnitEnum.values()){
            Map<String, String> valueType = Maps.newHashMap();
            valueType.put("code", dataUnitEnum.getCode());
            valueType.put("name", dataUnitEnum.getName());
            valueUnits.add(valueType);
        }
        return WebResponse.buildData(valueUnits);
    }

}
