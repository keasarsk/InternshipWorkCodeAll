package com.sankuai.tripdatecenter.databp.fenghuang.server.service;

import com.meituan.mdp.boot.starter.web.response.BusinessResponseData;
import com.sankuai.apa.origin.pojo.kpi.Kpi;
import com.sankuai.tripdatecenter.databp.fenghuang.common.domain.request.IndicatorRequestParam;
import com.sankuai.tripdatecenter.databp.fenghuang.common.exception.FHBaseException;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.tmpapp.IndicatorVO;
import java.util.List;

/**
 * description 指标元数据Service
 *
 * @author nixuefeng
 * @createTime 2022/4/13 11:49 上午
 */
public interface IndicatorMetaService {
    /**
     * 拉取起源中指标列表
     * @return
     */
    BusinessResponseData<IndicatorVO> listIndicatorFromOrigin(IndicatorRequestParam pageInfo) throws FHBaseException;

    /**
     * 获取指标池中指标列表
     * @return
     */
    BusinessResponseData<IndicatorVO> listIndicator(IndicatorRequestParam requestParam) throws FHBaseException;

    /**
     * 保存起源指标
     * @return
     */
    boolean saveIndicatorMeta(List<IndicatorVO> indicators, String businessId) throws FHBaseException;

    /**
     * 保存起源指标
     * @return
     */
    boolean saveIndicatorMeta(List<IndicatorVO> indicators, String businessId, Boolean isOverwrite) throws FHBaseException;

    /**
     * 删除起源指标
     * @return
     */
    boolean deleteIndicatorMeta(List<String> indicatorIds, String businessId) throws FHBaseException;

    /**
     * 将 Kpi 转为 IndicatorVO
     *
     * @param kpiDetail
     * @return
     */
    IndicatorVO buildIndicatorVOByKpi(Kpi kpiDetail);

}
