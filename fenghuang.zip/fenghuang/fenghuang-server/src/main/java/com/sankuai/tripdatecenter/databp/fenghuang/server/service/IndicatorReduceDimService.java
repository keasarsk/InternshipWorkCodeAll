package com.sankuai.tripdatecenter.databp.fenghuang.server.service;

import com.sankuai.tripdatecenter.databp.fenghuang.domain.report.TopicIndicatorReduceDimCollectionVO;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.report.TopicIndicatorVO;

import java.util.List;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2023/5/26 15:20
 */
public interface IndicatorReduceDimService {
    List<TopicIndicatorReduceDimCollectionVO> getReduceDimByIndicator(String businessId, Long topicId, String indicatorId);

    boolean saveReduceDimAndEnum(TopicIndicatorVO topicIndicatorVO);
}
