package com.sankuai.tripdatecenter.databp.fenghuang.server.controller.ba;

import com.meituan.mdp.boot.starter.web.response.WebResponse;
import com.sankuai.tripdatecenter.databp.fenghuang.common.enums.ResponseCodeEnum;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.ba.BaModuleVO;
import com.sankuai.tripdatecenter.databp.fenghuang.server.service.ba.BaModuleService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2023/2/27 10:58
 */
@RestController
@Api(description = "经营分析模版，模块相关api")
@RequestMapping("/api/fh/ba/report/module")
public class ModuleConfigController {
    @Autowired
    private BaModuleService baModuleService;

    @GetMapping("/list")
    @ApiOperation(value = "报表模块列表")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "topicId", value = "主题Id", dataType = "Long", required = true, paramType = "query")
    })
    WebResponse<List<BaModuleVO>> listModule(@RequestParam Long topicId) {
        return WebResponse.buildData(baModuleService.listModule(topicId));
    }

    @GetMapping("/remove")
    @ApiOperation(value = "报表模块删除接口")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "moduleId", value = "模块Id", dataType = "Long", required = true, paramType = "query")
    })
    WebResponse<ResponseCodeEnum> removeModule(@RequestParam Long moduleId) {
        if (baModuleService.removeModule(moduleId)) {
            return WebResponse.buildData(ResponseCodeEnum.SUCCESS);
        } else {
            return WebResponse.buildError(ResponseCodeEnum.NOT_FOUND.getCode(), ResponseCodeEnum.NOT_FOUND.getMessage());
        }
    }

    @PostMapping("/submit")
    @ApiOperation(value = "报表模块提交")
    WebResponse<ResponseCodeEnum> submitModule(@RequestBody BaModuleVO baModule) {
        if (baModuleService.submitModule(baModule)) {
            return WebResponse.buildData(ResponseCodeEnum.SUCCESS);
        } else {
            return WebResponse.buildError(ResponseCodeEnum.BAD_REQUEST.getCode(), ResponseCodeEnum.BAD_REQUEST.getMessage());
        }
    }

    @PostMapping("/sort")
    @ApiOperation(value = "报表模块排序")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "businessId", value = "业务线", dataType = "String", paramType = "query")
    })
    WebResponse<ResponseCodeEnum> sortModule(@RequestBody List<Long> moduleIds) {
        baModuleService.sortModule(moduleIds);
        return WebResponse.buildData(ResponseCodeEnum.SUCCESS);
    }
}
