package com.sankuai.tripdatecenter.databp.fenghuang.server.service;

import com.sankuai.apa.origin.pojo.PageOut;
import com.sankuai.apa.origin.pojo.app.App;
import com.sankuai.apa.origin.pojo.app.AppDetail;
import com.sankuai.apa.origin.pojo.app.AppDim;
import com.sankuai.apa.origin.pojo.data.DimDataOut;
import com.sankuai.apa.origin.pojo.dim.Dim;
import com.sankuai.apa.origin.pojo.dim.DimDetail;
import com.sankuai.apa.origin.pojo.dim.DimDict;
import com.sankuai.apa.origin.pojo.dim.DimResume;
import com.sankuai.apa.origin.pojo.kpi.Kpi;
import com.sankuai.apa.origin.pojo.kpi.KpiDetail;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.domain.BusinessLineVO;

import java.util.List;

/**
 * Description: 访问起源接口
 *
 * @author mayuzhe@meituan.com
 * @date 2022/4/14
 */
public interface OriginService {
    /**
     * 默认获取业务线下所有指标
     *
     * @return
     */
    List<Kpi> getIndicatorList(BusinessLineVO businessLineVO);

    /**
     * 搜索指标列表
     *
     * @param searchText 搜索框文本
     * @param sn         pageSize
     * @param cn         currentPageNum
     * @return
     */
    PageOut<Kpi> searchIndicatorList(String searchText, int sn, int cn, BusinessLineVO businessLineVO);

    /**
     * 获取指标详情
     *
     * @param indicatorCode 指标 code
     * @return
     */
    KpiDetail getIndicatorDetail(String indicatorCode, BusinessLineVO businessLineVO);

    /**
     * 根据起源指标ID获取指标详情
     *
     * @param originKpiId 起源指标ID
     * @return 指标详情
     */
    KpiDetail getIndicatorDetailById(Integer originKpiId, BusinessLineVO businessLineVO);

    /**
     * 获取指标详情
     *
     * @param indicatorCodes 指标 code
     * @return
     */
    List<KpiDetail> getIndicatorDetails(List<String> indicatorCodes, BusinessLineVO businessLineVO);

    /**
     * 默认获取业务线下所有维度
     *
     * @return
     */
    List<Dim> getDimensionList(BusinessLineVO businessLineVO);

    /**
     * 搜索维度列表
     *
     * @param dimName
     * @param sn
     * @param cn
     * @return
     */
    PageOut<Dim> searchDimensionList(String dimName, int sn, int cn, BusinessLineVO businessLineVO);

    /**
     * 获取维度详情
     *
     * @param dimensionCode 维度 code
     * @return
     */
    DimDetail getDimensionDetail(String dimensionCode, BusinessLineVO businessLineVO);

    /**
     * 获取维度字典
     *
     * @param dimensionCode 维度code
     * @return
     */
    List<DimDict> getDimensionDict(String dimensionCode, BusinessLineVO businessLineVO);

    /**
     * 查询APP列表
     *
     * @param appName  应用名称
     * @param appId    应用ID
     * @param pageNum  页数
     * @param pageSize 每页记录数
     * @return
     */
    PageOut<App> searchAppList(String appName, Integer appId, int pageNum, int pageSize, BusinessLineVO businessLineVO);

    /**
     * 获取APP详细信息
     *
     * @param appId
     * @return
     */
    AppDetail getAppDetail(Integer appId, BusinessLineVO businessLineVO);

    /**
     * 获取维度值数据
     *
     * @param dimensionCode
     * @param businessLineVO
     * @return
     */
    DimDataOut getDimData(String dimensionCode, BusinessLineVO businessLineVO);

    /**
     * 获取应用下所有维度列表
     * @param appId
     * @return
     */
    List<AppDim> getDimListByAppId(Integer appId);

    /**
     * 根据dimId获取指标code
     * @param dimId
     * @return
     */
    String getDimensionCodeByDimId(Integer dimId, BusinessLineVO businessLineVO);

}
