package com.sankuai.tripdatecenter.databp.fenghuang.server.controller.ba;

import com.meituan.mdp.boot.starter.web.response.WebResponse;
import com.sankuai.hbdata.commonutils.common.CollectionUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.common.enums.ResponseCodeEnum;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.ba.BaTopicFunnelVO;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.ba.FunnelIndicatorVO;
import com.sankuai.tripdatecenter.databp.fenghuang.server.service.ba.BaFunnelService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2023/2/27 10:47
 */
@RestController
@Api(description = "经营分析模版，漏斗图相关api")
@RequestMapping("/api/fh/ba/report/funnel")
public class FunnelConfigController {
    @Autowired
    private BaFunnelService baFunnelService;

    @GetMapping("/detail")
    @ApiOperation(value = "漏斗图指标信息")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "topicId", value = "主题Id", dataType = "Long", required = true, paramType = "query")
    })
    WebResponse<List<FunnelIndicatorVO>> queryFunnel(@RequestParam Long topicId) {
        return WebResponse.buildData(baFunnelService.queryFunnelIndicator(topicId));
    }

    @PostMapping("/submit")
    @ApiOperation(value = "漏斗图配置提交")
    WebResponse<ResponseCodeEnum> submitFunnel(@RequestBody BaTopicFunnelVO baTopicFunnelVO) {
        if (CollectionUtils.isEmpty(baTopicFunnelVO.getFunnelIndicators()) || baFunnelService.submitFunnelIndicator(baTopicFunnelVO)) {
            return WebResponse.buildData(ResponseCodeEnum.SUCCESS);
        } else {
            return WebResponse.buildError(ResponseCodeEnum.UNKNOWN_ERROR.getCode(), "漏斗图配置保存错误");
        }
    }

    @PostMapping("/sort")
    @ApiOperation(value = "漏斗指标排序")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "topicId", value = "主题Id", dataType = "Long", required = true, paramType = "query")
    })
    WebResponse<ResponseCodeEnum> sortIndicators(@RequestBody List<String> indicatorIds, @RequestParam Long topicId) {
        if (CollectionUtils.isEmpty(indicatorIds) || baFunnelService.sortFunnelIndicator(indicatorIds, topicId)) {
            return WebResponse.buildData(ResponseCodeEnum.SUCCESS);
        } else {
            return WebResponse.buildError(ResponseCodeEnum.UNKNOWN_ERROR.getCode(), "漏斗图配置保存错误");
        }
    }
}
