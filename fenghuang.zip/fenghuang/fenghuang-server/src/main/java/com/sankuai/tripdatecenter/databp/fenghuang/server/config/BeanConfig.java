package com.sankuai.tripdatecenter.databp.fenghuang.server.config;

import com.dianping.pigeon.remoting.ServiceFactory;
import com.dianping.pigeon.remoting.invoker.config.InvokerConfig;
import com.meituan.service.mobile.mtthrift.proxy.ThriftClientProxy;
import com.sankuai.apa.origin.service.*;
import com.sankuai.hbdata.auth.client.AuthService;
import com.sankuai.hbdata.auth.client.AuthServiceImpl;
import com.sankuai.xm.pubapi.thrift.PushMessageServiceI;
import com.sankuai.xm.udb.common.UdbServiceI;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * description: 服务注册
 *
 * @author nixuefeng
 * @createTime 2022/4/12 11:26 上午
 */
@Configuration
public class BeanConfig {
    /**
     * 超时时间
     */
    private static final int TIME_OUT = 5 * 60 * 1000;

    @Bean(value = "originMetaDimService")
    public OriginMetaDimService getOriginMetaDimService() {
        InvokerConfig<OriginMetaDimService> config = new InvokerConfig(OriginMetaDimService.class);
        config.setCallType(InvokerConfig.CALL_SYNC);
        config.setTimeout(TIME_OUT);
        OriginMetaDimService originMetaDimService = ServiceFactory.getService(config);
        return originMetaDimService;
    }

    @Bean(value = "originMetaKpiService")
    public OriginMetaKpiService getOriginMetaKpiService() {
        InvokerConfig<OriginMetaKpiService> config = new InvokerConfig(OriginMetaKpiService.class);
        config.setCallType(InvokerConfig.CALL_SYNC);
        config.setTimeout(TIME_OUT);
        OriginMetaKpiService originMetaKpiService = ServiceFactory.getService(config);
        return originMetaKpiService;
    }

    @Bean(value = "originMetaAppService")
    public OriginMetaAppService getOriginMetaAppService() {
        InvokerConfig<OriginMetaAppService> config = new InvokerConfig(OriginMetaAppService.class);
        config.setCallType(InvokerConfig.CALL_SYNC);
        config.setTimeout(TIME_OUT);
        OriginMetaAppService originMetaAppService = ServiceFactory.getService(config);
        return originMetaAppService;
    }

    @Bean(value = "originDataService")
    public OriginDataService getOriginDataService() {
        InvokerConfig<OriginDataService> config = new InvokerConfig(OriginDataService.class);
        config.setCallType(InvokerConfig.CALL_SYNC);
        config.setTimeout(TIME_OUT);
        OriginDataService originDataService = ServiceFactory.getService(config);
        return originDataService;
    }

    @Bean(value = "originSqlService")
    public OriginSqlService getOriginSqlService() {
        InvokerConfig<OriginSqlService> config = new InvokerConfig(OriginSqlService.class);
        config.setCallType(InvokerConfig.CALL_SYNC);
        config.setTimeout(TIME_OUT);
        OriginSqlService originSqlService = ServiceFactory.getService(config);
        return originSqlService;
    }

    @Bean("mtAuthService")
    public AuthService getAuthService(@Value("${application.auth-client.secret}") String secret) {
        AuthServiceImpl authServiceImpl = new AuthServiceImpl();
        authServiceImpl.setTimeout(50000);
        authServiceImpl.setAppKey("com.sankuai.trip.b.phoenixtree");
        authServiceImpl.setSecret(secret);
        return authServiceImpl;
    }

    @Bean("pushMessageServiceI")
    public static ThriftClientProxy getPushMessageServiceI() {
        ThriftClientProxy proxy = new ThriftClientProxy();
        proxy.setRemoteAppkey("com.sankuai.xm.pubapi");
        proxy.setServiceInterface(PushMessageServiceI.class);
        proxy.setNettyIO(true);
        proxy.setFilterByServiceName(true);
        return proxy;
    }

    @Bean("udbThriftService")
    public static ThriftClientProxy getUdbThriftService() {
        ThriftClientProxy proxy = new ThriftClientProxy();
        proxy.setRemoteAppkey("com.sankuai.xm.udb");
        proxy.setServiceInterface(UdbServiceI.class);
        proxy.setNettyIO(true);
        proxy.setFilterByServiceName(true);
        return proxy;
    }

}
