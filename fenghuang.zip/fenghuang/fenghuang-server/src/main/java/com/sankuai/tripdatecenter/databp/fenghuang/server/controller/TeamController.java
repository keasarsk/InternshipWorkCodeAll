package com.sankuai.tripdatecenter.databp.fenghuang.server.controller;

import com.meituan.mdp.boot.starter.web.response.WebResponse;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.ExOriginService;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.request.OriginSqlRequest;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.response.OriginSqlResponse;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * description 访问起源接口
 *
 * @author mayuzhe
 * @date 2023-02-06
 */
@RestController
@Api("访问起源接口")
@RequestMapping("/api/fh/origin")
public class TeamController {
    @Autowired
    private ExOriginService exOriginService;

    @PostMapping("/originSql")
    @ApiOperation("从起源获取SQL")
    public WebResponse<OriginSqlResponse> getOriginSql(@RequestBody OriginSqlRequest request) {
        return WebResponse.buildData(exOriginService.getSql(request));
    }
}
