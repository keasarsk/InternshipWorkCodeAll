package com.sankuai.tripdatecenter.databp.fenghuang.server.service;

import com.meituan.mdp.boot.starter.web.response.BusinessResponseData;
import com.sankuai.tripdatecenter.databp.fenghuang.common.exception.FHBaseException;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.report.ReportVO;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.request.ReportRequestParam;

import java.util.List;


/**
 * description
 *
 * @author nixuefeng
 * @createTime 2022/4/18 7:45 下午
 */
public interface ReportService {
    /**
     * 提交报表权限配置
     *
     * @param reportId
     * @param version
     * @param isAuth
     * @return
     * @throws FHBaseException
     */
    boolean submitAuthConfig(Long reportId, Long version, Boolean isAuth) throws FHBaseException;

    /**
     * 获取报表权限配置信息
     *
     * @param reportId
     * @param version
     * @return
     * @throws FHBaseException
     */
    Boolean getAuthConfig(Long reportId, Long version) throws FHBaseException;

    /**
     * 查询报表集合
     *
     * @param requestParam
     * @return
     * @throws FHBaseException
     */
    BusinessResponseData<ReportVO> listReport(ReportRequestParam requestParam) throws FHBaseException;

    /**
     * 报表提交接口
     *
     * @param reportVO
     * @return
     * @throws FHBaseException
     */
    boolean submitReport(ReportVO reportVO) throws FHBaseException;

    /**
     * 更新助理管理员
     *
     * @param
     * @return
     * @throws FHBaseException
     */
    boolean updateReportAssistAdmin(Long reportId, String businessId, List<String> assistAdmin, String operatorMis) throws FHBaseException;

    /**
     * 报表删除接口
     *
     * @param reportId
     * @return
     * @throws FHBaseException
     */
    boolean removeReport(Long reportId, Long version, String businessId) throws FHBaseException;

    /**
     * 报表上线接口
     *
     * @param reportId
     * @param version
     * @param isOnline
     * @return
     * @throws FHBaseException
     */
    boolean onlineReport(Long reportId, Long version, Short isOnline, String businessId) throws FHBaseException;

    /**
     * 查询报表在线版本
     *
     * @param reportId
     * @return
     * @throws FHBaseException
     */
    Long getOnlineVersion(Long reportId) throws FHBaseException;

    /**
     * 获取报表基础配置信息
     *
     * @param reportId 报表ID
     * @param version  版本ID
     * @return
     * @throws FHBaseException
     */
    ReportVO getReportBaseConfig(Long reportId, Long version) throws FHBaseException;
}
