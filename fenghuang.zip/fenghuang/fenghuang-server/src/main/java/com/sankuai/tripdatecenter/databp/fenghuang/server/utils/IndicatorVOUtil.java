package com.sankuai.tripdatecenter.databp.fenghuang.server.utils;

import com.dianping.cat.util.StringUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.common.enums.AppTypeEnum;
import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.WutongUserUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.IndicatorPO;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.tmpapp.IndicatorVO;
import lombok.Data;
import lombok.ToString;

import java.util.Date;

import com.sankuai.tripdatecenter.databp.fenghuang.common.constant.NumberConstant;

/**
 * description 指标VO
 * @author nixuefeng
 * @createTime 2022/4/13 2:27 下午
 */
@Data
@ToString
public class IndicatorVOUtil {

    public static IndicatorPO createIndicatorPO(IndicatorVO indicatorVO){
        IndicatorPO indicatorPO = new IndicatorPO();
        indicatorPO.setVersion(indicatorVO.getVersion());
        indicatorPO.setIndicatorId(indicatorVO.getIndicatorId());
        indicatorPO.setIndicatorCode(indicatorVO.getIndicatorCode());
        indicatorPO.setIndicatorName(indicatorVO.getIndicatorName());
        indicatorPO.setAggregateFunction(indicatorVO.getAggregateFunction() == null ? "" : indicatorVO.getAggregateFunction());
        indicatorPO.setIndicatorComment(indicatorVO.getIndicatorComment());
        indicatorPO.setOrgIndicatorId(indicatorVO.getOrgIndicatorId());
        indicatorPO.setCreatedTime(new Date());
        indicatorPO.setUpdateTime(new Date());
        indicatorPO.setIndicatorType(indicatorVO.getIndicatorType());
        if(indicatorVO.getAppType() == null){
            indicatorPO.setAppType(AppTypeEnum.ORIGIN.getCode());
        }else{
            indicatorPO.setAppType(indicatorVO.getAppType());
        }
        if(indicatorVO.getAppId() == null){
            indicatorPO.setAppId((long)NumberConstant.ZERO);
        }else{
            indicatorPO.setAppId(indicatorVO.getAppId());
        }
        if(StringUtils.isEmpty(indicatorPO.getCreatedMis())){
            indicatorPO.setCreatedMis(WutongUserUtils.getUser());
        }
        indicatorPO.setLastUpdateMis(WutongUserUtils.getUser());
        indicatorPO.setIndicatorUnit(indicatorVO.getIndicatorUnit());
        indicatorPO.setBusinessId(indicatorVO.getBusinessId());
        return indicatorPO;
    }

    public static IndicatorVO buildByIndicatorPO(IndicatorPO indicatorPO){
        IndicatorVO indicatorVO = new IndicatorVO();
        indicatorVO.setId(indicatorPO.getId());
        indicatorVO.setIndicatorId(indicatorPO.getIndicatorId());
        indicatorVO.setOrgIndicatorId(indicatorPO.getOrgIndicatorId());
        indicatorVO.setVersion(indicatorPO.getVersion());
        indicatorVO.setAppId(indicatorPO.getAppId());
        indicatorVO.setAppType(indicatorPO.getAppType());
        indicatorVO.setIndicatorCode(indicatorPO.getIndicatorCode());
        indicatorVO.setIndicatorName(indicatorPO.getIndicatorName());
        indicatorVO.setIndicatorType(indicatorPO.getIndicatorType());
        indicatorVO.setAggregateFunction(indicatorPO.getAggregateFunction());
        indicatorVO.setIndicatorComment(indicatorPO.getIndicatorComment());
        indicatorVO.setIndicatorUnit(indicatorPO.getIndicatorUnit());
        indicatorVO.setBusinessId(indicatorPO.getBusinessId());
        return indicatorVO;
    }
}
