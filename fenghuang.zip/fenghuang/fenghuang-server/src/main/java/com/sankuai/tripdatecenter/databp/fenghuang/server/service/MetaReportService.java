package com.sankuai.tripdatecenter.databp.fenghuang.server.service;

import com.meituan.mdp.boot.starter.web.response.BusinessResponseData;
import com.sankuai.tripdatecenter.databp.fenghuang.common.exception.FHBaseException;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.report.MetaReportVO;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.request.ReportRequestParam;

/**
 * description 报表业务元数据管理
 *
 * @author nixuefeng
 * @createTime 2022/9/22 20:13
 */
public interface MetaReportService {
    /**
     * 查询报表集合
     * @param requestParam
     * @return
     * @throws FHBaseException
     */
    BusinessResponseData<MetaReportVO> listReport(ReportRequestParam requestParam) throws FHBaseException;

    /**
     * 报表提交接口
     * @param reportVO
     * @return
     * @throws FHBaseException
     */
    boolean submitReport(MetaReportVO reportVO) throws FHBaseException;

    /**
     * 报表删除接口
     * @param reportId
     * @param topicId
     * @return
     * @throws FHBaseException
     */
    boolean removeReport(String reportId, String topicId,Short version) throws FHBaseException;

    /**
     * 报表上线接口
     * @param reportId
     * @param version
     * @param isOnline
     * @return
     * @throws FHBaseException
     */
    boolean onlineReport(String reportId,String topicId,Short version,Short isOnline) throws FHBaseException;

    /**
     * 查询报表在线版本
     * @param reportId
     * @return
     * @throws FHBaseException
     */
    Short getOnlineVersion(String reportId) throws FHBaseException;

}
