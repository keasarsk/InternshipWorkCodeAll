package com.sankuai.tripdatecenter.databp.fenghuang.server.controller;

import com.meituan.mdp.boot.starter.web.response.BusinessResponseData;
import com.meituan.mdp.boot.starter.web.response.WebResponse;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.BusinessLineService;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.domain.BusinessLineVO;
import com.sankuai.tripdatecenter.databp.fenghuang.common.enums.ResponseCodeEnum;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.report.*;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.request.*;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.tmpapp.IndicatorVO;
import com.sankuai.tripdatecenter.databp.fenghuang.server.service.UploadAppService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * description 上传数据应用管理controller
 *
 * @author fuzhengwei02
 * @createTime 2022/4/18 7:22 下午
 */
@RestController
@Api(description = "报表相关api")
@RequestMapping("/api/fh/uploadapp")
public class UploadAppController {

    @Autowired
    private UploadAppService uploadAppService;

    @Autowired
    private BusinessLineService businessLineService;

    @PostMapping("/list")
    @ApiOperation(value = "上传应用列表")
    WebResponse<BusinessResponseData<UploadAppVO>> listUploadApp(@RequestBody UploadAppRequestParam requestParam) {
        BusinessLineVO businessLineVO = businessLineService.getBusinessLineByBusinessId(requestParam.getBusinessId());
        requestParam.setBusinessId(businessLineVO.getBusinessId());
        return WebResponse.buildData(uploadAppService.listUploadApp(requestParam));
    }

    @PostMapping("/load")
    @ApiOperation(value = "获取单个应用信息")
    WebResponse<UploadAppVO> listUploadApp(@RequestBody GetUploadAppRequestParam requestParam) {
        BusinessLineVO businessLineVO = businessLineService.getBusinessLineByBusinessId(requestParam.getBusinessId());
        requestParam.setBusinessId(businessLineVO.getBusinessId());
        return WebResponse.buildData(uploadAppService.getUploadAppById(requestParam));
    }

    @PostMapping("/add")
    @ApiOperation(value = "上传应用提交")
    WebResponse<ResponseCodeEnum> addUploadApp(@RequestBody CreateUploadAppParam createUploadAppParam) {
        BusinessLineVO businessLineVO = businessLineService.getBusinessLineByBusinessId(createUploadAppParam.getBusinessId());
        createUploadAppParam.setBusinessId(businessLineVO.getBusinessId());
        if (uploadAppService.addUploadApp(createUploadAppParam)) {
            return WebResponse.buildData(ResponseCodeEnum.SUCCESS);
        } else {
            return WebResponse.buildError(ResponseCodeEnum.UNKNOWN_ERROR.getCode(), ResponseCodeEnum.UNKNOWN_ERROR.getMessage());
        }
    }

    @PostMapping("/remove")
    @ApiOperation(value = "删除上传应用")
    @ApiImplicitParams({
    })
    WebResponse<ResponseCodeEnum> removeUploadApp(@RequestBody RemoveUploadAppParam removeUploadAppParam) {
        BusinessLineVO businessLineVO = businessLineService.getBusinessLineByBusinessId(removeUploadAppParam.getBusinessId());
        removeUploadAppParam.setBusinessId(businessLineVO.getBusinessId());
        if (uploadAppService.removeUploadApp(removeUploadAppParam)) {
            return WebResponse.buildData(ResponseCodeEnum.SUCCESS);
        } else {
            return WebResponse.buildError(ResponseCodeEnum.UNKNOWN_ERROR.getCode(), ResponseCodeEnum.UNKNOWN_ERROR.getMessage());
        }
    }

    @PostMapping("/update")
    @ApiOperation(value = "更新上传应用")
    @ApiImplicitParams({
    })
    WebResponse<ResponseCodeEnum> updateUploadApp(@RequestBody UpdateUploadAppParam updateUploadAppParam) {
        BusinessLineVO businessLineVO = businessLineService.getBusinessLineByBusinessId(updateUploadAppParam.getBusinessId());
        updateUploadAppParam.setBusinessId(businessLineVO.getBusinessId());
        if (uploadAppService.updateUploadApp(updateUploadAppParam)) {
            return WebResponse.buildData(ResponseCodeEnum.SUCCESS);
        } else {
            return WebResponse.buildError(ResponseCodeEnum.UNKNOWN_ERROR.getCode(), ResponseCodeEnum.UNKNOWN_ERROR.getMessage());
        }
    }

    @PostMapping("/online")
    @ApiOperation(value = "更新上传应用<在线>状态")
    @ApiImplicitParams({
    })
    WebResponse<ResponseCodeEnum> updateOnline(@RequestBody UpdateUploadAppOnlineParam updateUploadAppOnlineParam) {
        BusinessLineVO businessLineVO = businessLineService.getBusinessLineByBusinessId(updateUploadAppOnlineParam.getBusinessId());
        updateUploadAppOnlineParam.setBusinessId(businessLineVO.getBusinessId());
        if (uploadAppService.onlineUploadApp(updateUploadAppOnlineParam)) {
            return WebResponse.buildData(ResponseCodeEnum.SUCCESS);
        } else {
            return WebResponse.buildError(ResponseCodeEnum.UNKNOWN_ERROR.getCode(), ResponseCodeEnum.UNKNOWN_ERROR.getMessage());
        }
    }

    @PostMapping("/indicator/add")
    @ApiOperation(value = "新增上传应用指标")
    WebResponse<String> addIndicator(@RequestBody CreateUploadAppIndicatorParam createUploadAppIndicatorParam) {
        BusinessLineVO businessLineVO = businessLineService.getBusinessLineByBusinessId(createUploadAppIndicatorParam.getBusinessId());
        createUploadAppIndicatorParam.setBusinessId(businessLineVO.getBusinessId());
        String indicatorId = uploadAppService.addUploadAppIndicator(createUploadAppIndicatorParam);
        if (StringUtils.isNotBlank(indicatorId)) {
            return WebResponse.buildData(indicatorId);
        } else {
            return WebResponse.buildError(ResponseCodeEnum.UNKNOWN_ERROR.getCode(), ResponseCodeEnum.UNKNOWN_ERROR.getMessage());
        }
    }

    @PostMapping("/indicator/update")
    @ApiOperation(value = "更新上传应用指标")
    WebResponse<ResponseCodeEnum> updateIndicator(@RequestBody UpdateUploadAppIndicatorParam updateUploadAppIndicatorParam) {
        BusinessLineVO businessLineVO = businessLineService.getBusinessLineByBusinessId(updateUploadAppIndicatorParam.getBusinessId());
        updateUploadAppIndicatorParam.setBusinessId(businessLineVO.getBusinessId());
        boolean result = uploadAppService.updateUploadAppIndicator(updateUploadAppIndicatorParam);
        if (result) {
            return WebResponse.buildData(ResponseCodeEnum.SUCCESS);
        } else {
            return WebResponse.buildError(ResponseCodeEnum.UNKNOWN_ERROR.getCode(), ResponseCodeEnum.UNKNOWN_ERROR.getMessage());
        }
    }

    @PostMapping("/indicator/remove")
    @ApiOperation(value = "删除上传应用指标")
    WebResponse<ResponseCodeEnum> addIndicator(@RequestBody DeleteUploadAppIndicatorParam deleteUploadAppIndicatorParam) {
        BusinessLineVO businessLineVO = businessLineService.getBusinessLineByBusinessId(deleteUploadAppIndicatorParam.getBusinessId());
        deleteUploadAppIndicatorParam.setBusinessId(businessLineVO.getBusinessId());
        Boolean deleteResult = uploadAppService.deleteUploadAppIndicator(deleteUploadAppIndicatorParam);
        if (deleteResult) {
            return WebResponse.buildData(ResponseCodeEnum.SUCCESS);
        } else {
            return WebResponse.buildError(ResponseCodeEnum.UNKNOWN_ERROR.getCode(), ResponseCodeEnum.UNKNOWN_ERROR.getMessage());
        }
    }

    @PostMapping("/indicator/list")
    @ApiOperation(value = "上传应用指标列表")
    WebResponse<BusinessResponseData<IndicatorVO>> listIndicator(@RequestBody ListAppIndicatorRequestParam listAppIndicatorRequestParam) {
        BusinessLineVO businessLineVO = businessLineService.getBusinessLineByBusinessId(listAppIndicatorRequestParam.getBusinessId());
        listAppIndicatorRequestParam.setBusinessId(businessLineVO.getBusinessId());
        BusinessResponseData<IndicatorVO> appIndicators = uploadAppService.listAppIndicators(listAppIndicatorRequestParam);
        if (appIndicators != null) {
            return WebResponse.buildData(appIndicators);
        } else {
            return WebResponse.buildError(ResponseCodeEnum.UNKNOWN_ERROR.getCode(), ResponseCodeEnum.UNKNOWN_ERROR.getMessage());
        }
    }

    @PostMapping("/indicator/load")
    @ApiOperation(value = "获取应用单个指标信息")
    WebResponse<IndicatorVO> getUploadAppIndicator(@RequestBody GetAppIndicatorByIdRequestParam requestParam) {
        BusinessLineVO businessLineVO = businessLineService.getBusinessLineByBusinessId(requestParam.getBusinessId());
        requestParam.setBusinessId(businessLineVO.getBusinessId());
        return WebResponse.buildData(uploadAppService.getAppIndicatorById(requestParam));
    }

}
