package com.sankuai.tripdatecenter.databp.fenghuang.server.task;

import com.cip.crane.client.spring.annotation.Crane;
import com.meituan.mdp.boot.starter.web.response.BusinessResponseData;
import com.meituan.mdp.boot.starter.web.response.paging.FixedSizePageInfo;
import com.meituan.mtrace.Tracer;
import com.sankuai.hbdata.commonutils.common.BeanCopyUtils;
import com.sankuai.hbdata.commonutils.common.StringUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.common.domain.request.IndicatorRequestParam;
import com.sankuai.tripdatecenter.databp.fenghuang.common.domain.user.FhUserInfo;
import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.JsonUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.IndicatorDao;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.IndicatorPO;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.tmpapp.IndicatorVO;
import com.sankuai.tripdatecenter.databp.fenghuang.server.service.IndicatorMetaService;
import io.swagger.models.auth.In;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.compress.utils.Lists;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.testng.collections.Maps;

import java.util.List;
import java.util.Map;

/**
 * description crane任务
 *
 * @author nixuefeng
 * @createTime 2023/4/7 19:38
 */
@Service
@Slf4j
public class CraneTask {
    @Autowired
    private IndicatorDao indicatorDao;
    @Autowired
    private IndicatorMetaService indicatorMetaService;
    private static String BUSINESS_ID = "trip";

    /**
     * 批量更新起源指标信息
     */
    @Crane("com.sankuai.tripdatecenter.fenghuang_updateIndicatorInfo")
    public void updateIndicatorInfo() {
        addUserInfo();
        log.info("开始批量更新指标信息中起源id");
        List<IndicatorPO> indicatorPOS =
                indicatorDao.selectList(null, null, 1, null, BUSINESS_ID);
        if (CollectionUtils.isEmpty(indicatorPOS)) {
            log.info("未获取到符合条件的指标信息");
            return;
        }
        Map<String, IndicatorVO> originIndicator = getOriginIndicator();
        log.info("获取到 {} 条起源指标", indicatorPOS.size());
        List<IndicatorVO> indicatorVOS = Lists.newArrayList();
        for (int i = 0; i < indicatorPOS.size(); i++) {
            IndicatorVO vo = new IndicatorVO();
            BeanCopyUtils.copyProperties(indicatorPOS.get(i), vo);
            // 调用起源，获取起源指标id
            if(!StringUtils.isEmpty(vo.getIndicatorId()) && originIndicator.containsKey(vo.getIndicatorId())){
                vo.setOrgIndicatorId(originIndicator.get(vo.getIndicatorId()).getOrgIndicatorId());
            }
            indicatorVOS.add(vo);
            if (i % 10 == 0 || i == indicatorPOS.size()) {
                indicatorMetaService.saveIndicatorMeta(indicatorVOS, BUSINESS_ID, true);
                indicatorVOS.clear();
            }
        }

    }

    private Map<String, IndicatorVO> getOriginIndicator() {
        IndicatorRequestParam requestParam = new IndicatorRequestParam();
        requestParam.setBusinessId("trip");
        FixedSizePageInfo pageInfo = new FixedSizePageInfo();
        pageInfo.setCurrentPageNum(1);
        pageInfo.setPageSize(2000);
        requestParam.setPageInfo(pageInfo);
        BusinessResponseData<IndicatorVO> responseData = indicatorMetaService.listIndicatorFromOrigin(requestParam);
        List<IndicatorVO> indicatorVOS = responseData.getList();
        Map<String, IndicatorVO> indicatorVOMap = Maps.newHashMap();
        indicatorVOS.stream().forEach(indicatorVO -> {
            if (indicatorVOMap.containsKey(indicatorVO.getIndicatorId())) {
                return;
            }
            indicatorVOMap.put(indicatorVO.getIndicatorId(), indicatorVO);
        });
        return indicatorVOMap;
    }

    private void addUserInfo(){
        log.info("crane 任务中添加测试账号");
        FhUserInfo user = new FhUserInfo();
        user.setMisId("test_fenghuang");
        user.setMisName("凤凰监控账号");
        Tracer.putContext("fh.sso.user", JsonUtils.toJson(user));
    }
}
