package com.sankuai.tripdatecenter.databp.fenghuang.server.config;

import com.meituan.mdp.boot.starter.web.response.WebResponse;
import com.sankuai.tripdatecenter.databp.fenghuang.common.enums.ResponseCodeEnum;
import com.sankuai.tripdatecenter.databp.fenghuang.common.exception.FHBaseException;
import com.sankuai.tripdatecenter.databp.fenghuang.common.exception.FHErrorException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;


/**
 * Description: 全局异常处理器
 *
 * @author mayuzhe@meituan.com
 * @date 2022/4/19
 */
@Slf4j
@ControllerAdvice
public class GlobalExceptionHandler {
    /**
     * 处理 Exception 异常
     *
     * @param e 异常
     * @return
     */
    @ResponseBody
    @ExceptionHandler(value = Exception.class)
    public WebResponse<String> exceptionHandler(Exception e) {
        log.error("系统错误:", e);
        return WebResponse.buildError(ResponseCodeEnum.UNKNOWN_ERROR.getCode(), ResponseCodeEnum.UNKNOWN_ERROR.getMessage() + ": " + e.getMessage());
    }

    /**
     * 处理 FHBaseException 异常
     *
     * @param e 异常
     * @return
     */
    @ResponseBody
    @ExceptionHandler(value = FHBaseException.class)
    public WebResponse<String> fhBaseExceptionHandler(FHBaseException e) {
        log.info("业务异常。code:" + e.getCode() + "，msg:" + e.getMsg());
        return WebResponse.buildError(e.getCode(), e.getMsg());
    }

    /**
     * 处理 FHErrorException 异常
     *
     * @param e 异常
     * @return
     */
    @ResponseBody
    @ExceptionHandler(value = FHErrorException.class)
    public WebResponse<String> fhErrorExceptionHandler(FHErrorException e) {
        log.error("系统异常。code:" + e.getCode() + "msg:" + e.getMsg(), e);
        return WebResponse.buildError(e.getCode(), e.getMsg());
    }
}
