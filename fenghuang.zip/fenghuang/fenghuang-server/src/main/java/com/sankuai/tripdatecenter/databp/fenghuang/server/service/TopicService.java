package com.sankuai.tripdatecenter.databp.fenghuang.server.service;

import com.sankuai.tripdatecenter.databp.fenghuang.common.exception.FHErrorException;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.report.TopicVO;
import com.sankuai.tripdatecenter.databp.fenghuang.server.controller.vo.ImportTopicParam;
import com.sankuai.tripdatecenter.databp.fenghuang.server.controller.vo.TopicCopyParam;

import java.util.List;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2022/4/18 7:46 下午
 */
public interface TopicService {
    /**
     * 获取指定版本报表的主题列表
     *
     * @param reportId
     * @param version
     * @return
     */
    List<TopicVO> listTopic(Long reportId, Long version) throws FHErrorException;

    /**
     * 获取指定版本报表主题信息
     *
     * @param reportId
     * @param version
     * @return
     */
    TopicVO getTopic(Long reportId, Long topicId, Long version) throws FHErrorException;

    /**
     * 提交报表主题信息
     *
     * @param topic
     * @return
     */
    boolean submitTopic(TopicVO topic) throws FHErrorException;

    /**
     * 修改报表主题名称
     *
     * @param topic
     * @return
     */
    boolean updateTopicName(TopicVO topic) throws FHErrorException;

    /**
     * 删除某主题
     * @param topicId
     * @param version
     * @return
     * @throws FHErrorException
     */
    boolean removeTopic( Long topicId, Long version, String businessId) throws FHErrorException;

    /**
     * 删除报表下所有主题
     * @param reportId
     * @param version
     * @return
     * @throws FHErrorException
     */
    boolean removeTopics(Long reportId, Long version, String businessId) throws FHErrorException;

    void sortTopic(List<Long> topicIds, Long version, String businessId) throws FHErrorException;

    /**
     * 拷贝主题
     * @param importTopicParam 导入参数
     * @return 新生成的主题信息
     */
    TopicVO copyTopic(ImportTopicParam importTopicParam);


}
