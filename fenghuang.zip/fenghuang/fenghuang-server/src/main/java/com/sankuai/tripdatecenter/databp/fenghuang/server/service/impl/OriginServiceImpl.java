package com.sankuai.tripdatecenter.databp.fenghuang.server.service.impl;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.sankuai.apa.origin.enums.DataQueryStatusEnum;
import com.sankuai.apa.origin.pojo.PageOut;
import com.sankuai.apa.origin.pojo.Response;
import com.sankuai.apa.origin.pojo.app.App;
import com.sankuai.apa.origin.pojo.app.AppDetail;
import com.sankuai.apa.origin.pojo.app.AppDim;
import com.sankuai.apa.origin.pojo.app.AppListSearchForm;
import com.sankuai.apa.origin.pojo.data.DimDataForm;
import com.sankuai.apa.origin.pojo.data.DimDataOut;
import com.sankuai.apa.origin.pojo.dim.*;
import com.sankuai.apa.origin.pojo.kpi.Kpi;
import com.sankuai.apa.origin.pojo.kpi.KpiDetail;
import com.sankuai.apa.origin.pojo.kpi.KpiSearchForm;
import com.sankuai.apa.origin.service.OriginDataService;
import com.sankuai.apa.origin.service.OriginMetaAppService;
import com.sankuai.apa.origin.service.OriginMetaDimService;
import com.sankuai.apa.origin.service.OriginMetaKpiService;
import com.sankuai.tripdatecenter.databp.fenghuang.cache.annotation.FhCacheable;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.domain.BusinessLineVO;
import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.ExecutorPoolUtil;
import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.WutongUserUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.server.service.ExtFilterService;
import com.sankuai.tripdatecenter.databp.fenghuang.server.service.OriginService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.beanutils.ConvertUtils;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import com.sankuai.tripdatecenter.databp.fenghuang.common.constant.BizConstant;

import javax.sql.DataSource;

/**
 * Description: 起源接口服务
 *
 * @author mayuzhe@meituan.com
 * @date 2022/4/14
 */
@Service
@Slf4j
public class OriginServiceImpl implements OriginService {

    @Autowired
    private OriginMetaKpiService originMetaKpiService;

    @Autowired
    private OriginMetaDimService originMetaDimService;

    @Autowired
    private OriginMetaAppService originMetaAppService;

    @Autowired
    private OriginDataService originDataService;

    @Autowired
    private ExtFilterService extFilterService;

    @Autowired
    @Qualifier("dataSource_mysql_system")
    private DataSource dataSource;

    @Value("${bq.app.set}")
    private String bqAppSet;

    private String DEFAULT_BQ_USER_MIS = "fuzhengwei02";

    private static final Pattern ENUM_PATTERN = Pattern.compile("'([^']*)'");

    private static final Pattern DIMENSION_CODE_PATTERN = Pattern.compile("\\$\\{((?!\\{).)*\\}");

    //衍生维度类型-3
    private final int DERIVED_DIM = 3;

    @Override
    public List<Kpi> getIndicatorList(BusinessLineVO businessLineVO) {
        return this.getIndicatorList(BizConstant.ORIGIN_MODULE_KEY, businessLineVO.getOriginBusiLineId());
    }

    @Override
    public PageOut<Kpi> searchIndicatorList(String searchText, int sn, int cn, BusinessLineVO businessLineVO) {
        KpiSearchForm kpiSearchForm = new KpiSearchForm();
        kpiSearchForm.setBusiLineId(businessLineVO.getOriginBusiLineId());
        kpiSearchForm.setSearchTxt(searchText);
        kpiSearchForm.setCn(cn);
        kpiSearchForm.setSn(sn);
        return this.searchIndicatorList(BizConstant.ORIGIN_MODULE_KEY, kpiSearchForm);
    }

    @Override
    public KpiDetail getIndicatorDetail(String indicatorCode, BusinessLineVO businessLineVO) {
        return this.getIndicatorDetail(BizConstant.ORIGIN_MODULE_KEY, indicatorCode, businessLineVO.getOriginBusiLineId());
    }

    @Override
    public KpiDetail getIndicatorDetailById(Integer originKpiId, BusinessLineVO businessLineVO) {
        return this.getIndicatorDetail(BizConstant.ORIGIN_MODULE_KEY, originKpiId);
    }

    @Override
    public List<KpiDetail> getIndicatorDetails(List<String> indicatorCodes, BusinessLineVO businessLineVO) {
        List<CompletableFuture<KpiDetail>> futureList = indicatorCodes.stream().map(indicator -> {
            return CompletableFuture.supplyAsync(() -> getIndicatorDetail(indicator, businessLineVO), ExecutorPoolUtil.getExecutorService());
        }).collect(Collectors.toList());
        List<KpiDetail> result = futureList.stream().map(CompletableFuture::join).filter(Objects::nonNull).collect(Collectors.toList());
        return result;
    }

    @Override
    public List<Dim> getDimensionList(BusinessLineVO businessLineVO) {
        return this.getDimensionList(BizConstant.ORIGIN_MODULE_KEY, businessLineVO.getOriginBusiLineId());
    }

    @Override
    public PageOut<Dim> searchDimensionList(String dimName, int sn, int cn, BusinessLineVO businessLineVO) {
        DimSearchForm dimSearchForm = new DimSearchForm();
        dimSearchForm.setBusiLineId(businessLineVO.getOriginBusiLineId());
        dimSearchForm.setDimName(dimName);
        dimSearchForm.setCn(cn);
        dimSearchForm.setSn(sn);
        return this.searchDimensionList(BizConstant.ORIGIN_MODULE_KEY, dimSearchForm);
    }

    @Override
    @FhCacheable(KEY = "0,1", CACHE_DURATION = 60, VALUE_SERIALIZE_TYPE = "KRYO")
    public DimDetail getDimensionDetail(String dimensionCode, BusinessLineVO businessLineVO) {
        return this.getDimensionDetail(BizConstant.ORIGIN_MODULE_KEY, dimensionCode, businessLineVO.getOriginBusiLineId());
    }

    @Override
    @FhCacheable(KEY = "0,1", CACHE_DURATION = 60)
    public List<DimDict> getDimensionDict(String dimensionCode, BusinessLineVO businessLineVO) {
        DimDetail dimDetail = getDimensionDetail(dimensionCode, businessLineVO);
        if (dimDetail != null) {
            String dimNameField = dimDetail.getDimNameField();
            boolean isDimNameField = dimensionCode.equals(dimNameField);
            if (CollectionUtils.isNotEmpty(dimDetail.getDimDictList())) {
                return wrapDict(dimDetail.getDimDictList(), isDimNameField);
            }
            if (CollectionUtils.isNotEmpty(dimDetail.getDimTableList())) {
                List<DimDict> list = Lists.newArrayList();
                if(extFilterService.isQueryEnumByDimensionId(dimensionCode)){
                    // poi、deal、bd、省份、城市等，不能设置降维，枚举值
                    list = queryDimEnumValuesFromOrigin(dimensionCode, businessLineVO);
                }
//                DimTable dimTable = dimDetail.getDimTableList().get(0);
//                List<DimDict> list = queryDimEnumValuesFromTable(dimTable);
                return wrapDict(list, isDimNameField);
            }else{
                //查询衍生公式
                return getDimDict4DerivedDim(dimensionCode, dimDetail, businessLineVO);
            }
        }
        return Lists.newArrayList();
    }

    private List<DimDict> getDimDict4DerivedDim(String dimensionCode, DimDetail dimDetail, BusinessLineVO businessLineVO){
        int dimId = dimDetail.getDimId();
        String dimNameField = dimDetail.getDimNameField();
        String dimCodeField = dimDetail.getDimCodeField();
        DimQuery dimQuery = new DimQuery();
        dimQuery.setDimIdList(Lists.newArrayList(dimId));
        Response<List<DimDetailDTO>> response = originMetaDimService.dimDetailList(businessLineVO.getOriginBusiLineId(), dimQuery);
        if(response != null && CollectionUtils.isNotEmpty(response.getData())){
            DimDetailDTO dimDetailDTO = response.getData().get(0);
            if(dimDetailDTO != null && dimDetailDTO.getDimDerive() != null){
                DimDeriveDTO dimDeriveDTO = dimDetailDTO.getDimDerive();
                String formula = null;
                if(dimensionCode.equals(dimCodeField)){
                    if(CollectionUtils.isNotEmpty(dimDeriveDTO.getCodeFormulaList())){
                        DimDeriveFormulaDTO formulaDTO = dimDeriveDTO.getCodeFormulaList().get(0);
                        formula = formulaDTO.getFormula();
                    }
                }else if(dimensionCode.equals(dimNameField)){
                    if(CollectionUtils.isNotEmpty(dimDeriveDTO.getNameFormulaList())){
                        DimDeriveFormulaDTO formulaDTO = dimDeriveDTO.getNameFormulaList().get(0);
                        formula = formulaDTO.getFormula();
                    }
                }
                if(StringUtils.isBlank(formula)){
                    return Lists.newArrayList();
                }
                return getDimDictFromDerivedFormula(dimensionCode, formula, businessLineVO);
            }
        }
        return Lists.newArrayList();
    }

    private List<DimDict> getDimDictFromDerivedFormula(String dimensionCode, String formula, BusinessLineVO businessLineVO){
        //将 ${变量取出来},这些是指标ID
        log.info("formula:{}", formula);
        List<String> enumCodes = Lists.newArrayList();
        boolean dimensionAlias = isDimensionAlias(formula);
        if(dimensionAlias){
            return getDimensionEnumValues4dimensionAlias(dimensionCode, formula, businessLineVO);
        }
        boolean acceptFormat = acceptFormulaFormat(formula);
        if(StringUtils.isNotBlank(formula) && acceptFormat){
            boolean isEnumAllConstants = isFormulaAllEnumConstants(formula);
            if(isEnumAllConstants){
                enumCodes = parseFormulaEnumConstants(formula, true);
            } else {
                List<String> dimensionCodes = formulaDependDimensionCode(formula, businessLineVO);
                if(CollectionUtils.isNotEmpty(dimensionCodes) && dimensionCodes.size() == 1){
                    //通过构造表方式，来执行查询。 mysql引擎执行
                    List<String> newEnumCodes = parseFormulaEnumConstants(formula, false);
                    List<String> newAllEnumCodes = generateNewAllEnumCode(dimensionCode, formula, dimensionCodes.get(0), newEnumCodes, businessLineVO);
                    enumCodes = newAllEnumCodes;
                }else{
                    //多于一个维度，只解析枚举值。
                    enumCodes = parseFormulaEnumConstants(formula, false);
                }
            }
        }
        //通过code，构造维值
        List<DimDict> dimDicts = Lists.newArrayList();
        if(CollectionUtils.isNotEmpty(enumCodes)){
            for(String enumCode : enumCodes){
                DimDict dimDict = new DimDict();
                dimDict.setDimCode(enumCode);
                dimDict.setDimName(enumCode);
                dimDicts.add(dimDict);
            }
        }
        return dimDicts;
    }

    private List<String> generateNewAllEnumCode(String dimensionCode, String formula, String dependDimensionCode, List<String> newEnumCodes, BusinessLineVO businessLineVO){
        //循环依赖检测
        if(dimensionCode.equals(dependDimensionCode)){
            log.info("维度不能依赖自己:{},{}", dimensionCode, dependDimensionCode);
            return Lists.newArrayList();
        }
        //依赖维度维值
        List<DimDict> dimDicts = getDimensionDict(dependDimensionCode, businessLineVO);
        String fullSqlTemplate = "select dim_code from ( select %s as dim_code from (%s) t1 ) t2 group by t2.dim_code";
        String dimValueTemplate = "SELECT '%s' AS dim_code  FROM DUAL";
        //根据维值构造内部SQL，
        List<String> dimCodeItems = Lists.newArrayList();
        if(CollectionUtils.isNotEmpty(dimDicts)){
            for(DimDict dimDict : dimDicts){
                String dimCodeItem = String.format(dimValueTemplate, dimDict.getDimCode());
                dimCodeItems.add(dimCodeItem);
            }
        }
        String innerItemsPart = String.join(" UNION ", dimCodeItems);
        //公式替换为固定code
        Matcher matcher = DIMENSION_CODE_PATTERN.matcher(formula);
        String newFormula = matcher.replaceAll("dim_code");
        //连接外部公式，生成整体SQL。
        String realSql = String.format(fullSqlTemplate, newFormula, innerItemsPart);
        //交给MYSQL执行。
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        List<String> dimEnumValues= jdbcTemplate.queryForList(realSql, String.class);
        //返回结果
        return dimEnumValues;
    }

    private boolean isDimensionAlias(String formula){
        if(StringUtils.isNotBlank(formula) && formula.startsWith("${") && formula.startsWith("}")){
            return true;
        }
        return false;
    }

    private List<DimDict> getDimensionEnumValues4dimensionAlias(String dimensionCode, String formula, BusinessLineVO businessLineVO){
        List<String> childrenDimensionCodes = formulaDependDimensionCode(formula, businessLineVO);
        if(CollectionUtils.isNotEmpty(childrenDimensionCodes) && childrenDimensionCodes.size() == 1){
            String childDimensionCode = childrenDimensionCodes.get(0);
            if(dimensionCode.equals(childDimensionCode)){
                log.info("维度不能依赖自身");
                return Lists.newArrayList();
            }
            return getDimensionDict(childDimensionCode, businessLineVO);
        }
        return Lists.newArrayList();
    }

    private boolean acceptFormulaFormat(String formula){
        //TODO：暂时不支持别名方式（月维度日期(凤凰平台) ${统计月起始日期}）
        return formula != null && StringUtils.containsIgnoreCase(formula, "case when");
    }

    private boolean isFormulaAllEnumConstants(String formula){
        boolean acceptFormat = acceptFormulaFormat(formula);
        if(acceptFormat){
            int index = StringUtils.lastIndexOfIgnoreCase(formula, "ELSE");
            String defaultStr = formula.substring(index);
            log.info("最后一个ELSE: {}", defaultStr);
            if(StringUtils.isNotBlank(defaultStr)){
                Matcher matcher = DIMENSION_CODE_PATTERN.matcher(defaultStr);
                boolean existDynamicDimensionCode = matcher.find();
                log.info("是否含有动态维度: {}", existDynamicDimensionCode);
                if(!existDynamicDimensionCode){
                    //没有动态维度
                    return true;
                }
            }
        }
        return false;
    }

    private List<String> parseFormulaEnumConstants(String formula, boolean includeEndPart){
        //解析（1）THEN后面的字符串， (2)解析else后面的字符串。
        String remainingStr = formula;
        Set<String> parsedDimensionCodes = Sets.newLinkedHashSet();
        if(includeEndPart){
            //先处理ELSE 字符串
            int elseIndex = StringUtils.lastIndexOfIgnoreCase(formula, "else");
            if(elseIndex != -1){
                String subFormula = formula.substring(elseIndex);
                String singleEnumValue = parseEnumValue(subFormula);
                if(singleEnumValue != null){
                    parsedDimensionCodes.add(singleEnumValue);
                }
                remainingStr = remainingStr.substring(0, elseIndex);
            }
        }
        if(remainingStr != null){
            int thenIndex = StringUtils.lastIndexOfIgnoreCase(remainingStr, "then");
            while(thenIndex != -1){
                String subFormula = remainingStr.substring(thenIndex);
                String singleEnumValue = parseEnumValue(subFormula);
                if(singleEnumValue != null){
                    parsedDimensionCodes.add(singleEnumValue);
                }
                remainingStr = remainingStr.substring(0, thenIndex);
                thenIndex = StringUtils.lastIndexOfIgnoreCase(remainingStr, "then");
            }
        }
        return Lists.newArrayList(parsedDimensionCodes);
    }

    private String parseEnumValue(String text){
        Matcher matcher = ENUM_PATTERN.matcher(text);
        if(matcher.find()){
            String findStr = matcher.group();
            return findStr.substring(1, findStr.length()-1);
        }
        return null;
    }

    private List<String> formulaDependDimensionCode(String formula, BusinessLineVO businessLineVO){
        Matcher matcher = DIMENSION_CODE_PATTERN.matcher(formula);
        Set<Integer> dimensionIds = Sets.newHashSet();
        Set<String> dimensionCodes = Sets.newHashSet();
        while (matcher.find()) {
            String singleFind = matcher.group();
            log.info("查找到指标信息:{}", singleFind);
            int singleFindLength = singleFind.length();
            String innerDimensionInfoStr = singleFind.substring(2, singleFindLength - 1);
            log.info("dimensionInfo:{}", innerDimensionInfoStr);
            String dimensionId = innerDimensionInfoStr.split(":")[1];
            log.info("parse dimensionId:{}", dimensionId);
            Integer dimId = (Integer)ConvertUtils.convert(dimensionId, Integer.class);
            if(!dimensionIds.contains(dimId)){
                dimensionIds.add(dimId);
                String dimensionCode = getDimensionCodeByDimId(dimId, businessLineVO);
                log.info("解析出指标Code:{}", dimensionCode);
                if(StringUtils.isNotBlank(dimensionCode)){
                    dimensionCodes.add(dimensionCode);
                }
            }
        }
        log.info("解析出指标codes:{}", dimensionCodes);
        return Lists.newArrayList(dimensionCodes);
    }

    private List<DimDict> wrapDict(List<DimDict> rawDicts, boolean isNameField) {
        if (isNameField) {
            List<DimDict> newDicts = Lists.newArrayList();
            if (CollectionUtils.isNotEmpty(rawDicts)) {
                for (DimDict rawDict : rawDicts) {
                    DimDict newDict = new DimDict();
                    newDict.setDimCode(rawDict.getDimName());
                    newDict.setDimName(rawDict.getDimName());
                    newDicts.add(newDict);
                }
            }
            return newDicts;
        }
        return rawDicts;
    }

    /**
     * 调用起源接口，获取维值信息
     * 注：test环境，接口响应时间过长，可在stage和prod进行测试
     */
    private List<DimDict> queryDimEnumValuesFromOrigin(String dimensionCode, BusinessLineVO businessLineVO) {
        DimDataOut dimDataOut = getDimData(dimensionCode, businessLineVO);
        if (!dimDataOut.getQueryStatusEnum().equals(DataQueryStatusEnum.FINISHED)) {
            throw new RuntimeException("query dim value error , message: " + dimDataOut.getMessage() + dimDataOut.getQueryStatusEnum().getValueDesc());
        }
        List<DimDict> dimDicts = Lists.newArrayList();
        if (CollectionUtils.isEmpty(dimDataOut.getData())) {
            return Collections.emptyList();
        }
        dimDataOut.getData().stream().forEach(dimData -> {
            if (CollectionUtils.isNotEmpty(dimData) && dimData.size() >= 2) {
                DimDict dimDictItem = new DimDict();
                dimDictItem.setDimCode(dimData.get(0));
                dimDictItem.setDimName(dimData.get(1));
                dimDicts.add(dimDictItem);
            }
        });
        return dimDicts;
    }

    @Override
    public PageOut<App> searchAppList(String appName, Integer appId, int pageNum, int pageSize, BusinessLineVO businessLineVO) {
        AppListSearchForm appListSearchForm = new AppListSearchForm();
        appListSearchForm.setBusiLineId(businessLineVO.getOriginBusiLineId());
        if (StringUtils.isNotBlank(appName)) {
            appListSearchForm.setAppName(appName.trim());
        }
        if (appId != null) {
            appListSearchForm.setAppId(appId);
        }
        appListSearchForm.setCn(pageNum);
        appListSearchForm.setSn(pageSize);
        return originMetaAppService.appList(BizConstant.ORIGIN_MODULE_KEY, appListSearchForm, businessLineVO.getOriginAdminMis()).getData();
    }

    @Override
    public AppDetail getAppDetail(Integer appId, BusinessLineVO businessLineVO) {
        return originMetaAppService.appDetail(BizConstant.ORIGIN_MODULE_KEY, appId, businessLineVO.getOriginAdminMis()).getData();
    }

    @Override
    @FhCacheable(KEY = "0,1", CACHE_DURATION = 600)
    public DimDataOut getDimData(String dimensionCode, BusinessLineVO businessLineVO) {
        DimDataForm dimDataForm = new DimDataForm();
        dimDataForm.setDimCode(dimensionCode);
        dimDataForm.setBusiLineId(businessLineVO.getOriginBusiLineId());
        DimDataOut dimDataOut = originDataService.getDimDataSync(dimDataForm, WutongUserUtils.getUser()).getData();
        return dimDataOut;
    }

    @Override
    @FhCacheable(KEY = "0", CACHE_DURATION = 600)
    public List<AppDim> getDimListByAppId(Integer appId) {
        Response<AppDetail> appDetail = originMetaAppService.appDetail(BizConstant.ORIGIN_MODULE_KEY, appId, WutongUserUtils.getUser());
        if(appDetail.getData() != null){
            return appDetail.getData().getDimList();
        }
        return Collections.emptyList();
    }

    @Override
    @FhCacheable(KEY = "0", CACHE_DURATION = 600)
    public String getDimensionCodeByDimId(Integer dimId, BusinessLineVO businessLineVO) {
        if(dimId == null){
            return null;
        }
        DimQuery dimQuery = new DimQuery();
        dimQuery.setDimIdList(Lists.newArrayList(dimId));
        Response<List<DimDetailDTO>> response = originMetaDimService.dimDetailList(businessLineVO.getOriginBusiLineId(), dimQuery);
        if(response != null && CollectionUtils.isNotEmpty(response.getData())){
            DimDetailDTO dimDetailDTO = response.getData().get(0);
            if(dimId.equals(dimDetailDTO.getDimCodeFieldId())){
                return dimDetailDTO.getDimCodeField();
            }else if(dimId.equals(dimDetailDTO.getDimNameFieldId())){
                return dimDetailDTO.getDimNameField();
            }
        }
        return null;
    }

    /**
     * 获取指标列表
     *
     * @param module     module
     * @param busiLineId 业务线 id
     * @return
     */
    private List<Kpi> getIndicatorList(String module, Integer busiLineId) {
        return originMetaKpiService.kpiList(module, busiLineId).getData();
    }

    /**
     * 搜索指标列表
     *
     * @param module        module
     * @param kpiSearchForm 检索条件
     * @return
     */
    private PageOut<Kpi> searchIndicatorList(String module, KpiSearchForm kpiSearchForm) {
        return originMetaKpiService.searchKpiList(module, kpiSearchForm).getData();
    }

    /**
     * 获取指标详情
     *
     * @param module        module
     * @param indicatorCode 指标 code
     * @param busiLineId    业务线 id
     * @return
     */
    private KpiDetail getIndicatorDetail(String module, String indicatorCode, Integer busiLineId) {
        return originMetaKpiService.kpiDetail(module, indicatorCode, busiLineId).getData();
    }


    private KpiDetail getIndicatorDetail(String module, Integer indicatorId) {
        return originMetaKpiService.kpiDetail(module, indicatorId).getData();
    }

    /**
     * 获取维度列表
     *
     * @param module      module
     * @param dimCodeList 维度 code 列表
     * @param busiLineId  业务线 id
     * @return
     */
    private List<Dim> getDimensionList(String module, List<String> dimCodeList, Integer busiLineId) {
        return originMetaDimService.dimList(module, dimCodeList, busiLineId).getData();
    }

    /**
     * 获取维度列表
     *
     * @param module     module
     * @param busiLineId 业务线 id
     * @return
     */
    private List<Dim> getDimensionList(String module, Integer busiLineId) {
        return originMetaDimService.dimList(module, busiLineId).getData();
    }

    /**
     * 搜索起源维度列表
     *
     * @param module        module
     * @param dimSearchForm 检索条件
     * @return
     */
    private PageOut<Dim> searchDimensionList(String module, DimSearchForm dimSearchForm) {
        return originMetaDimService.searchDimList(module, dimSearchForm).getData();
    }

    private DimDetail getDimensionDetail(String module, String dimensionCode, Integer busiLineId) {
        return originMetaDimService.dimDetail(module, dimensionCode, busiLineId).getData();
    }
}
