package com.sankuai.tripdatecenter.databp.fenghuang.server.service;

import com.sankuai.tripdatecenter.databp.fenghuang.client.config.domain.BusinessLineVO;
import com.sankuai.tripdatecenter.databp.fenghuang.common.domain.user.UserInfo;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.meta.DimDictVO;
import java.util.List;

/**
 * Description: 维度维值
 *
 * @author fuzhengwei02
 * @date 2022-06-22
 */
public interface DimensionDictMetaService {

    /**
     *
     * @param dimensionId
     * @return
     */
    List<DimDictVO> getDimDictFromOrigin(String dimensionId, BusinessLineVO businessLineVO);

    /**
     *
     * @param dimensionId
     * @return
     */
    List<DimDictVO> getDimDictFromLocal(String dimensionId, BusinessLineVO businessLineVO);

    /**
     *
     * @param dimensionId
     * @param userInfo
     * @return
     */
    boolean deleteDimDictFromLocal(String dimensionId, List<String> dimCodes, UserInfo userInfo, BusinessLineVO businessLineVO);

    /**
     *
     * @param dimDicts
     * @return
     */
    boolean saveDimDictToLocal(String dimensionId, List<DimDictVO> dimDicts, UserInfo userInfo, BusinessLineVO businessLineVO);

}
