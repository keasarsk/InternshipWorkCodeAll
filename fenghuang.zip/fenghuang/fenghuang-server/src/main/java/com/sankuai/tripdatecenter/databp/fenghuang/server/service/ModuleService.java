package com.sankuai.tripdatecenter.databp.fenghuang.server.service;

import com.sankuai.tripdatecenter.databp.fenghuang.common.exception.FHErrorException;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.report.ModuleVO;

import java.util.List;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2022/4/18 7:47 下午
 */
public interface ModuleService {
    /**
     * 获取指定版本主题下模块列表
     *
     * @param topicId
     * @param version
     * @return
     */
    List<ModuleVO> listModule(Long topicId, Long version) throws FHErrorException;

    /**
     * 提交模块信息
     *
     * @param module
     * @return
     */
    boolean submitModule(ModuleVO module) throws FHErrorException;

    /**
     * 删除模块信息
     *
     * @param moduleId
     * @param version
     * @return
     * @throws FHErrorException
     */
    boolean removeModule(Long moduleId, Long version) throws FHErrorException;

    /**
     * 删除报表下所有模块
     * @param reportId
     * @param version
     * @return
     * @throws FHErrorException
     */
    boolean removeModules(Long reportId, Long version) throws FHErrorException;

    /**
     * 主题下模块排序
     *
     * @param moduleIds
     * @param version
     * @throws FHErrorException
     */
    void sortModule(List<Long> moduleIds, Long version) throws FHErrorException;

}
