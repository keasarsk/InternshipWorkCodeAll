package com.sankuai.tripdatecenter.databp.fenghuang.server.controller.vo;

import lombok.Data;

import java.io.Serializable;

@Data
public class TopicCopyParam implements Serializable {

    private String businessId;

    private Long sourceReportId;

    private Long sourceTopicId;

    private Long sourceVersion;

    private Long targetReportId;

    private Long targetVersion;

    private String templateType;

}
