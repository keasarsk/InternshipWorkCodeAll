package com.sankuai.tripdatecenter.databp.fenghuang.server.controller.vo;

import lombok.Data;

import java.io.Serializable;

@Data
public class ImportTopicParam implements Serializable {

    private String businessId;

    private Long sourceReportId;

    private Long sourceTopicId;

    private Long targetReportId;

}
