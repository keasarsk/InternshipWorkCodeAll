package com.sankuai.tripdatecenter.databp.fenghuang.server.service;

import com.sankuai.tripdatecenter.databp.fenghuang.common.domain.result.DataResult;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.report.TopicVO;
import com.sankuai.tripdatecenter.databp.fenghuang.server.controller.vo.TopicCopyParam;


/**
 * description 主题扩展服务
 *
 * @author fuzhengwei02
 * @createTime 2023/6/26 11:50 上午
 */
public interface TopicExtService {

    /**
     * 主题拷贝
     * @param copyParam 主题拷贝参数
     * @return 新生成的主题
     */
    DataResult<TopicVO> copyTopic(TopicCopyParam copyParam);



}
