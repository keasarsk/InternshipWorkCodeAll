package com.sankuai.tripdatecenter.databp.fenghuang.server.service;

import com.meituan.mdp.boot.starter.web.response.BusinessResponseData;
import com.sankuai.apa.origin.pojo.dim.Dim;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.domain.BusinessLineVO;
import com.sankuai.tripdatecenter.databp.fenghuang.common.exception.FHBaseException;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.ba.BaDimVO;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.tmpapp.DimensionVO;

import java.util.List;

/**
 * Description: 维度Service接口
 *
 * @author mayuzhe
 * @date 2022-04-18
 */
public interface DimensionMetaService {
    /**
     * 从起源获取维度列表
     *
     * @param pageNum
     * @param pageSize
     * @param dimName
     * @return
     */
    BusinessResponseData<Dim> getDimListFromOrigin(int pageNum, int pageSize, String dimName, BusinessLineVO businessLineVO);

    /**
     * 从维度池获取维度里列表
     *
     * @param pageNum
     * @param pageSize
     * @return
     */
    BusinessResponseData<DimensionVO> getDimensionList(int pageNum, int pageSize, String dimName, BusinessLineVO businessLineVO);

    /**
     * 从起源填加维度到维度池
     *
     * @param dimensionCode 起源维度 code
     */
    void addDimensionFromOrigin(String dimensionCode, BusinessLineVO businessLineVO);

    /**
     * 获取指标详情
     *
     * @param dimensionId
     * @return
     */
    DimensionVO getDimensionDetail(String dimensionId, BusinessLineVO businessLineVO);

    /**
     * 从本地维度池中删除
     **/
    boolean deleteDimensionMeta(List<String> dimensionIds, BusinessLineVO businessLineVO) throws FHBaseException;

    /**
     * 根据应用信息，获取维度集合
     * @param appSource
     * @param appId
     * @return
     */
    List<BaDimVO> getDimensionListByApp(Integer appSource, Long appId, String businessId);
}
