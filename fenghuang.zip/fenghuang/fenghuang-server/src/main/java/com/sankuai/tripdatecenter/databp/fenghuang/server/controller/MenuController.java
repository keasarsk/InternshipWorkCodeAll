package com.sankuai.tripdatecenter.databp.fenghuang.server.controller;

import com.meituan.mdp.boot.starter.web.response.WebResponse;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.FhAuthService;
import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.WutongUserUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.menu.MenuVO;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.report.*;
import com.sankuai.tripdatecenter.databp.fenghuang.server.service.MenuService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * description 凤凰菜单controller
 *
 * @author fuzhengwei02
 * @createTime 2022/4/18 7:22 下午
 */
@RestController
@Api(description = "菜单相关api")
@RequestMapping("/api/fh/menu")
@Slf4j
public class MenuController {

    @Autowired
    private MenuService menuService;

    @GetMapping("/manage")
    @ApiOperation(value = "")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "businessId", value = "业务线ID", dataType = "String", required = true, paramType = "query"),
    })
    public WebResponse<List<MenuVO>> getMenageMenuTree(@RequestParam String businessId) {
        String userMis = WutongUserUtils.getUser();
        return WebResponse.buildData(menuService.getAuthMenu(userMis, businessId));
    }

}
