package com.sankuai.tripdatecenter.databp.fenghuang.server.utils;

import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.WutongUserUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.TmpAppPO;
import com.sankuai.tripdatecenter.databp.fenghuang.dao.po.ext.TmpAppExtPO;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.tmpapp.TmpAppDetailVO;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.tmpapp.TmpAppInfoVO;
import lombok.Data;
import lombok.ToString;
import org.springframework.beans.BeanUtils;

import java.util.Date;

/**
 * description 临时应用详情信息
 *
 * @author nixuefeng
 * @createTime 2022/4/6 8:28 下午
 */
@Data
@ToString
public class TmpAppDetailVOUtil {

    public static TmpAppDetailVO buildTmpAppInfoVOByPO(TmpAppExtPO tmpAppPO){
        TmpAppDetailVO tmpAppDetailVO = new TmpAppDetailVO();
        TmpAppInfoVO tmpAppInfoVO = TmpAppInfoVOUtil.buildTmpAppInfoVOByPO(tmpAppPO);
        BeanUtils.copyProperties(tmpAppInfoVO, tmpAppDetailVO);
        tmpAppDetailVO.setDefinitionInfo(tmpAppPO.getDefinitionInfo());
        tmpAppDetailVO.setUseInfo(tmpAppPO.getUseInfo());
        tmpAppDetailVO.setComment(tmpAppPO.getTmpappComment());
        tmpAppDetailVO.setSqlTemplate(tmpAppPO.getSqlTemplate());
        tmpAppDetailVO.setLastUpdateTime(tmpAppPO.getUpdateTime());
        return tmpAppDetailVO;
    }

    public static TmpAppPO createTmpAppInfoVOByPO(TmpAppDetailVO tmpAppDetailVO){
        TmpAppPO tmpAppPO = new TmpAppPO();
        tmpAppPO.setTmpappId(tmpAppDetailVO.getTmpAppId());
        tmpAppPO.setTmpappName(tmpAppDetailVO.getTmpAppName());
        tmpAppPO.setDatasourceId(tmpAppDetailVO.getDataSourceId());
        tmpAppPO.setCreatedMis(tmpAppDetailVO.getCreatedMis());
        tmpAppPO.setLastUpdateMis(tmpAppDetailVO.getCreatedMis());
        tmpAppPO.setVersion(tmpAppDetailVO.getVersion());
        tmpAppPO.setDefinitionInfo(tmpAppDetailVO.getDefinitionInfo());
        tmpAppPO.setUseInfo(tmpAppDetailVO.getUseInfo());
        tmpAppPO.setTmpappComment(tmpAppDetailVO.getComment());
        tmpAppPO.setSqlTemplate(tmpAppDetailVO.getSqlTemplate());
        tmpAppPO.setUpdateTime(new Date());
        if(tmpAppPO.getCreatedTime() == null){
            tmpAppPO.setCreatedTime(new Date());
        }
        if(tmpAppDetailVO.getCreatedMis() == null){
            tmpAppPO.setCreatedMis(WutongUserUtils.getUser());
        }
        tmpAppPO.setLastUpdateMis(WutongUserUtils.getUser());
        return tmpAppPO;
    }
}
