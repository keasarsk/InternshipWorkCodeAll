package com.sankuai.tripdatecenter.databp.fenghuang.server.controller;

import com.meituan.mdp.boot.starter.web.response.BusinessResponseData;
import com.meituan.mdp.boot.starter.web.response.WebResponse;
import com.sankuai.apa.origin.pojo.dim.Dim;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.BusinessLineService;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.domain.BusinessLineVO;
import com.sankuai.tripdatecenter.databp.fenghuang.common.enums.ResponseCodeEnum;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.tmpapp.DimensionVO;
import com.sankuai.tripdatecenter.databp.fenghuang.server.service.DimensionMetaService;
import com.sankuai.tripdatecenter.databp.fenghuang.server.service.DimensionService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * description 维度Controller类
 *
 * @author mayuzhe
 * @date 2022-04-14
 */
@RestController
@Api("维度元数据相关api")
@RequestMapping("/api/fh/dimension")
public class DimensionMetaController {
    @Autowired
    private DimensionMetaService dimensionService;

    @Autowired
    private DimensionService topicDimensionService;

    @Autowired
    private BusinessLineService businessLineService;

    @GetMapping("/origin/list")
    @ApiOperation("拉取起源中维度列表")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "pageNum", value = "pageNum", dataType = "int", required = true, paramType = "query"),
            @ApiImplicitParam(name = "pageSize", value = "pageSize", dataType = "int", required = true, paramType = "query"),
            @ApiImplicitParam(name = "dimName", value = "维度名称", dataType = "String", required = false, paramType = "query")
    })
    public WebResponse<BusinessResponseData<Dim>> getOriginDimensionList(@RequestParam int pageNum, @RequestParam int pageSize, @RequestParam(required = false) String dimName
            , @RequestParam String businessId) {
        BusinessLineVO businessLineVO = businessLineService.getBusinessLineByBusinessId(businessId);
        return WebResponse.buildData(dimensionService.getDimListFromOrigin(pageNum, pageSize, dimName, businessLineVO));
    }

    @GetMapping("/list")
    @ApiOperation("拉取维度池中维度列表")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "pageNum", value = "pageNum", dataType = "int", required = true, paramType = "query"),
            @ApiImplicitParam(name = "pageSize", value = "pageSize", dataType = "int", required = true, paramType = "query"),
            @ApiImplicitParam(name = "dimName", value = "维度名称", dataType = "String", required = false, paramType = "query")
    })
    public WebResponse<BusinessResponseData<DimensionVO>> getDimensionList(@RequestParam int pageNum, @RequestParam int pageSize, @RequestParam(required = false) String dimName
            , @RequestParam String businessId) {
        BusinessLineVO businessLineVO = businessLineService.getBusinessLineByBusinessId(businessId);
        return WebResponse.buildData(dimensionService.getDimensionList(pageNum, pageSize, dimName, businessLineVO));
    }

    @GetMapping("/origin/add")
    @ApiOperation("填加起源维度到维度池中")
    public WebResponse<String> addDimensionFromOrigin(@RequestParam String dimensionCode, @RequestParam String businessId) {
        BusinessLineVO businessLineVO = businessLineService.getBusinessLineByBusinessId(businessId);
        dimensionService.addDimensionFromOrigin(dimensionCode, businessLineVO);
        return WebResponse.buildData("200");
    }

    @GetMapping("/detail")
    @ApiOperation("获取维度详情")
    public WebResponse<DimensionVO> getDimensionDetail(@RequestParam String dimensionId, @RequestParam String businessId) {
        BusinessLineVO businessLineVO = businessLineService.getBusinessLineByBusinessId(businessId);
        return WebResponse.buildData(dimensionService.getDimensionDetail(dimensionId, businessLineVO));
    }

    @PostMapping("/delete")
    @ApiOperation("起源中维度从凤凰中删除")
    public WebResponse<ResponseCodeEnum> deleteDimension(@RequestBody List<String> dimensionIds, @RequestParam String businessId) {
        BusinessLineVO businessLineVO = businessLineService.getBusinessLineByBusinessId(businessId);
        // 检查待删指标是否被报表使用 fenghuang_info_topic_dimension
        List<String> existDimensionReportId = topicDimensionService.checkTopicDimensions(dimensionIds, businessLineVO);
        if(existDimensionReportId.size() == 0) {
            // 没有被使用，本地池中删除 fenghuang_info_dimension
            if (dimensionService.deleteDimensionMeta(dimensionIds, businessLineVO)) {
                return WebResponse.buildData(ResponseCodeEnum.SUCCESS);
            }
            return WebResponse.buildError(ResponseCodeEnum.UNKNOWN_ERROR.getCode(), ResponseCodeEnum.UNKNOWN_ERROR.getMessage());
        }
        else {
            String msg = ResponseCodeEnum.DIM_DELETE_FAILED.getMessage();
            StringBuilder reportIds = new StringBuilder();
            if(existDimensionReportId.size() > 3){
                for(int i = 0;i < 3;i++){
                    if(i != 2)  reportIds.append(existDimensionReportId.get(i)).append(",");
                    else reportIds.append(existDimensionReportId.get(i));
                }
                reportIds.append("...");
            }
            else{
                for(int i = 0;i < existDimensionReportId.size();i++){
                    if(i != existDimensionReportId.size()-1)    reportIds.append(existDimensionReportId.get(i)).append(",");
                    else reportIds.append(existDimensionReportId.get(i));
                }
            }
            return WebResponse.buildError(ResponseCodeEnum.DIM_DELETE_FAILED.getCode(), msg.replace("{}",reportIds.toString()));
        }
    }
}
