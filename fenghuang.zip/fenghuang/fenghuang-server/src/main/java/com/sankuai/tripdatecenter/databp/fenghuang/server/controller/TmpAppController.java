package com.sankuai.tripdatecenter.databp.fenghuang.server.controller;

import com.meituan.mdp.boot.starter.web.response.BusinessResponseData;
import com.meituan.mdp.boot.starter.web.response.WebResponse;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.BusinessLineService;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.domain.BusinessLineVO;
import com.sankuai.tripdatecenter.databp.fenghuang.common.enums.ResponseCodeEnum;
import com.sankuai.tripdatecenter.databp.fenghuang.common.domain.request.TmpAppRequestParam;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.tmpapp.IndicatorOrDimVO;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.tmpapp.TmpAppDetailVO;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.tmpapp.TmpAppInfoVO;
import com.sankuai.tripdatecenter.databp.fenghuang.server.service.TmpAppService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * description 临时应用Controller类
 *
 * @author nixuefeng
 * @createTime 2022/4/6 3:41 下午
 */

@RestController
@Api(description = "临时应用相关api")
@RequestMapping("/api/fh/app")
public class TmpAppController {

    @Autowired
    private TmpAppService tmpAppService;

    @Autowired
    private BusinessLineService businessLineService;

    @PostMapping("/list")
    @ApiOperation(value = "临时应用列表")
    public WebResponse<BusinessResponseData<TmpAppInfoVO>> listTmpApp(@RequestBody TmpAppRequestParam tmpAppRequest) {
        BusinessLineVO businessLineVO = businessLineService.getBusinessLineByBusinessId(tmpAppRequest.getBusinessId());
        tmpAppRequest.setBusinessId(businessLineVO.getBusinessId());
        return WebResponse.buildData(tmpAppService.listTmpApp(tmpAppRequest));
    }

    @GetMapping("/get")
    @ApiOperation(value = "临时应用详情")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "tmpAppId", value = "临时应用Id", dataType = "Long", required = true, paramType = "query"),
            @ApiImplicitParam(name = "version", value = "临时应用版本", dataType = "Long", paramType = "query")
    })
    public WebResponse<TmpAppDetailVO> getTmpApp(@RequestParam Long tmpAppId, @RequestParam(required = false) Long version, @RequestParam(required = false) String businessId) {
        BusinessLineVO businessLineVO = businessLineService.getBusinessLineByBusinessId(businessId);
        return WebResponse.buildData(tmpAppService.getTmpAppDetail(tmpAppId, version, businessLineVO.getBusinessId()));
    }

    @PostMapping("/submit")
    @ApiOperation(value = "临时应用提交")
    public WebResponse<ResponseCodeEnum> submitTmpApp(@RequestBody TmpAppDetailVO tmpAppDetail, @RequestParam(required = false) String businessId) {
        BusinessLineVO businessLineVO = businessLineService.getBusinessLineByBusinessId(businessId);
        if (tmpAppService.submitTmpApp(tmpAppDetail, businessLineVO.getBusinessId())) {
            return WebResponse.buildData(ResponseCodeEnum.SUCCESS);
        } else {
            return WebResponse.buildData(ResponseCodeEnum.UNKNOWN_ERROR);
        }
    }

    @GetMapping("/online")
    @ApiOperation(value = "临时应用上线")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "tmpAppId", value = "临时应用Id", dataType = "Long", required = true, paramType = "query"),
            @ApiImplicitParam(name = "version", value = "临时应用版本", dataType = "Long", paramType = "query"),
            @ApiImplicitParam(name = "isOnline", value = "上线为1，下线为0", dataType = "Short", required = true, paramType = "query")
    })
    public WebResponse<ResponseCodeEnum> onlineTmpApp(@RequestParam Long tmpAppId, @RequestParam(required = false) Long version, @RequestParam Short isOnline
        ,@RequestParam(required = false) String businessId) {
        BusinessLineVO businessLineVO = businessLineService.getBusinessLineByBusinessId(businessId);
        if (tmpAppService.onlineTmpApp(tmpAppId, version, isOnline, businessLineVO.getBusinessId())) {
            return WebResponse.buildData(ResponseCodeEnum.SUCCESS);
        } else {
            return WebResponse.buildError(ResponseCodeEnum.NOT_FOUND.getCode(), "未找到需要操作的临时应用");
        }
    }

    @GetMapping("/remove")
    @ApiOperation(value = "临时应用删除")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "tmpAppId", value = "临时应用Id", dataType = "Long", required = true, paramType = "query")
    })
    public WebResponse<ResponseCodeEnum> removeTmpApp(@RequestParam Long tmpAppId, @RequestParam(required = false) String businessId) {
        BusinessLineVO businessLineVO = businessLineService.getBusinessLineByBusinessId(businessId);
        if (tmpAppService.removeTmpApp(tmpAppId, businessLineVO.getBusinessId())) {
            return WebResponse.buildData(ResponseCodeEnum.SUCCESS);
        } else {
            return WebResponse.buildError(ResponseCodeEnum.NOT_FOUND.getCode(), "未找到需要删除的临时应用");
        }
    }

    @PostMapping("/sqlParse")
    @ApiOperation(value = "临时应用sql解析")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "tmpAppId", value = "临时应用Id", dataType = "Long", paramType = "query"),
            @ApiImplicitParam(name = "version", value = "临时应用版本", dataType = "Long", paramType = "query")
    })
    public WebResponse<List<IndicatorOrDimVO>> parseSql(@RequestBody String sql, @RequestParam(required = false) Long tmpAppId, @RequestParam(required = false) Long version
        , @RequestParam(required = false) String businessId) {
        BusinessLineVO businessLineVO = businessLineService.getBusinessLineByBusinessId(businessId);
        return WebResponse.buildData(tmpAppService.sqlParseToFields(sql, tmpAppId, version, businessLineVO.getBusinessId()));
    }

    @PostMapping("/metaVerify")
    @ApiOperation(value = "指标维度校验接口")
    public WebResponse<ResponseCodeEnum> metaVerify() {
        return WebResponse.buildData(ResponseCodeEnum.SUCCESS);
    }

    @GetMapping("/getAggregateFunction")
    @ApiOperation(value = "获取聚合方式枚举接口")
    public WebResponse<List<String>> getAggregateFunction() {
        return WebResponse.buildData(tmpAppService.getAggregateFunction());
    }
}
