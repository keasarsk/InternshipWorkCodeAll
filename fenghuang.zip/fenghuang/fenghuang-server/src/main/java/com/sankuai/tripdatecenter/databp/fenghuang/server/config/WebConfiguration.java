package com.sankuai.tripdatecenter.databp.fenghuang.server.config;

import com.sankuai.it.sso.sdk.spring.FilterFactoryBean;
import com.sankuai.tripdatecenter.databp.fenghuang.common.listener.MySSOListener;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


@Configuration
public class WebConfiguration {

    /**
     * mtFilter配置
     */
    @Bean
    public FilterFactoryBean mtFilterBean(@Value("${mdp.sso.clientId}") String clientId,
                                          @Value("${mdp.sso.secret}") String secret,
                                          @Value("${mdp.sso.exclude-paths}") String excludePaths) {
        FilterFactoryBean filterFactoryBean = new FilterFactoryBean();
        filterFactoryBean.setClientId(clientId);
        filterFactoryBean.setSecret(secret);
        filterFactoryBean.setExcludedUriList(excludePaths);
        // 强制https
        filterFactoryBean.setSchema("https");
        filterFactoryBean.setSsoListener(MySSOListener.class.getName());
        return filterFactoryBean;
    }
}
