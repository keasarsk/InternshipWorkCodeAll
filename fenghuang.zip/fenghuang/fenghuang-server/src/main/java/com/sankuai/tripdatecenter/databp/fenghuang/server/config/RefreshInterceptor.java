package com.sankuai.tripdatecenter.databp.fenghuang.server.config;

import com.meituan.mtrace.Tracer;
import com.sankuai.tripdatecenter.databp.fenghuang.common.enums.YnEnum;
import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.JsonUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@Component
@Slf4j
public class RefreshInterceptor implements HandlerInterceptor {

    private static final String FORCE_RESET_CACHE = "fh.cache.force_reset_cache";

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        //获取对应请求头的值
        log.info("interceptor=====>:{}", JsonUtils.toJson(request.getHeaderNames()));
        log.info("写入强制刷新标识");
        if(Tracer.getAllContext() != null){
            Tracer.getAllContext().put(FORCE_RESET_CACHE, String.valueOf(YnEnum.Y.getCode()));
        }
        return true;
    }

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {

    }
}
