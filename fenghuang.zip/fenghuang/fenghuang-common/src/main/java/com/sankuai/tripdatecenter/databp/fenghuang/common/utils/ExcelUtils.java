package com.sankuai.tripdatecenter.databp.fenghuang.common.utils;

import com.sankuai.databp.common.web.enums.DataTypeStringEnum;
import com.sankuai.databp.common.web.vo.CommonDataVo;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static com.sankuai.databp.common.web.enums.DataTypeStringEnum.STRING;

/**
 * Created by mayuzhe on 2021/8/27
 *
 * @author mayuzhe
 */
@Slf4j
public class ExcelUtils {
    private static final String NUMBER_FORMAT = "#.00";

    /**
     * 生成表格
     *
     * @param commonDataVo
     * @return
     */

    private static void createExel(CommonDataVo<CommonDataVo.Row<CommonDataVo.DataCell>, CommonDataVo.DataCell, CommonDataVo.Column> commonDataVo,
                                                      boolean ignoreNullShowName,
                                                      XSSFWorkbook workBook,
                                                      String sheetName) {
        XSSFSheet sheet;
        if (StringUtils.isBlank(sheetName)) {
            sheet = workBook.createSheet();
        } else {
            sheet = workBook.createSheet(sheetName);
        }

        //插入需导出的表头
        XSSFRow titleRow = sheet.createRow(0);
        List<CommonDataVo.Column> columnList = commonDataVo.getColumns().stream().filter(e -> !(ignoreNullShowName && e.getName() == null)).collect(Collectors.toList());
        Map<String, CommonDataVo.Column> columnMap = columnList.stream().collect(Collectors.toMap(CommonDataVo.Column::getKey, e -> e));
        for (int i = 0; i < columnList.size(); i++) {
            XSSFCell cell = titleRow.createCell(i);
            cell.setCellValue(columnList.get(i).getName());
        }
        //插入需导出的数据
        for (int i = 0; i < commonDataVo.getRows().size(); i++) {
            int rowIndex = i + 1;
            XSSFRow row = sheet.createRow(rowIndex);
            CommonDataVo.Row<CommonDataVo.DataCell> data = commonDataVo.getRows().get(i);
            for (int j = 0; j < columnList.size(); j++) {
                XSSFCell cell = row.createCell(j);
                String columnKey = columnList.get(j).getKey();
                CommonDataVo.DataCell dataCell = data.getValue().get(columnKey);
                String result;
                if (dataCell.isInheritStyle()) {
                    CommonDataVo.Column c = columnMap.get(columnKey);
                    if (c.getDataType().equals("string")) {
                        result = dataCell.getValue();
                    } else {
                        result = format(dataCell.getValue(), getByType(c.getDataType()), c.getDataFormat());
                    }

                } else {
                    if (dataCell.getDataType().equals("string")) {
                        result = dataCell.getValue();
                    } else {
                        result = format(dataCell.getValue(), getByType(dataCell.getDataType()), dataCell.getDataFormat());
                    }
                }
                cell.setCellValue(result);
                cell.setCellType(CellType.STRING);
            }
        }
    }

    public static ByteArrayInputStream generateExcel(CommonDataVo<CommonDataVo.Row<CommonDataVo.DataCell>, CommonDataVo.DataCell, CommonDataVo.Column> commonDataVo, boolean ignoreNullShowName) {
        XSSFWorkbook workBook = new XSSFWorkbook();
        createExel(commonDataVo, ignoreNullShowName, workBook, null);
        return getByteArrayInputStream(workBook);
    }

    public static void generateExcel(CommonDataVo<CommonDataVo.Row<CommonDataVo.DataCell>, CommonDataVo.DataCell, CommonDataVo.Column> commonDataVo,
                                                     boolean ignoreNullShowName,
                                                     XSSFWorkbook workBook,
                                                     String sheetName) {
        createExel(commonDataVo, ignoreNullShowName, workBook, sheetName);
    }


    /**
     * excel对象转为字节数组流
     *
     * @param workBook
     * @return
     */
    public static ByteArrayInputStream getByteArrayInputStream(XSSFWorkbook workBook) {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        try {
            workBook.write(bos);
        } catch (IOException e) {
            log.error("excel写流失败", e);
        } finally {
            try {
                workBook.close();
            } catch (IOException e) {
                log.error("关闭流失败", e);
            }
        }
        byte[] byteArray = bos.toByteArray();
        return new ByteArrayInputStream(byteArray);
    }

    public static DataTypeStringEnum getByType(String type) {
        for (DataTypeStringEnum anEnum : DataTypeStringEnum.values()) {
            if (anEnum.getType().equals(type)) {
                return anEnum;
            }
        }
        return STRING;
    }

    //添加了万订单
    public static String format(String origin, DataTypeStringEnum type, CommonDataVo.Style.StyleFormat styleFormat) {
        Integer digit = styleFormat.getDigit();
        try {
            if (digit == null) {
                digit = 2;
            }
            switch (type) {
                case STRING:
                    return origin;
                case NUMBER:
                    String unit = styleFormat.getUnit();
                    String res;
                     if ("percent".equals(unit)) {
                        res = new BigDecimal(origin).multiply(new BigDecimal(100)).setScale(digit, RoundingMode.HALF_EVEN) + "%";
                    } else if ("pp".equals(unit)) {
                        res = new BigDecimal(origin).multiply(new BigDecimal(100)).setScale(digit, RoundingMode.HALF_EVEN) + "pp";
                    } else if ("w_order".equals(unit)) {
                         res = new BigDecimal(origin).multiply(new BigDecimal(10000)).setScale(digit, RoundingMode.HALF_EVEN) + "万订单";
                    } else {
                         res = String.valueOf(new BigDecimal(origin).setScale(digit, RoundingMode.HALF_EVEN));
                    }
                    return res;
                case DATE:
                    return new SimpleDateFormat("yyyyMMdd").format(origin);
                case TIME:
                    return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(origin);
                default:
                    return origin;
            }
        } catch (Exception e) {
            return origin;
        }
    }
}
