package com.sankuai.tripdatecenter.databp.fenghuang.common.enums;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2022/4/12 8:08 下午
 */
public enum FieldTypeEnum {
    INDICATOR((short) 1,"INDICATOR"),
    DIMENSION((short) 2,"DIMENSION");

    private Short code;
    private String type;

    private FieldTypeEnum(short code, String type) {
        this.code = code;
        this.type = type;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Short getCode() {
        return code;
    }

    public void setCode(Short code) {
        this.code = code;
    }
}
