package com.sankuai.tripdatecenter.databp.fenghuang.common.utils;

import org.apache.commons.lang.StringUtils;

import java.io.InputStream;
import java.util.Properties;

/**
 * Description:
 *
 * @author mayuzhe@meituan.com
 * @date 2022/4/26
 */
public class AppKey {
    private static String currentAppKey;

    public static synchronized String get() {
        if (currentAppKey == null) {
            // 加载jar包中的app.properties配置
            try {
                InputStream is = AppKey.class.getResourceAsStream("/META-INF/app.properties");
                if (is != null) {
                    Properties prop = new Properties();
                    prop.load(is);
                    currentAppKey = prop.getProperty("app.name");
                }
                if (StringUtils.isBlank(currentAppKey)) {
                    throw new IllegalArgumentException("app.properties file not found.");
                }
            } catch (Exception ex) {
                throw new IllegalArgumentException(ex);
            }
        }
        return currentAppKey;
    }
}
