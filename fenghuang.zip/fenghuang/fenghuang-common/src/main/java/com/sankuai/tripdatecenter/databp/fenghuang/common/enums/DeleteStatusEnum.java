package com.sankuai.tripdatecenter.databp.fenghuang.common.enums;


/**
 *
 */
public enum DeleteStatusEnum {
    DELETED((short) 1, "已删除"),
    NOT_DELETED((short) 0, "有效状态");

    private short code;
    private String desc;

    private DeleteStatusEnum(short code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public short getCode() {
        return this.code;
    }

    public String getDesc() {
        return this.desc;
    }

}
