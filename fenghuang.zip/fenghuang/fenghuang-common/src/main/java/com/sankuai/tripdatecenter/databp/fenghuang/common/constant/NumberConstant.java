package com.sankuai.tripdatecenter.databp.fenghuang.common.constant;

/**
 * description 数字常量
 *
 * @author nixuefeng
 * @createTime 2022/4/7 5:58 下午
 */
public class NumberConstant {
    public static final int ZERO = 0;
    public static final int ONE = 1;
}
