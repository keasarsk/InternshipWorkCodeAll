package com.sankuai.tripdatecenter.databp.fenghuang.common.utils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.google.gson.JsonParser;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

/**
 * description GsonUtil .
 *
 * @author fuzhengwei02
 * @createTime 2021/10/13 上午11:07
 */
@Slf4j
public class JsonUtils {

    private static final Gson GSON = new GsonBuilder()
            .registerTypeAdapter(Date.class, new UtilDateSerializer()).setDateFormat(DateFormat.LONG)
            .registerTypeAdapter(Date.class, new UtilDateDeserializer()).setDateFormat(DateFormat.LONG)
            .disableHtmlEscaping()
            .create();

    private static final String MESSAGE_MULTIPLE_FIELD = "declares multiple JSON fields named";

    public static class UtilDateSerializer implements JsonSerializer<Date> {

        public JsonElement serialize(Date src, Type typeOfSrc,
                                     JsonSerializationContext context) {
            return new JsonPrimitive(src.getTime());
        }
    }

    public static class UtilDateDeserializer implements JsonDeserializer<Date> {

        public Date deserialize(JsonElement json, Type typeOfT,
                                JsonDeserializationContext context) throws JsonParseException {
            return new Date(json.getAsJsonPrimitive().getAsLong());
        }

    }

    /**
     * 将字符串转换为指定数据类型
     *
     * @param str
     * @param clazz
     * @param <T>
     * @return
     */
    public static <T> T string2Class(String str, Class<T> clazz) {
        if (null == str) {
            return null;
        }
        if (clazz.isAssignableFrom(String.class)) {
            return (T) str;
        }
        return GSON.fromJson(str.trim(), clazz);
    }

    /**
     * 将字符串转换成ArrayList
     *
     * @param str
     * @param clazz
     * @param <T>
     * @return
     */
    public static <T> List<T> string2List(String str, Class<T> clazz) {
        if (null == str) {
            return Collections.emptyList();
        }
        Type type = TypeToken.getParameterized(ArrayList.class, clazz).getType();
        return GSON.fromJson(str.trim(), type);
    }

    /**
     * 将字符串转换为指定数据类型
     *
     * @param str
     * @param type
     * @param <T>
     * @return
     */
    public static <T> T string2Type(String str, Type type) {
        if (StringUtils.isBlank(str)) {
            return null;
        }
        if (type.getClass().isAssignableFrom(String.class)) {
            return (T) str;
        }
        return GSON.fromJson(str.trim(), type);
    }

    /**
     * 将对象转为json字符串
     *
     * @param obj
     * @return
     */
    public static String toJson(Object obj) {
        if (null == obj) {
            return null;
        }
        if (obj.getClass().isAssignableFrom(String.class)) {
            return obj.toString();
        }
        String result = null;
        try {
            result = JSON.toJSONString(obj);
        } catch (Exception e) {

        }
        return result;
    }

    /**
     * 将对象转为json字符串，添加serializerFeature 参数
     *
     * @param obj
     * @param serializerFeature
     * @return
     */
    public static String toJson(Object obj, SerializerFeature serializerFeature) {
        if (null == obj) {
            return null;
        }
        if (obj.getClass().isAssignableFrom(String.class)) {
            return obj.toString();
        }
        String result = null;
        try {
            result = JSON.toJSONString(obj, serializerFeature);
        } catch (Exception e) {

        }
        return result;
    }

    /**
     * 获取JsonElement对象值字符串
     *
     * @param element
     * @return
     */
    public static String jsonElement2Str(JsonElement element) {
        if (null == element || element.isJsonNull()) {
            return null;
        }
        if (element.isJsonArray() || element.isJsonObject()) {
            return element.toString();
        }
        if (element.isJsonPrimitive()) {
            return element.getAsString();
        }
        return null;
    }
}
