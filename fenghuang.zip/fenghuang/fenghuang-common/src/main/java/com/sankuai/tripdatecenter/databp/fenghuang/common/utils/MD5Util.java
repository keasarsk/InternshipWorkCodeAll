package com.sankuai.tripdatecenter.databp.fenghuang.common.utils;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import lombok.extern.slf4j.Slf4j;

/**
 * description MD5
 *
 * @author fuzhengwei02
 * @createTime 2022年07月20日 23:17:00
 */
@Slf4j
public class MD5Util {

    public static String encode(String message){
        log.info("encode: {}", message);
        String result ="";
        try {
            MessageDigest md5Digest = MessageDigest.getInstance("MD5");
            byte[] encodeMd5Digest = md5Digest.digest(message.getBytes());
            result = convertByteToHexString(encodeMd5Digest);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        log.info("encode result:{}", result);
        return result;
    }

    public static String convertByteToHexString(byte[] bytes){
        String result="";
        for(int i=0;i<bytes.length;i++){
            int temp= bytes[i] & 0xff;
            String tempHex = Integer.toHexString(temp);
            if(tempHex.length()<2){
                result +="0"+tempHex;
            }else {
                result += tempHex;
            }
        }
        return result;
    }

    public static void main(String args[]){
        System.out.println(encode("admin"));
    }

}
