package com.sankuai.tripdatecenter.databp.fenghuang.common.enums;


/**
 *
 */
public enum QueryStatusEnum {

    SUCCESS(0, "执行成功"),
    FAILED(9, "执行异常");

    private int code;
    private String desc;

    private QueryStatusEnum(int code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public int getCode() {
        return this.code;
    }

    public String getDesc() {
        return this.desc;
    }

}
