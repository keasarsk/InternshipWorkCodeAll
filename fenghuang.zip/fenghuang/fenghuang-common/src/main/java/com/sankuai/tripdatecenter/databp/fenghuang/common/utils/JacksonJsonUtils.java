package com.sankuai.tripdatecenter.databp.fenghuang.common.utils;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import lombok.extern.slf4j.Slf4j;

import java.lang.reflect.Type;
import java.util.List;

/**
 * description
 *
 * @author fuzhengwei02
 * @createTime 2022年07月26日 10:47:00
 */
@Slf4j
public class JacksonJsonUtils {
    /**
     * 线程安全，可全局使用
     */
    public static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

    static {
        //反序列化的时候如果多了其他属性,不抛出异常
        OBJECT_MAPPER.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

        //如果是空对象的时候,不抛异常
        OBJECT_MAPPER.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);

        //属性为null不转换
        OBJECT_MAPPER.setSerializationInclusion(JsonInclude.Include.NON_NULL);
    }

    public static <T> T string2Class(String str, Class<T> clazz) {
        if (null == str) {
            return null;
        }
        if (clazz.isAssignableFrom(String.class)) {
            return (T) str;
        }
        try {
            return OBJECT_MAPPER.readValue(str, clazz);
        }catch (Exception e){
            log.error("解析json异常：" + str + ", " + clazz, e);
            return null;
        }
    }

    public static Object string2List(String str, Class itemClazz) {
        if (null == str) {
            return null;
        }
        try {
            log.info("itemClass:{}", itemClazz);
            return OBJECT_MAPPER.readValue(str, OBJECT_MAPPER.getTypeFactory().constructCollectionType(List.class, itemClazz));
        }catch (Exception e){
            log.error("string2List解析json异常：" + str + ", " + itemClazz, e);
            return null;
        }
    }


}
