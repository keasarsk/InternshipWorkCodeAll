package com.sankuai.tripdatecenter.databp.fenghuang.common.listener;

import com.sankuai.it.sso.sdk.enums.AuthFailedCodeEnum;
import com.sankuai.it.sso.sdk.listener.SSOListener;
import com.sankuai.meituan.auth.vo.User;
import com.sankuai.security.sdk.SecSdk;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * description
 *
 * @author nixuefeng
 * @createTime 2022/11/1 20:09
 */
public class MySSOListener implements SSOListener {

    private static final Logger logger = LoggerFactory.getLogger(MySSOListener.class);

    private static final String[] whiteUrls = {"*.sankuai.com", "*.meituan.com", "localhost"};

    /**
     * 未登录，完成SSO认证过程
     * SSO认证过程中将会跳转到SSO登录页进行登录校验。
     *
     * @param httpServletRequest
     * @param httpServletResponse
     * @param callbackUri
     * @return
     */
    @Override
    public String onRedirectingToSSOLogin(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, String callbackUri) {
        return callbackUri;
    }

    /**
     * 业务方可以在此处对response进行种自定义cookie、自定义Header等操作
     *
     * @param req
     * @param res
     * @param ssoid
     * @param originalUrl
     * @return
     */
    @Override
    public String onRedirectingToOriginalUrl(HttpServletRequest req, HttpServletResponse res, String ssoid, String originalUrl) {
        return originalUrl;
    }

    /**
     * 如果在SSO认证通过后有自己的业务操作，可以重写该回调方法
     * 这里自定义session和cookie最好，说明：https://123.sankuai.com/km/page/60887101
     *
     * @param httpServletRequest
     * @param httpServletResponse
     * @param user
     * @return
     */
    @Override
    public boolean onSSOAuthed(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, User user) {
        String requestUri = httpServletRequest.getRequestURI();
        if ("/login".equals(requestUri)) { // 处理登录请求
            String redirectUrl = httpServletRequest.getParameter("redirect_url");
            if (StringUtils.isBlank(redirectUrl)) {
                redirectUrl = httpServletRequest.getHeader("referer");
            }
            boolean isSecurityUrl = SecSdk.securityUrlRedirect(redirectUrl, whiteUrls);
            if (!isSecurityUrl){
                logger.error("重定向路径非法, redirectUrl={}", redirectUrl);
            }else{
                try {
                    httpServletResponse.sendRedirect(redirectUrl);
                } catch (Exception e) {
                    logger.error("重定向失败, redirectUrl={}", redirectUrl, e);
                }
            }
        }
        return true;
    }

    @Override
    public boolean onSSOAuthFailed(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, AuthFailedCodeEnum authFailedCodeEnum) {
        return false;
    }

    /**
     * 清理cookie
     *
     * @param httpServletRequest
     * @param httpServletResponse
     * @param user
     */
    @Override
    public void onSSOLogouted(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, User user) {

    }
}
