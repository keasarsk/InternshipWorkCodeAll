package com.sankuai.tripdatecenter.databp.fenghuang.common.enums;

import org.apache.commons.lang3.StringUtils;

/**
 * description 临时应用类型枚举类
 *
 * @author nixuefeng
 * @createTime 2022/4/11 7:48 下午
 */
public enum TmpAppTypeEnum {
    SQL(0, "SQL模型"),
    TABLE(1, "表模型");

    private Integer code;
    private String name;

    private TmpAppTypeEnum(Integer code, String name) {
        this.code = code;
        this.name = name;
    }

    public static TmpAppTypeEnum getByCode(Integer code) {
        if(code != null){
            for (TmpAppTypeEnum valEnum : values()) {
                if (valEnum.getCode().equals(code)) {
                    return valEnum;
                }
            }
        }
        return null;
    }

    public Integer getCode() {
        return this.code;
    }

    public String getName() {
        return this.name;
    }
}
