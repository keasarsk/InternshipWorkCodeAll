package com.sankuai.tripdatecenter.databp.fenghuang.common.annotation;

import java.lang.annotation.*;
import java.util.concurrent.TimeUnit;

/**
 * @author jiabosen
 * @date 2022/7/5 14:28
 **/
@Documented
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@Inherited
public @interface CellarOdt {
    String AUTH_SOURCE_CODE() default "";//将军令资源CODE
    String PRODUCT_NAME() default "";  //产品名称
    String SYSTEM_OWNERS() default "mayuzhe;nixuefeng;fuzhengwei02"; // 服务负责人
}