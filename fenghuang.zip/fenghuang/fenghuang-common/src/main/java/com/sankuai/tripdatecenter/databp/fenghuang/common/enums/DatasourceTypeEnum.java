package com.sankuai.tripdatecenter.databp.fenghuang.common.enums;


import org.apache.commons.lang3.StringUtils;

/**
 * description 数据源类型枚举 .
 *
 * @author fuzhengwei02
 * @createTime 2022/6/15 下午3:01
 * @throws
 */
public enum DatasourceTypeEnum {
    BQ_DORIS("BQ_DORIS", "BI-Query_Doris"),
    JDBC_REF("REF", "jdbc-ref")
    ;

    private String code;
    private String desc;

    private DatasourceTypeEnum(String code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public static DatasourceTypeEnum getByCode(String code) {
        if(StringUtils.isNotBlank(code)){
            for (DatasourceTypeEnum valEnum : values()) {
                if (valEnum.getCode().equals(code))
                    return valEnum;
            }
        }
        return null;
    }

    public String getCode() {
        return this.code;
    }

    public String getDesc() {
        return this.desc;
    }

}
