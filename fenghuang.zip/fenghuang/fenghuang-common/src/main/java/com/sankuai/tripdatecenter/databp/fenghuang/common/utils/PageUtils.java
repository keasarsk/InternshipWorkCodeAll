package com.sankuai.tripdatecenter.databp.fenghuang.common.utils;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.meituan.mdp.boot.starter.web.response.BusinessResponseData;
import com.meituan.mdp.boot.starter.web.response.paging.FixedSizePageInfo;
import com.sankuai.tripdatecenter.databp.fenghuang.common.enums.ResponseCodeEnum;
import com.sankuai.tripdatecenter.databp.fenghuang.common.exception.FHErrorException;
import lombok.extern.slf4j.Slf4j;

import java.util.List;

/**
 * Description: 分页工具
 *
 * @author mayuzhe@meituan.com
 * @date 2022/4/18
 */
@Slf4j
public class PageUtils {
    /**
     * 分页
     *
     * @param list     原始列表
     * @param pageNum  当前页码
     * @param pageSize 页长
     * @return 分页结果
     */
    public static <T> List<T> pageList(List<T> list, int pageNum, int pageSize) {
        //计算总页数
        int page = pageCount(list, pageSize);
        //兼容性分页参数错误
        pageNum = pageNum <= 0 ? 1 : pageNum;
        pageNum = Math.min(pageNum, page);
        // 开始索引
        int begin;
        // 结束索引
        int end;
        if (pageNum != page) {
            begin = (pageNum - 1) * pageSize;
            end = begin + pageSize;
        } else {
            begin = (pageNum - 1) * pageSize;
            begin = begin < 0 ? 0 : begin;
            end = list.size();
        }
        return list.subList(begin, end);
    }

    /**
     * 计算总页数
     *
     * @param list     原始列表
     * @param pageSize 页长
     * @return 总页数
     */
    public static <T> int pageCount(List<T> list, int pageSize) {
        return list.size() % pageSize == 0 ? list.size() / pageSize : list.size() / pageSize + 1;
    }

    /**
     * 将普通mybatis list查询转换为分页查询
     *
     * @param queryable 包装list查询
     * @param pageNum   当前页码
     * @param pageSize  页长
     * @return 分页查询结果
     */
    public static <T> BusinessResponseData<T> queryForPage(ListQueryable<T> queryable, int pageNum, int pageSize) {
        try {
            //设置分页参数
            PageHelper.<T>startPage(pageNum, pageSize);
            //执行SQL查询
            PageInfo<T> allPageInfo = new PageInfo<>(queryable.query());
            //设置分页结果
            FixedSizePageInfo pageInfo = FixedSizePageInfo.builder()
                    .totalCount((int) allPageInfo.getTotal())
                    .totalPageCount(allPageInfo.getPages())
                    .currentPageNum(allPageInfo.getPageNum())
                    .pageSize(allPageInfo.getPageSize())
                    .build();
            //构建分页信息
            return BusinessResponseData.<T>builder()
                    .list(allPageInfo.getList())
                    .pageInfo(pageInfo)
                    .build();
        } catch (Exception e) {
            log.error("queryForPage failed:" + e.getMessage(), e);
            throw new FHErrorException(ResponseCodeEnum.SQL_PAGE_ERROR, e);
        }
    }

    /**
     * list查询请求
     *
     * @param <T> 元素类型
     */
    public interface ListQueryable<T> {
        List<T> query();
    }
}
