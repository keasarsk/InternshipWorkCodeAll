package com.sankuai.tripdatecenter.databp.fenghuang.common.enums;

import org.apache.commons.lang3.StringUtils;

/**
 * description 逻辑操作符
 *
 * @author fuzhengwei02
 * @createTime 2022/12/06 7:48 下午
 */
public enum LogicOperatorEnum {
    NONE("NONE", "NONE"),
    OR("OR", "OR"),
    AND("AND", "AND");

    private String code;
    private String name;

    private LogicOperatorEnum(String code, String name) {
        this.code = code;
        this.name = name;
    }

    public static LogicOperatorEnum getByCode(String code) {
        if(StringUtils.isNotBlank(code)){
            for (LogicOperatorEnum valEnum : values()) {
                if (valEnum.getCode().equals(code)) {
                    return valEnum;
                }
            }
        }
        return null;
    }

    public String getCode() {
        return this.code;
    }

    public String getName() {
        return this.name;
    }
}
