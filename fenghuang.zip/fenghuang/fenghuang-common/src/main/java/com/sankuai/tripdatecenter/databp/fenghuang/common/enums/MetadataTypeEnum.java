package com.sankuai.tripdatecenter.databp.fenghuang.common.enums;

import org.apache.commons.lang3.StringUtils;

/**
 * description 元数据类型枚举
 *
 * @author fuzhengwei02
 * @createTime 2022/4/11 7:48 下午
 */
public enum MetadataTypeEnum {
    DIMENSION(1, "维度"),
    INDICATOR(2, "指标");

    private Integer code;
    private String name;

    private MetadataTypeEnum(Integer code, String name) {
        this.code = code;
        this.name = name;
    }

    public static MetadataTypeEnum getByCode(Integer code) {
        if(code != null){
            for (MetadataTypeEnum valEnum : values()) {
                if (valEnum.getCode().equals(code)) {
                    return valEnum;
                }
            }
        }
        return null;
    }

    public Integer getCode() {
        return this.code;
    }

    public String getName() {
        return this.name;
    }
}
