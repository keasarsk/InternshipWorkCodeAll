package com.sankuai.tripdatecenter.databp.fenghuang.common.utils;

import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import com.meituan.mtrace.Tracer;
import com.sankuai.meituan.auth.util.UserUtils;
import com.sankuai.meituan.auth.vo.User;
import com.sankuai.tripdatecenter.databp.client.service.CommonService;
import com.sankuai.tripdatecenter.databp.fenghuang.common.constant.BizConstant;
import com.sankuai.tripdatecenter.databp.fenghuang.common.domain.user.FhUserInfo;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;

/**
 * Description: ID 生成公共类
 *
 * @author mayuzhe@meituan.com
 * @date 2022/4/11
 */
@Component
@Slf4j
public class WutongUserUtils {

    private static Cache<String, String> mockUserMisCache = CacheBuilder.newBuilder()
            .expireAfterWrite(1, TimeUnit.MINUTES)
            .build();

    @Autowired
    private CommonService commonService;


    private static CommonService COMMON_SERVICE;

    /**
     * Trace中SSO用户信息的key
     */
    private static final String SSO_USER_KEY = "sso.user";

    private static final String NULL_FLAG = "__null__";

    /**
     * 默认凤凰用户
     */
    private static final FhUserInfo EMPTY_USER = new FhUserInfo();

    @PostConstruct
    void initialize(){
        COMMON_SERVICE = commonService;
    }

    /**
     * 获取当前用户
     *
     * @return
     */
    public static String getUser(){
//        User user = UserUtils.getUser();
//        if(user != null && StringUtils.isNotBlank(user.getLogin())){
//            return COMMON_SERVICE.getMockMis(user.getLogin());
//        } else {
//            return null;
//        }
        FhUserInfo fhUserInfo = getUser2();
        if(fhUserInfo != null){
            return fhUserInfo.getMisId();
        }else{
            return null;
        }
    }

    public static FhUserInfo getUser2(){
        User user = UserUtils.getUser();
        log.info("FhUserInfo getUser2 realMis {}",JsonUtils.toJson(user));
        if(user != null && StringUtils.isNotBlank(user.getLogin())){
            String realMis = user.getLogin();
            String cacheMockMis = mockUserMisCache.getIfPresent(realMis);
            log.info("FhUserInfo getUser2 cacheMockMis {}",cacheMockMis);
            String mockMis = null;
            if(cacheMockMis != null){
                if(!cacheMockMis.equals(NULL_FLAG)){
                    mockMis = cacheMockMis;
//                    log.info("缓存mockMis:" + mockMis);
                }else{
                    //
                }
            }else{
                //调用一次查询
                 mockMis = COMMON_SERVICE.getMockMis(realMis);
                 log.info("调用mockMis服务:" + mockMis);
                 if(mockMis != null){
                     mockUserMisCache.put(realMis, mockMis);
                     log.info("写入mockMis缓存:" + mockMis);
                 }else{
                     mockUserMisCache.put(realMis, NULL_FLAG);
                 }
            }
            if(mockMis != null && mockMis.equals(realMis)){
                log.info("mockMis.equals(realMis) realMis {}",realMis);
                FhUserInfo userInfo = new FhUserInfo();
                userInfo.setMisId(user.getLogin());
                userInfo.setMisName(user.getName());
                return userInfo;
            } else if(mockMis == null){
                log.info("mockMis == null mockMis {}",mockMis);
                FhUserInfo userInfo = new FhUserInfo();
                userInfo.setMisId(user.getLogin());
                userInfo.setMisName(user.getName());
                return userInfo;
            } else{
                log.info("mockMis == null mockMis {}",mockMis);
                FhUserInfo userInfo = new FhUserInfo();
                userInfo.setMisId(mockMis);
                userInfo.setMisName(mockMis);
                return userInfo;
            }
        } else {
            return null;
        }
    }

    private static String existUser(){
        String user = getUser();
        if(StringUtils.isNotBlank(user)){
            return user;
        }
        if (Tracer.getAllContext() == null) {
            log.error("trace中不存在SSO用户信息，track context:{},thread:{}", Tracer.getAllContext(), Thread.currentThread().getName());
            return null;
        }
        Map<String, String> context = Tracer.getAllContext();
        if(context.containsKey(SSO_USER_KEY)){
            return SSO_USER_KEY;
        }
        if(context.containsKey(BizConstant.FH_SSO_USER_KEY)){
            return BizConstant.FH_SSO_USER_KEY;
        }
        log.error("trace中不存在SSO用户信息，track context:{},thread:{}", Tracer.getAllContext(), Thread.currentThread().getName());
        return null;
    }

    public static FhUserInfo getFhUserInfo() {
        String userKey = existUser();
        if(org.apache.commons.lang3.StringUtils.isBlank(userKey)){
            return null;
        }
        FhUserInfo fhUserInfo = getUser2();
        if(fhUserInfo != null){
            return fhUserInfo;
        }else if(SSO_USER_KEY.equals(userKey)){
            //从trace中获取用户信息
            String userInfoJson = Tracer.getContext(SSO_USER_KEY);
            User user = JsonUtils.string2Class(userInfoJson, User.class);
            if(user == null){
                return EMPTY_USER;
            }
            FhUserInfo userInfo = new FhUserInfo();
            userInfo.setMisId(user.getLogin());
            userInfo.setMisName(user.getName());
            return userInfo;
        } else if(BizConstant.FH_SSO_USER_KEY.equals(userKey)){
            String userInfoJson = Tracer.getContext(BizConstant.FH_SSO_USER_KEY);
            FhUserInfo user = JsonUtils.string2Class(userInfoJson, FhUserInfo.class);
            return user == null ? EMPTY_USER : user;
        }
        return EMPTY_USER;
    }

}