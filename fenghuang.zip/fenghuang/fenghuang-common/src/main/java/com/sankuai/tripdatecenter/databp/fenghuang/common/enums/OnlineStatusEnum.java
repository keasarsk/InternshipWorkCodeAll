package com.sankuai.tripdatecenter.databp.fenghuang.common.enums;


/**
 * description 在线状态枚举类型
 *
 * @author nixuefeng
 * @createTime 2022/4/7 6:26 下午
 */
public enum OnlineStatusEnum {
    OFFLINE((short) 0, "未在线"),
    ONLINE((short)1, "已在线");

    private short code;
    private String message;

    private OnlineStatusEnum(short code, String message) {
        this.code = code;
        this.message = message;
    }

    public static String getMessageByCode(int code) {
        for (OnlineStatusEnum valEnum : values()) {
            if (valEnum.getCode() == code)
                return valEnum.getMessage();
        }
        return null;
    }

    public short getCode() {
        return code;
    }

    public void setCode(short code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
