package com.sankuai.tripdatecenter.databp.fenghuang.common.enums;

import org.apache.commons.lang3.StringUtils;

/**
 * description 数据单位类型 .
 *
 * @author fuzhengwei02
 * @createTime 2022/8/19 下午3:16
 * @throws
 */
public enum DataUnitEnum {
    PERCENT("percent", "%"),
    PP("pp", "pp"),
    K("k", "千"),
    W("w", "万"),
    M("m", "百万"),
    W_ORDER("w_order", "万订单");

    private String code;
    private String name;

    private DataUnitEnum(String code, String name) {
        this.code = code;
        this.name = name;
    }

    public static DataUnitEnum getByCode(String code) {
        if(StringUtils.isNotBlank(code)){
            for (DataUnitEnum valEnum : values()) {
                if (valEnum.getCode().equals(code)) {
                    return valEnum;
                }
            }
        }
        return null;
    }

    public String getCode() {
        return this.code;
    }

    public String getName() {
        return this.name;
    }
}
