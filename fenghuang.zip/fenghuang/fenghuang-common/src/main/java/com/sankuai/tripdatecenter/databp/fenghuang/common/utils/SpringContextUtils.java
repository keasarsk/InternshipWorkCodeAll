package com.sankuai.tripdatecenter.databp.fenghuang.common.utils;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.core.env.Environment;

@Slf4j
public class SpringContextUtils implements ApplicationContextAware {

    private static ApplicationContext applicationContext;

    /**
     * 获取applicationContext对象
     *
     * @return
     */
    public static ApplicationContext getApplicationContext() {
        return applicationContext;
    }

    /**
     * 根据bean的id来查找对象
     *
     * @param id
     * @return
     */
    public static <T> T getBeanById(String id) {
        try {
            return (T)applicationContext.getBean(id);
        } catch(Exception e){
            log.error("获取spring bean 异常: id=" + id , e.getMessage());
        }
        return null;
    }

    /**
     * 根据bean的class来查找对象
     *
     * @param c
     * @return
     */
    public static <T> T getBeanByClass(Class c) {
        try{
            return (T)applicationContext.getBean(c);
        } catch(Exception e){
            log.error("获取spring bean 异常: class=" + c, e.getMessage());
        }
        return null;
    }

    /**
     * description 获取生效环境 .
     *
     * @throws
     * @author wukailai
     * @createTime 2021/9/16 20:05
     * @return: java.lang.String
     **/
    public static String getActiveEnvironment() {
        Environment environment = applicationContext.getEnvironment();
        String[] profiles = environment.getActiveProfiles();
        if (null == profiles || profiles.length == 0) {
            return environment.getDefaultProfiles()[0];
        }
        return profiles[0];
    }

    @Override
    public void setApplicationContext(ApplicationContext arg0) throws BeansException {
        this.applicationContext = arg0;
    }
}