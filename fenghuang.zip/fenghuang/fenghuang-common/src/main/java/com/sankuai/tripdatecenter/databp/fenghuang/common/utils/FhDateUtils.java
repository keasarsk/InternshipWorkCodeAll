package com.sankuai.tripdatecenter.databp.fenghuang.common.utils;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Set;
import lombok.extern.slf4j.Slf4j;

/**
 * description 日期工具类
 *
 * @author fuzhengwei02
 * @createTime 2022年05月26日 14:32:00
 */
@Slf4j
public class FhDateUtils {

    public static Date getWeekFirstDay(Date date){
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        int weekday = cal.get(Calendar.DAY_OF_WEEK);//当前日期是周几
        if(weekday == 1){//如果是周日,减一
            cal.add(Calendar.DAY_OF_MONTH,-1);
        }
        cal.setFirstDayOfWeek(Calendar.MONDAY);//周一
        int dy = cal.get(Calendar.DAY_OF_WEEK);
        cal.add(Calendar.DATE,cal.getFirstDayOfWeek() - dy);
        return cal.getTime();
    }

    public static Date getWeekEndDay(Date date){
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        int weekday = cal.get(Calendar.DAY_OF_WEEK);//当前日期是周几
        if(weekday == 1){//如果是周日,减一
            cal.add(Calendar.DAY_OF_MONTH,-1);
        }
        cal.setFirstDayOfWeek(Calendar.MONDAY);//周一
        int dy = cal.get(Calendar.DAY_OF_WEEK);
        //计算出周日
        cal.add(Calendar.DATE,cal.getFirstDayOfWeek() - dy + 6);
        return cal.getTime();
    }

    public static Date getMonthFirstDay(Date date){
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.set(Calendar.DAY_OF_MONTH,1);
        calendar.add(Calendar.MONTH,0);
        return calendar.getTime();
    }

    public static Date getMonthEndDay(Date date){
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.set(Calendar.DAY_OF_MONTH,1);
        //下个月第一天的前一天，就是本月最后一天
        calendar.add(Calendar.MONTH,1);
        calendar.add(Calendar.DATE, -1);
        return calendar.getTime();
    }

    public static List<String> getAllWeekDays(List<String> weeks, DateFormat dateFormat){
        //参数去重
        weeks = Lists.newArrayList(Sets.newHashSet(weeks));
        Set<String> weekDays = Sets.newHashSet();
        for(String week : weeks){
            weekDays.addAll(getWeekDays(week, dateFormat));
        }
        return Lists.newArrayList(weekDays);
    }

    public static Date add(Date date, int addCount){
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.DATE, addCount);
        return calendar.getTime();
    }

    public static List<String> getWeekDays(String week, DateFormat dateFormat){
        Date firstDay = getWeekFirstDay(week, dateFormat);
        Date endDay = getWeekEndDay(week, dateFormat);
        List<String> weekDays = Lists.newArrayList();
        while(firstDay.compareTo(endDay) <= 0){
            String dateStr = dateFormat.format(firstDay);
            weekDays.add(dateStr);
            firstDay = add(firstDay, 1);
        }
        return weekDays;
    }

    public static String getWeekFirstDayStr(String dateStr, DateFormat dateFormat){
        try {
            Date date = dateFormat.parse(dateStr);
            Date weekFirstDay = getWeekFirstDay(date);
            return dateFormat.format(weekFirstDay);
        } catch (Exception e){
            log.error("getWeekFirstDayStr error:{}", e);
            throw new RuntimeException("getWeekFirstDayStr failed:" + e.getMessage());
        }
    }

    public static Date getWeekFirstDay(String dateStr, DateFormat dateFormat){
        try {
            Date date = dateFormat.parse(dateStr);
            Date weekFirstDay = getWeekFirstDay(date);
            return weekFirstDay;
        }catch (Exception e){
            log.error("getWeekFirstDay error:{}", e);
            throw new RuntimeException("getWeekFirstDay failed:" + e.getMessage());
        }
    }

    public static Date getWeekEndDay(String dateStr, DateFormat dateFormat){
        try {
            Date date = dateFormat.parse(dateStr);
            Date weekEndDay = getWeekEndDay(date);
            return weekEndDay;
        }catch (Exception e){
            log.error("getWeekEndDay error:{}", e);
            throw new RuntimeException("getWeekEndDay failed:" + e.getMessage());
        }
    }

    public static String getMonthFirstDayStr(String dateStr, DateFormat dateFormat){
        try {
            Date date = dateFormat.parse(dateStr);
            Date monthFirstDay = getMonthFirstDay(date);
            return dateFormat.format(monthFirstDay);
        }catch (Exception e ){
            log.error("getMonthFirstDayStr error:{}", e);
            throw new RuntimeException("getMonthFirstDayStr failed:" + e.getMessage());
        }
    }

    public static Date getMonthFirstDay(String dateStr, DateFormat dateFormat){
        try {
            Date date = dateFormat.parse(dateStr);
            Date monthFirstDay = getMonthFirstDay(date);
            return monthFirstDay;
        }catch (Exception e ){
            log.error("getMonthFirstDay error:{}", e);
            throw new RuntimeException("getMonthFirstDay failed:" + e.getMessage());
        }
    }

    public static Date getMonthEndDay(String dateStr, DateFormat dateFormat){
        try {
            Date date = dateFormat.parse(dateStr);
            Date monthEndDay = getMonthEndDay(date);
            return monthEndDay;
        }catch (Exception e ){
            log.error("getMonthEndDay error:{}", e);
            throw new RuntimeException("getMonthEndDay failed:" + e.getMessage());
        }
    }

    public static String getMonthEndDayStr(String dateStr, DateFormat dateFormat){
        Date date = getMonthEndDay(dateStr, dateFormat);
        return dateFormat.format(date);
    }


    public static Date convertStr2Date(String dateStr, DateFormat dateFormat){
        try {
            return dateFormat.parse(dateStr);
        } catch (Exception e){
            log.error("convertStr2Date failed " + dateStr + ", format :" + dateFormat, e);
            throw new RuntimeException("convertStr2Date failed : " + dateStr);
        }
    }

    public static String convertDate2Str(Date date, DateFormat dateFormat){
        return dateFormat.format(date);
    }


}
