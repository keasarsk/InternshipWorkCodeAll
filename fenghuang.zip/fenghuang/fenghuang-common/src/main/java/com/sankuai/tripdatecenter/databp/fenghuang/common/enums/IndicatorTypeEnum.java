package com.sankuai.tripdatecenter.databp.fenghuang.common.enums;

import org.apache.commons.lang3.StringUtils;

/**
 * description 指标类型枚举类
 *
 * @author nixuefeng
 * @createTime 2022/4/11 7:48 下午
 */
public enum IndicatorTypeEnum {
    ORIGIN("1", "起源指标"),
    TEMP("2", "临时指标"),
    UPLOAD_APP("3", "上传应用指标"),
    BUFFALO("4", "buffalo接口指标");

    private String code;
    private String name;

    private IndicatorTypeEnum(String code, String name) {
        this.code = code;
        this.name = name;
    }

    public static IndicatorTypeEnum getByCode(String code) {
        if(StringUtils.isNotBlank(code)){
            for (IndicatorTypeEnum valEnum : values()) {
                if (valEnum.getCode().equals(code))
                    return valEnum;
            }
        }
        return null;
    }

    public String getCode() {
        return this.code;
    }

    public String getName() {
        return this.name;
    }
}
