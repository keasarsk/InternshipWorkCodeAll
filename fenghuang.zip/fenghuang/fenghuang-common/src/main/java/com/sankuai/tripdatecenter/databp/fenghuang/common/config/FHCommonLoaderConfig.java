package com.sankuai.tripdatecenter.databp.fenghuang.common.config;

import org.springframework.context.annotation.ComponentScan;

/**
 * description：扫包配置
 *
 * @author fuzhengwei02
 * @createTime 2022年06月17日 20:00:00
 */
@ComponentScan(basePackages = {"com.sankuai.tripdatecenter.databp.fenghuang.common"})
public class FHCommonLoaderConfig {
}
