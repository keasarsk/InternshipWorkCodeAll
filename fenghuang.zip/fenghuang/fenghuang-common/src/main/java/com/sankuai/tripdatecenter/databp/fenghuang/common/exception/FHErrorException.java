package com.sankuai.tripdatecenter.databp.fenghuang.common.exception;

import com.sankuai.tripdatecenter.databp.fenghuang.common.enums.ResponseCodeEnum;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * Description: 自定义需要人工介入处理的异常类
 *
 * @author mayuzhe@meituan.com
 * @date 2022/4/19
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class FHErrorException extends RuntimeException {
    private int code;
    private String msg;
    private Exception exception;

    public FHErrorException(ResponseCodeEnum responseCodeEnum) {
        this.code = responseCodeEnum.getCode();
        this.msg = exception.getMessage();
    }

    public FHErrorException(ResponseCodeEnum responseCodeEnum, Exception exception) {
        this.code = responseCodeEnum.getCode();
        this.msg = exception.getMessage();
        this.exception = exception;
    }
}
