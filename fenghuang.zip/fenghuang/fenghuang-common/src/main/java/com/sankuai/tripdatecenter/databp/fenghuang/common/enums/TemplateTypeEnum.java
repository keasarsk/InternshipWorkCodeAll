package com.sankuai.tripdatecenter.databp.fenghuang.common.enums;

import org.apache.commons.lang3.StringUtils;

/**
 * description 模版类型 .
 *
 * @author fuzhengwei02
 * @createTime 2022/8/19 下午3:16
 * @throws
 */
public enum TemplateTypeEnum {
    MVP("mvp", "MVP模版"),
    T_6WEEK_12MONTH("t_6w12m", "6周12月模版"),
    T_6WEEK_12MONTH_V2("t_6w12m_v2", "6周12月模版（V2）");

    private String code;
    private String name;

    private TemplateTypeEnum(String code, String name) {
        this.code = code;
        this.name = name;
    }

    public static TemplateTypeEnum getByCode(String code) {
        if(StringUtils.isNotBlank(code)){
            for (TemplateTypeEnum valEnum : values()) {
                if (valEnum.getCode().equals(code)) {
                    return valEnum;
                }
            }
        }
        return null;
    }

    public String getCode() {
        return this.code;
    }

    public String getName() {
        return this.name;
    }
}
