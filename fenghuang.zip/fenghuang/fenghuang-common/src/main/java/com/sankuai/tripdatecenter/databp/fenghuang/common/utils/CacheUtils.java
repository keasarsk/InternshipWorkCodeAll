package com.sankuai.tripdatecenter.databp.fenghuang.common.utils;

import com.sankuai.tripdatecenter.databp.fenghuang.common.enums.SerializeTypeEnum;
import lombok.extern.slf4j.Slf4j;


@Slf4j
public class CacheUtils {

    public static <T> T convert2Object(byte[] rawValue, SerializeTypeEnum serializeTypeEnum, Class targetClass){
        log.info(" convert2Object rawValue:{}, serializeTypeEnum:{}, targetClass:{}", (rawValue != null), serializeTypeEnum, targetClass);
        if(rawValue != null && serializeTypeEnum != null && targetClass != null){
            switch (serializeTypeEnum){
                case JSON:
                    return (T)getCache4Json(rawValue, targetClass);
                case KRYO:
                    return (T)getCache4Kryo(rawValue);
                default:
                    throw new RuntimeException("unsupported serializeTypeEnum:" + serializeTypeEnum);
            }
        }else{
            log.info("params should be null");
        }
        return null;
    }

    private static <T> T getCache4Json(byte[] valueRaw, Class targetClass){
        String valueStr = new String(valueRaw);
        log.info("returnType:{}, returnClass:{}", targetClass);
        return (T)JacksonJsonUtils.string2Class(valueStr, targetClass);
    }

    private static <T> T getCache4Kryo(byte[] valueRaw){
        log.info("getCache4Kryo");
        return KryoSerializer.deserialize(valueRaw);
    }


}
