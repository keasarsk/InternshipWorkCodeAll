package com.sankuai.tripdatecenter.databp.fenghuang.common.enums;

/**
 * description
 * 业务线ID枚举
 * @author fuzhengwei02
 * @createTime 2023/2/7 14:17
 */
public enum BusinessIdEnum {
    TRIP("trip", "门票度假"),
    TRAFFIC("traffic", "交通");

    private String code;
    private String name;

    private BusinessIdEnum(String code, String name) {
        this.code = code;
        this.name = name;
    }

    public static BusinessIdEnum getByCode(String code) {
        if(code != null){
            for (BusinessIdEnum valEnum : values()) {
                if (valEnum.getCode().equals(code)) {
                    return valEnum;
                }
            }
        }
        return null;
    }

    public String getCode() {
        return this.code;
    }

    public String getName() {
        return this.name;
    }
}
