//package com.sankuai.tripdatecenter.databp.fenghuang.common.utils;
//
//import com.sankuai.tripdatecenter.databp.fenghuang.common.domain.filter.WutongOrgFilterVO;
//import org.apache.commons.collections4.CollectionUtils;
//import org.apache.commons.lang3.StringUtils;
//
//import java.util.ArrayList;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//
///**
// * Description: 梧桐组织架构工具类
// *
// * @author mayuzhe@meituan.com
// * @date 2023/3/27
// */
//public class WutongOrgUtils {
//    public static final String SEPARATOR = "###";
//
//    public static WutongOrgFilterVO nodeEncoder (WutongOrgFilterVO wutongOrgFilterVO) {
//        return nodeEncoder(wutongOrgFilterVO, "");
//    }
//
//    public static List<WutongOrgFilterVO> nodeEncoder(List<WutongOrgFilterVO> list) {
//        List<WutongOrgFilterVO> newList = new ArrayList<>();
//        list.forEach(node -> newList.add(nodeEncoder(node)));
//        return newList;
//    }
//
//    public static WutongOrgFilterVO nodeEncoder (WutongOrgFilterVO wutongOrgFilterVO, String preFix) {
//        preFix = preFix + wutongOrgFilterVO.getValue() + SEPARATOR;
//        String newValue = preFix + wutongOrgFilterVO.getValue();
//
//        WutongOrgFilterVO newWutongOrgFilterVO = new WutongOrgFilterVO();
//        newWutongOrgFilterVO.setNodeType(wutongOrgFilterVO.getNodeType());
//        newWutongOrgFilterVO.setLabel(wutongOrgFilterVO.getLabel());
//        newWutongOrgFilterVO.setCanSelect(wutongOrgFilterVO.getCanSelect());
//        newWutongOrgFilterVO.setValue(newValue);
//        newWutongOrgFilterVO.setChildren(new ArrayList<>());
//        if (CollectionUtils.isNotEmpty(wutongOrgFilterVO.getChildren())) {
//            String finalPreFix = preFix;
//            wutongOrgFilterVO.getChildren().forEach(children -> newWutongOrgFilterVO.getChildren().add(nodeEncoder(children, finalPreFix)));
//        }
//        return newWutongOrgFilterVO;
//    }
//
//    public static Map<String, List<List<WutongOrgFilterVO>>> nodeDecoder (Map<String, List<List<WutongOrgFilterVO>>> map) {
//        Map<String, List<List<WutongOrgFilterVO>>> newMap = new HashMap<>();
//        map.forEach((k, v) -> newMap.put(k, nodeDecoder(v)));
//        return newMap;
//    }
//
//    public static List<List<WutongOrgFilterVO>> nodeDecoder (List<List<WutongOrgFilterVO>> list) {
//        List<List<WutongOrgFilterVO>> newList = new ArrayList<>();
//        list.forEach(group -> {
//            List<WutongOrgFilterVO> groupList = new ArrayList<>();
//            group.forEach(node -> groupList.add(nodeDecoder(node)));
//            newList.add(groupList);
//        });
//        return newList;
//    }
//
//    public static WutongOrgFilterVO nodeDecoder (WutongOrgFilterVO wutongOrgFilterVO) {
//        String value = wutongOrgFilterVO.getValue();
//        String[] values = StringUtils.split(value, SEPARATOR);
//        String realValue = values[values.length - 1];
//
//        WutongOrgFilterVO newWutongOrgFilterVO = new WutongOrgFilterVO();
//        newWutongOrgFilterVO.setNodeType(wutongOrgFilterVO.getNodeType());
//        newWutongOrgFilterVO.setLabel(wutongOrgFilterVO.getLabel());
//        newWutongOrgFilterVO.setCanSelect(wutongOrgFilterVO.getCanSelect());
//        newWutongOrgFilterVO.setValue(realValue);
//        newWutongOrgFilterVO.setChildren(new ArrayList<>());
//
//        if (CollectionUtils.isNotEmpty(wutongOrgFilterVO.getChildren())) {
//            wutongOrgFilterVO.getChildren().forEach(children -> newWutongOrgFilterVO.getChildren().add(nodeDecoder(children)));
//        }
//
//        return newWutongOrgFilterVO;
//    }
//}
