package com.sankuai.tripdatecenter.databp.fenghuang.common.utils;

import java.net.InetAddress;
import java.net.UnknownHostException;
import lombok.extern.slf4j.Slf4j;

/**
 * description TODO
 *
 * @author fuzhengwei02
 * @createTime 2023年01月06日 11:53:00
 */
@Slf4j
public class IpUtil {
    public static String getLocalHostIp() {
        String res = "127.0.0.1";
        InetAddress addr = null;
        try {
            addr = InetAddress.getLocalHost();
            if (addr != null) {
                res = addr.getHostAddress();
            }
        } catch (UnknownHostException e) {
            log.error("Get localhost ip error.", e);
        }
        return res;
    }
}
