package com.sankuai.tripdatecenter.databp.fenghuang.common.enums;


import org.apache.commons.lang3.StringUtils;

/**
 *
 */
public enum ExceptionCodeEnum {

    SUCCESS("SUCCESS", "执行成功"),

    UNKNOWN_EXCEPTION("UNKN_001", "未知异常"),
    INIT_CELLAR_EXCEPTION("INIT_001", "cellar 客户端启动失败"),
    INIT_DEPENDEND_SERVICE_EXCEPTION("INIT_002","初始化容器失败"),
    PARA_NULL_EXCEPTION("PARA_001", "参数不能为null"),
    PARA_GT_ZERO_EXCEPTION("PARA_002", "参数必须大于0"),
    PARA_TYPE_NOT_MATCH_EXCEPTION("PARA_003", "参数类型不匹配"),

    EXEC_FAIL_EXCEPTION("EXEC_001", "执行失败"),

    CONF_NOT_SET_EXCEPTION("CONF_001", "配置未设置"),

    SUPPORT_SERVICE_EXCEPTION("SUPP_OO1", "不支持的服务"),
    SUPPORT_METHOD_EXCEPTION("SUPP_OO2", "不支持的方法"),

    FLOW_CONTROL_EXCEPTION("LIMT_001", "数据服务流控"),

    DB_QUERY_EXCEPTION("DB_001", "数据库查询异常"),

    RESULT_SIZE_EXCEPTION("RESULT_001", "结果数量不符合期望"),

    TIMEOUT_COMMON_EXCEPTION("TIMEOUT_001", "请求执行超时");

    private String code;
    private String desc;

    private ExceptionCodeEnum(String code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public static ExceptionCodeEnum getByCode(String code) {
        if(StringUtils.isNotBlank(code)){
            for (ExceptionCodeEnum valEnum : values()) {
                if (valEnum.getCode().equals(code))
                    return valEnum;
            }
        }
        return null;
    }
    public String getCode() {
        return this.code;
    }

    public String getDesc() {
        return this.desc;
    }

}
