package com.sankuai.tripdatecenter.databp.fenghuang.common.utils;

import com.sankuai.inf.leaf.thrift.IDGen;
import com.sankuai.inf.leaf.thrift.Result;
import com.sankuai.inf.leaf.thrift.Status;
import lombok.extern.slf4j.Slf4j;
import org.apache.thrift.TException;

/**
 * Description: ID 生成公共类
 *
 * @author fuzhengwei02@meituan.com
 * @date 2022/4/11
 */
@Slf4j
public class FhIdUtils {
    /**
     * 唯一 id
     */
    private static long id = 0L;
    /**
     * 1 毫秒内能生成的无重复 id 数
     */
    private static final int ID_NUM_PER_MS = 100;

    private static final String leafKey = "databp.fenghuang.unifiedidv2";

    private static final int INVOKE_RETRY_TIME = 5;

    private FhIdUtils() {
    }

    /**
     *
     * @return
     */
    public static long genFhUnifiedId() {
        IDGen.Iface idGen = (IDGen.Iface) SpringContextUtils.getBeanById("idGen");
        int retryTime = 0;
        while (++retryTime <= INVOKE_RETRY_TIME) {
            try {
                Result result = idGen.get(leafKey);
                if (Status.SUCCESS.equals(result.getStatus())) {
                    return result.getId();
                } else {
                    throw new RuntimeException("leaf id生成异常, 异常码:" + result.getId());
                }
            } catch (TException e) {
                if (e.getMessage() != null && e.getMessage().contains("timeout")) {
                    continue;
                }
                //非超时异常，或因超时重试达到最大重试次数
                if ((e.getMessage() != null && !e.getMessage().contains("timeout")) || retryTime >= INVOKE_RETRY_TIME) {
                    throw new RuntimeException("ID生成失败", e);
                }
            }
        }
        throw new RuntimeException("ID生成错误");
    }

}
