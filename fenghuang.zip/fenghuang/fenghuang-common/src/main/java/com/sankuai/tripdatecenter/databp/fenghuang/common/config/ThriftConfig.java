package com.sankuai.tripdatecenter.databp.fenghuang.common.config;

import com.dianping.pigeon.remoting.ServiceFactory;
import com.meituan.inf.xmdlog.StringUtils;
import com.sankuai.hbdata.auth.client.AuthService;
import com.sankuai.hbdata.auth.client.AuthServiceImpl;
import com.sankuai.tripdatecenter.databp.client.service.CommonService;
import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.AppKey;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Description:
 *
 * @author mayuzhe@meituan.com
 * @date 2022/4/11
 */
@Configuration
@Slf4j
public class ThriftConfig {
    @Bean("databpCommonService")
    public CommonService commonService(@Value("${thrift.common-service.timeout}") Integer timout) {
        return ServiceFactory.getService(CommonService.class, timout);
    }

    @Bean("authService")
    public AuthService authService(@Value("${application.auth-client.secret:}") String secret) {
        if(StringUtils.isEmpty(secret)){
            log.error("未配置将军令secret, param : application.auth-client.secret");
            return null;
        }
        AuthServiceImpl authServiceImpl = new AuthServiceImpl();
        authServiceImpl.setTimeout(50000);
        authServiceImpl.setAppKey("com.sankuai.trip.b.phoenixtree");
        authServiceImpl.setSecret(secret);
        return authServiceImpl;
    }
}
