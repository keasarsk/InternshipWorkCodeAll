package com.sankuai.tripdatecenter.databp.fenghuang.common.utils;



import com.dianping.rhino.Rhino;
import com.dianping.rhino.threadpool.DefaultThreadPoolProperties;
import com.meituan.mdp.boot.starter.threadpool.ExecutorServices;

import java.util.concurrent.*;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2022/4/29 4:35 下午
 */
public class ExecutorPoolUtil {
    public static ExecutorService getExecutorService() {
        long keepAliveTime = 30L;
        return ExecutorServices.forThreadPoolExecutor("fenghuangExecutor",
                keepAliveTime,
                TimeUnit.SECONDS,
                new ThreadPoolExecutor.CallerRunsPolicy());
    }

    public static Executor FENGHUANG_CACHE_THREAD_POOL = Rhino.newThreadPool("fenghuang_cache_threadpool",
            DefaultThreadPoolProperties.Setter().withCoreSize(10).withMaxSize(10)
                    .withKeepAliveTimeMinutes(30).withKeepAliveTimeUnit(TimeUnit.MINUTES)
                    .withBlockingQueue(new LinkedBlockingQueue<>(1000))
                    .withRejectHandler(new ThreadPoolExecutor.AbortPolicy())).getExecutor();
}
