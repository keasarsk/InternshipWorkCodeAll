package com.sankuai.tripdatecenter.databp.fenghuang.common.utils;

import org.apache.commons.lang.StringUtils;
import org.joda.time.*;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import java.util.Date;

/**
 * 时间工具类。
 * 格式化类型参考：https://www.joda.org/joda-time/key_format.html
 *
 * @author mayuzhe
 */
public final class TimeUtils {
    private TimeUtils() {
    }

    static {
        // 默认时区上海
        DateTimeZone.setDefault(DateTimeZone.forID("Asia/Shanghai"));
    }

    /**
     * 默认毫秒级时间格式
     */
    public static final String DEFAULT_MILLIS_TIME_FORMAT = "yyyyMMddHHmmssSSS";
    /**
     * 默认时间格式
     */
    public static final String DEFAULT_TIME_FORMAT = "yyyyMMddHHmmss";
    /**
     * 默认日期格式
     */
    public static final String DEFAULT_DATE_FORMAT = "yyyyMMdd";
    /**
     * 默认周数格式
     */
    public static final String DEFAULT_WEEK_FORMAT = "xxxxww";
    /**
     * 默认月格式
     */
    public static final String DEFAULT_MONTH_FORMAT = "yyyyMM";
    /**
     * 默认年格式
     */
    public static final String DEFAULT_YEAR_FORMAT = "yyyy";

    /**
     * 季度数
     */
    private static final int SEASON_1 = 1;
    private static final int SEASON_2 = 2;
    private static final int SEASON_3 = 3;
    private static final int SEASON_4 = 4;

    /**
     * 获取当前时间戳
     *
     * @return
     */
    public static long getCurrentTimestamp() {
        return DateTimeUtils.currentTimeMillis();
    }

    /**
     * 获取当前毫秒级时间。
     *
     * @return
     */
    public static String getCurrentMillisTime() {
        return formatTime(getCurrentJavaDate(), DEFAULT_MILLIS_TIME_FORMAT);
    }

    /**
     * 获取当前时间。
     *
     * @return
     */
    public static String getCurrentTime() {
        return formatTime(getCurrentJavaDate(), DEFAULT_TIME_FORMAT);
    }

    /**
     * 获取当前日期。
     *
     * @return
     */
    public static String getCurrentDate() {
        return formatTime(getCurrentJavaDate(), DEFAULT_DATE_FORMAT);
    }

    /**
     * 获取当前周数。
     *
     * @return
     */
    public static String getCurrentWeek() {
        return formatTime(getCurrentJavaDate(), DEFAULT_WEEK_FORMAT);
    }

    /**
     * 获取当前月。
     *
     * @return
     */
    public static String getCurrentMonth() {
        return formatTime(getCurrentJavaDate(), DEFAULT_MONTH_FORMAT);
    }

    /**
     * 获取当前季度。
     *
     * @return
     */
    public static String getCurrentSeason() {
        DateTime dt = new DateTime(getCurrentJavaDate());
        int month = dt.getMonthOfYear();
        String season = "0";
        switch (month) {
            case 1:
            case 2:
            case 3:
                season += SEASON_1;
                break;
            case 4:
            case 5:
            case 6:
                season += SEASON_2;
                break;
            case 7:
            case 8:
            case 9:
                season += SEASON_3;
                break;
            case 10:
            case 11:
            case 12:
            default:
                season += SEASON_4;
        }
        return getCurrentYear() + season;
    }

    /**
     * 获取当前年。
     *
     * @return
     */
    public static String getCurrentYear() {
        return formatTime(getCurrentJavaDate(), DEFAULT_YEAR_FORMAT);
    }

    /**
     * 获取当前时间。格式自定义。
     *
     * @param format 格式
     * @return
     */
    public static String getCurrentTime(String format) {
        return formatTime(getCurrentJavaDate(), format);
    }

    /**
     * 获取当前 Java Date 类
     *
     * @return
     */
    public static Date getCurrentJavaDate() {
        return new Date();
    }

    /**
     * 时间格式转换。str -> str
     *
     * @param inputTime    输入时间
     * @param inputFormat  输入时间格式
     * @param outputFormat 输出时间格式
     * @return
     */
    public static String formatTime(String inputTime, String inputFormat, String outputFormat) {
        DateTime dateTime = formatTimeString2DateTime(inputTime, inputFormat);
        return dateTime.toString(outputFormat);
    }

    /**
     * 时间格式转换。Date -> str
     *
     * @param date         时间类
     * @param outputFormat 输出时间格式
     * @return
     */
    public static String formatTime(Date date, String outputFormat) {
        if (StringUtils.isEmpty(outputFormat)) {
            outputFormat = DEFAULT_TIME_FORMAT;
        }
        DateTime dt = new DateTime(date);
        return dt.toString(outputFormat);
    }

    /**
     * 时间格式转换。timestamp -> str
     *
     * @param timestamp    时间戳
     * @param outputFormat 输出时间格式
     * @return
     */
    public static String formatTime(long timestamp, String outputFormat) {
        if (StringUtils.isEmpty(outputFormat)) {
            outputFormat = DEFAULT_TIME_FORMAT;
        }
        DateTime dt = new DateTime(timestamp);
        return dt.toString(outputFormat);
    }

    /**
     * 字符串时间格式转 DateTime 类。str -> DateTime
     *
     * @param dateTimeStr 时间字符串
     * @param format      当前时间字符串格式
     * @return
     */
    public static DateTime formatTimeString2DateTime(String dateTimeStr, String format) {
        DateTimeFormatter dateTimeFormatter = DateTimeFormat.forPattern(format);
        return dateTimeFormatter.parseDateTime(dateTimeStr);
    }

    /**
     * 加小时
     *
     * @param time         原时间
     * @param inputFormat  输入格式
     * @param outputFormat 输出格式
     * @param num          小时数
     * @return
     */
    public static String addHour(String time, String inputFormat, String outputFormat, int num) {
        DateTime dateTime = formatTimeString2DateTime(time, inputFormat);
        dateTime = dateTime.plusHours(num);
        return dateTime.toString(outputFormat);
    }

    /**
     * 加天数
     *
     * @param time         原时间
     * @param inputFormat  输入格式
     * @param outputFormat 输出格式
     * @param num          天数
     * @return
     */
    public static String addDay(String time, String inputFormat, String outputFormat, int num) {
        DateTime dateTime = formatTimeString2DateTime(time, inputFormat);
        dateTime = dateTime.plusDays(num);
        return dateTime.toString(outputFormat);
    }

    /**
     * 加周数
     *
     * @param time         原时间
     * @param inputFormat  输入格式
     * @param outputFormat 输出格式
     * @param num          周数
     * @return
     */
    public static String addWeek(String time, String inputFormat, String outputFormat, int num) {
        DateTime dateTime = formatTimeString2DateTime(time, inputFormat);
        dateTime = dateTime.plusWeeks(num);
        return dateTime.toString(outputFormat);
    }

    /**
     * 加月数
     *
     * @param time         原时间
     * @param inputFormat  输入格式
     * @param outputFormat 输出格式
     * @param num          月数
     * @return
     */
    public static String addMonth(String time, String inputFormat, String outputFormat, int num) {
        DateTime dateTime = formatTimeString2DateTime(time, inputFormat);
        dateTime = dateTime.plusMonths(num);
        return dateTime.toString(outputFormat);
    }

    /**
     * 加年数
     *
     * @param time         原时间
     * @param inputFormat  输入格式
     * @param outputFormat 输出格式
     * @param num          年数
     * @return
     */
    public static String addYear(String time, String inputFormat, String outputFormat, int num) {
        DateTime dateTime = formatTimeString2DateTime(time, inputFormat);
        dateTime = dateTime.plusYears(num);
        return dateTime.toString(outputFormat);
    }

//    public static void main(String[] args) {
//        System.out.println("获取当前毫秒级时间：" + getCurrentMillisTime());
//        System.out.println("获取当前时间：" + getCurrentTime());
//        System.out.println("获取当前日期：" + getCurrentDate());
//        System.out.println("获取当前周：" + getCurrentWeek());
//        System.out.println("获取当前月：" + getCurrentMonth());
//        System.out.println("获取当前季度：" + getCurrentSeason());
//        System.out.println("获取当前年：" + getCurrentYear());
//        System.out.println("获取当前时间戳：" + getCurrentTimestamp());
//        System.out.println("当前时间加一小时：" + addHour(getCurrentTime(), DEFAULT_TIME_FORMAT, DEFAULT_TIME_FORMAT, 1));
//        System.out.println("当前时间加一天：" + addDay(getCurrentTime(), DEFAULT_TIME_FORMAT, DEFAULT_DATE_FORMAT, 1));
//        System.out.println("当前时间加一周：" + addWeek(getCurrentTime(), DEFAULT_TIME_FORMAT, DEFAULT_WEEK_FORMAT, 1));
//        System.out.println("当前时间加一月：" + addMonth(getCurrentTime(), DEFAULT_TIME_FORMAT, DEFAULT_MONTH_FORMAT, 1));
//        System.out.println("当前时间加一年：" + addYear(getCurrentTime(), DEFAULT_TIME_FORMAT, DEFAULT_YEAR_FORMAT, 1));
//        System.out.println("Date 转时间：" + formatTime(getCurrentJavaDate(), DEFAULT_TIME_FORMAT));
//        System.out.println("时间戳转时间：" + formatTime(getCurrentTimestamp(), DEFAULT_TIME_FORMAT));
//        System.out.println("时间格式转换：" + formatTime(getCurrentTime(), DEFAULT_TIME_FORMAT, "yyyy-MM-dd HH:mm:ss"));
//        System.out.println("时间转DateTime：" + formatTimeString2DateTime(getCurrentTime(), DEFAULT_TIME_FORMAT));
//    }
}
