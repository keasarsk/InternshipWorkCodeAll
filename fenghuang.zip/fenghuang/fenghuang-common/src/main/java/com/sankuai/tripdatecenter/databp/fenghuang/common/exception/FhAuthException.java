package com.sankuai.tripdatecenter.databp.fenghuang.common.exception;

public class FhAuthException extends FHBaseException{

    public FhAuthException(int code, String msg) {
        super(code, msg);
    }
}
