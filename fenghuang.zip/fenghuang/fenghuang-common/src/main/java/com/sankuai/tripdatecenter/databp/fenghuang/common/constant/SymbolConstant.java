package com.sankuai.tripdatecenter.databp.fenghuang.common.constant;

/**
 * description 符号常量
 *
 * @author nixuefeng
 * @createTime 2022/4/12 5:18 下午
 */
public class SymbolConstant {
    public static final String CONCAT_UNDERLINE = "_";
    public static final String PERCENT = "%";
}
