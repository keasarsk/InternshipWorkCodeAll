package com.sankuai.tripdatecenter.databp.fenghuang.common.annotation;

import com.sankuai.tripdatecenter.databp.fenghuang.common.config.FHCommonLoaderConfig;
import org.springframework.context.annotation.Import;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * @author fuzhengwei02
 * @description 开启凤凰Common注解
 * @createTime 2022年06月17日 19:30:00
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.TYPE})
@Import(FHCommonLoaderConfig.class)
public @interface EnableFHCommon {
}
