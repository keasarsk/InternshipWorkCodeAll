package com.sankuai.tripdatecenter.databp.fenghuang.common.enums;


/**
 *
 */
public enum ConditionTypeEnum {
    CONDITION(0, "condition"),
    CRITERIA(1, "criteria");

    private Integer code;
    private String desc;

    private ConditionTypeEnum(Integer code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public static ConditionTypeEnum getByCode(Integer code) {
        if(code != null){
            for (ConditionTypeEnum valEnum : values()) {
                if (valEnum.getCode().equals(code)) {
                    return valEnum;
                }
            }
        }
        return null;
    }

    public Integer getCode() {
        return this.code;
    }

    public String getDesc() {
        return this.desc;
    }

}
