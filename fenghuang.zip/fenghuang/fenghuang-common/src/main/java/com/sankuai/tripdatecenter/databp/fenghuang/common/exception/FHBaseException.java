package com.sankuai.tripdatecenter.databp.fenghuang.common.exception;

import com.sankuai.tripdatecenter.databp.fenghuang.common.enums.ResponseCodeEnum;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * description 凤凰系统基础Exception
 *
 * @author nixuefeng
 * @createTime 2022/4/7 8:22 下午
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class FHBaseException extends RuntimeException {
    private int code;
    private String msg;

    public FHBaseException(int code,String msg) {
        this.code = code;
        this.msg = msg;
    }

    public FHBaseException(ResponseCodeEnum responseCodeEnum) {
        super(responseCodeEnum.getMessage());
        this.code = responseCodeEnum.getCode();
        this.msg = responseCodeEnum.getMessage();
    }
}
