package com.sankuai.tripdatecenter.databp.fenghuang.common.enums;

/**
 * description 响应状态码枚举
 *
 * @author nixuefeng
 * @createTime 2022/4/7 11:40 上午
 */
public enum ResponseCodeEnum {
    DATA_EMPTY_OR_NOT_READY(10001,"数据为空或数据未到岗"),
    SQL_PAGE_ERROR(10002,"数据库查询分页异常"),

    /**
     * 指标维度相关
     */
    DIM_EMPTY_ERROR(20001,"维度不存在"),
    DIM_IS_EXISTED(20002,"维度已添加到凤凰维度池中"),
    DIM_DICT_NOT_EXISTED(20003,"不存在维度枚举信息"),
    INDICATOR_EMPTY_ERROR(21001,"指标不存在"),
    INDICATOR_IS_EXISTED(21002,"指标已添加到凤凰指标池中"),
    INDICATOR_NOT_EXISTED(21003,"指标不存在"),
    INDICATOR_DUPLICATE_ERROR(21004,"指标重复"),
    INDICATOR_DELETE_FAILED(22001,"删除失败，id为 {} 的报表中存在待删指标"),
    DIM_DELETE_FAILED(22002,"删除失败，id为 {} 的报表中存在待删维度"),
    /**
     * 临时应用相关
     */
    SQL_PARSE_FAILED(30001,"sql语法错误"),
    /**
     * 数据源相关
     */
    DATASOURCE_IS_EXISTED(40001,"数据源已经存在"),
    /**
     * 数据服务化相关
     */
    APP_TYPE_UNSUPPORT(90001,"应用类型不支持"),

    PERMISSION_DENY(90002,"权限不符合"),

    /**
     * 请求超时
     */
    TIMEOUT(80000,"请求超时"),

    SUCCESS(200, "SUCCESS"),
    BAD_REQUEST(400,"错误请求"),
    FORBID_REQUEST(403,"禁止请求"),
    NOT_FOUND(404,"未找到"),
    UNKNOWN_ERROR(500,"系统错误");

    private int code;
    private String message;

    ResponseCodeEnum(int code, String message) {
        this.code = code;
        this.message = message;
    }

    public static ResponseCodeEnum getByCode(Integer code) {
        if(code != null){
            for (ResponseCodeEnum valEnum : values()) {
                if (valEnum.getCode() == code) {
                    return valEnum;
                }
            }
        }
        return null;
    }

    public int getCode() {
        return this.code;
    }

    public String getMessage() {
        return this.message;
    }
}
