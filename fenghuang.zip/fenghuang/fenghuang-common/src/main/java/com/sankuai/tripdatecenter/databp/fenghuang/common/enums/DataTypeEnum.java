package com.sankuai.tripdatecenter.databp.fenghuang.common.enums;

import org.apache.commons.lang3.StringUtils;

/**
 * description 数据类型 .
 *
 * @author fuzhengwei02
 * @createTime 2022/8/19 下午3:16
 * @throws
 */
public enum DataTypeEnum {
    STRING("string", "字符"),
    NUMBER("number", "数值"),
    DATE("date", "日期"),
    TIME("time", "时间");

    private String code;
    private String name;

    private DataTypeEnum(String code, String name) {
        this.code = code;
        this.name = name;
    }

    public static DataTypeEnum getByCode(String code) {
        if(StringUtils.isNotBlank(code)){
            for (DataTypeEnum valEnum : values()) {
                if (valEnum.getCode().equals(code)) {
                    return valEnum;
                }
            }
        }
        return null;
    }

    public String getCode() {
        return this.code;
    }

    public String getName() {
        return this.name;
    }
}
