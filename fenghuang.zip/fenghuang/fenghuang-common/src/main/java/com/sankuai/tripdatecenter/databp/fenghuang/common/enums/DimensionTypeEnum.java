package com.sankuai.tripdatecenter.databp.fenghuang.common.enums;

import org.apache.commons.lang3.StringUtils;

/**
 * description 维度类型枚举类
 *
 * @author nixuefeng
 * @createTime 2022/4/11 7:48 下午
 */
public enum DimensionTypeEnum {
    ORIGIN("1", "起源维度"),
    TEMP("2", "临时维度");

    private String code;
    private String name;

    private DimensionTypeEnum(String code, String name) {
        this.code = code;
        this.name = name;
    }

    public static DimensionTypeEnum getByCode(String code) {
        if(StringUtils.isNotBlank(code)){
            for (DimensionTypeEnum valEnum : values()) {
                if (valEnum.getCode().equals(code))
                    return valEnum;
            }
        }
        return null;
    }


    public String getCode() {
        return this.code;
    }

    public String getName() {
        return this.name;
    }
}
