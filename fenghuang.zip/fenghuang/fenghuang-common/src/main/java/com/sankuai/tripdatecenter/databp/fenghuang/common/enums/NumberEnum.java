package com.sankuai.tripdatecenter.databp.fenghuang.common.enums;


/**
 *
 */
public enum NumberEnum {
    ZERO( 0, "0"),
    ONE( 1, "1"),
    TWO( 2, "2"),
    THREE(3, "3"),
    FOUR(4, "4"),
    FIVE( 5, "5"),
    SIX( 6, "6"),
    SEVEN(7, "7"),
    EIGHT( 8, "8"),
    NINE( 9, "9"),
    TEN(10, "10");

    private Integer code;
    private String desc;

    private NumberEnum(Integer code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public Integer getCode() {
        return this.code;
    }

    public String getDesc() {
        return this.desc;
    }

}
