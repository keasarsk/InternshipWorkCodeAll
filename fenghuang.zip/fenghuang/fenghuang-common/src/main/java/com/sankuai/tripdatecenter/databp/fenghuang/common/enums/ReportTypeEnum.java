package com.sankuai.tripdatecenter.databp.fenghuang.common.enums;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2023/2/7 14:17
 */
public enum ReportTypeEnum {
    CONFIGURATION((short)1, "WBR配置化"),
    INDIVIDUATION((short)2, "个性化");

    private Short code;
    private String name;

    private ReportTypeEnum(Short code, String name) {
        this.code = code;
        this.name = name;
    }

    public static ReportTypeEnum getByCode(Short code) {
        if(code != null){
            for (ReportTypeEnum valEnum : values()) {
                if (valEnum.getCode().equals(code)) {
                    return valEnum;
                }
            }
        }
        return null;
    }

    public Short getCode() {
        return this.code;
    }

    public String getName() {
        return this.name;
    }
}
