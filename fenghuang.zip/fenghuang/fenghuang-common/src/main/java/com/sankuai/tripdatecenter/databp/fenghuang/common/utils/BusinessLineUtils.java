package com.sankuai.tripdatecenter.databp.fenghuang.common.utils;

import com.sankuai.tripdatecenter.databp.fenghuang.common.enums.BusinessLineEnum;
import org.apache.commons.lang3.StringUtils;

/**
 * description TODO
 *
 * @author fuzhengwei02
 * @createTime 2022年12月08日 23:04:00
 */
public class BusinessLineUtils {

    public static String parseBusinessId(String businessId){
        if(StringUtils.isBlank(businessId)){
            return getDefaultBusinessId();
        }
        return businessId;
    }

    public static String getDefaultBusinessId(){
        return BusinessLineEnum.TRIP.getCode();
    }
}
