package com.sankuai.tripdatecenter.databp.fenghuang.common.enums;

import org.apache.commons.lang3.StringUtils;

/**
 * description 查询任务状态枚举类
 *
 * @author fuzhengwei02
 * @createTime 2023/6/16 5:48 下午
 */
public enum QueryTaskStatusEnum {
    WAIT("0", "执行中"),
    DONE("1", "执行完毕"),
    EXCEPTION("2","执行失败"),
    NOTFOUND("-1","任务不存在");

    private String code;
    private String name;

    private QueryTaskStatusEnum(String code, String name) {
        this.code = code;
        this.name = name;
    }

    public static QueryTaskStatusEnum getByCode(String code) {
        if(StringUtils.isNotBlank(code)){
            for (QueryTaskStatusEnum valEnum : values()) {
                if (valEnum.getCode().equals(code)) {
                    return valEnum;
                }
            }
        }
        return null;
    }

    public String getCode() {
        return this.code;
    }

    public String getName() {
        return this.name;
    }
}
