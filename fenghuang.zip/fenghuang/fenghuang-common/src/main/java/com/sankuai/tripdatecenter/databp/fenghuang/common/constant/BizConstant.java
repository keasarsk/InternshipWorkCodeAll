package com.sankuai.tripdatecenter.databp.fenghuang.common.constant;

/**
 * description 业务常量信息
 *
 * @author nixuefeng
 * @createTime 2022/4/12 7:33 下午
 */
public class BizConstant {

//    public static final int ORIGIN_BUSILINE_ID = 33;

    public static final String ORIGIN_MODULE_KEY = "fenghuang";

    public static final String ORDER_STR = "order_num asc";

    public static final String ORDER_ID_STR = "id asc";

//    public static final String ORIGIN_INVOKE_MIS_ID = "wangzhe30";

    public static final Long INDICATOR_TREE_ROOT_ID = -1L;

    public static final String FH_SSO_USER_KEY = "fh.sso.user";

}
