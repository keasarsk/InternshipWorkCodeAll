package com.sankuai.tripdatecenter.databp.fenghuang.common.aop;


import com.sankuai.hbdata.auth.client.AuthService;
import com.sankuai.hbdata.auth.user.bean.PermissionBean;
import com.sankuai.hbdata.commonutils.metaappquery.MetaAppQuery;
import com.sankuai.hbdata.commonutils.metaappquery.MetaAppQueryUtils;
import com.sankuai.meituan.auth.util.CollectionUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.common.annotation.CellarOdt;
import com.sankuai.tripdatecenter.databp.fenghuang.common.enums.ResponseCodeEnum;
import com.sankuai.tripdatecenter.databp.fenghuang.common.exception.FhAuthException;
import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.*;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.lang.reflect.Method;
import java.util.List;


/**
 * description
 *
 * @author nixuefeng
 * @createTime 2022/11/1 20:23
 */
@Slf4j
@Aspect
@Component
public class OdtAspect {
    @Autowired(required = false)
    private AuthService authService;

    @Value("${auth.switch:true}")
    private boolean authSwitch;


    @Pointcut("@annotation(com.sankuai.tripdatecenter.databp.fenghuang.common.annotation.CellarOdt)")
    public void submitAuth() {
    }

    private CellarOdt getCellarOdt(JoinPoint joinPoint) {
        MethodSignature signature = (MethodSignature) joinPoint.getSignature();
        Method method = signature.getMethod();
        return method.getAnnotation(CellarOdt.class);
    }

    /**
     * 上报应用日志
     *
     * @param joinPoint
     */
    @Around("submitAuth()")
    public Object submitAuth(ProceedingJoinPoint joinPoint) throws Throwable {
        CellarOdt handler = getCellarOdt(joinPoint);
        String authSourceCode = handler.AUTH_SOURCE_CODE();
        String productName = handler.PRODUCT_NAME();
        String systemOwners = handler.SYSTEM_OWNERS();
        if(!authSwitch){
            log.info("未开启将军令鉴权开关，绕过鉴权逻辑");
            return joinPoint.proceed();
        }
        if (this.checkPermission(authSourceCode)) {
            MetaAppQuery.MetaAppLog appLog = new MetaAppQuery.MetaAppLog(AppKey.get(), productName, systemOwners, 1);
            appLog.setDashboardInfo(authSourceCode, productName, appLog.getDashboardOwner(), appLog.getDashboardCore());
            appLog.setTimeInfo(System.currentTimeMillis(), System.currentTimeMillis());
            MetaAppQueryUtils.keepAppLog(appLog, "tripdatecenter");
            //执行目标方法
            return joinPoint.proceed();
        } else {
            log.error("访问者 {} 无产品权限", WutongUserUtils.getUser());
            throw new FhAuthException(ResponseCodeEnum.FORBID_REQUEST.getCode(), "无权限");
        }
    }

    /**
     * 检查权限总入口
     *
     * @return
     */
    private boolean checkPermission(String authSourceCode) {
        if(authService == null){
            log.error("authService is null");
            return false;
        }
        // 若用户无权限，authService.authPermission() 有时候为 null 有时候 size == 0（不知道为啥）。所以需要对这两种情况都要判断一下。
        List<PermissionBean> permissionBeans = authService.authPermission(WutongUserUtils.getUser(), authSourceCode);
        return !CollectionUtils.isEmpty(permissionBeans);
    }
}
