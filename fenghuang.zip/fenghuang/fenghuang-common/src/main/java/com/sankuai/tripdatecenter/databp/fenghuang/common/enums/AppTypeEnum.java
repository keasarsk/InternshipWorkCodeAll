package com.sankuai.tripdatecenter.databp.fenghuang.common.enums;

import org.apache.commons.lang3.StringUtils;

/**
 * description 应用枚举类
 *
 * @author nixuefeng
 * @createTime 2022/4/11 7:48 下午
 */
public enum AppTypeEnum {
    ORIGIN("1", "起源"),
    TMP_APP("2", "临时应用"),
    UPLOAD_APP("3","上传应用"),
    BUFFALO("4","buffalo");

    private String code;
    private String name;

    private AppTypeEnum(String code, String name) {
        this.code = code;
        this.name = name;
    }

    public static AppTypeEnum getByCode(String code) {
        if(StringUtils.isNotBlank(code)){
            for (AppTypeEnum valEnum : values()) {
                if (valEnum.getCode().equals(code)) {
                    return valEnum;
                }
            }
        }
        return null;
    }

    public String getCode() {
        return this.code;
    }

    public String getName() {
        return this.name;
    }
}
