package com.sankuai.tripdatecenter.databp.fenghuang.common.enums;

import org.apache.commons.lang3.StringUtils;

/**
 * description 起源服务类枚举
 *
 * @author fuzhengwei02
 * @createTime 2022/07/01
 */
public enum OriginServiceEnum {
    META_KPI("meta_kpi", "OriginMetaKpiService"),
    META_DIM("meta_dim", "OriginMetaDimService"),
    SQL("sql", "OriginSqlService");

    private String code;
    private String name;

    private OriginServiceEnum(String code, String name) {
        this.code = code;
        this.name = name;
    }

    public static OriginServiceEnum getByCode(String code) {
        if(StringUtils.isNotBlank(code)){
            for (OriginServiceEnum valEnum : values()) {
                if (valEnum.getCode().equals(code)) {
                    return valEnum;
                }
            }
        }
        return null;
    }

    public String getCode() {
        return this.code;
    }

    public String getName() {
        return this.name;
    }
}
