package com.sankuai.tripdatecenter.databp.fenghuang.domain.ba;

import lombok.Data;

import java.util.List;

/**
 * Description:
 *
 * @author mayuzhe@meituan.com
 * @date 2023-03-01
 */
@Data
public class BaTopicIndicatorCollectionVO {
    private long reportId;
    private long topicId;
    private long moduleId;
    private String businessId;
    private List<BaTopicIndicatorVO> indicators;
}
