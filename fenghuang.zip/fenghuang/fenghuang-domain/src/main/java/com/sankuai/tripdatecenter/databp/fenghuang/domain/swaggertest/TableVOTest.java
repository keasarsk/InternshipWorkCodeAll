package com.sankuai.tripdatecenter.databp.fenghuang.domain.swaggertest;

import com.dianping.cat.util.StringUtils;
import com.meituan.mdp.boot.starter.web.response.paging.PageInfo;

import java.util.List;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2022/5/10 4:02 下午
 */
public class TableVOTest<C,R> implements TableVO<C,R>{

    @Override
    public List<R> getRows() {
        return null;
    }

    @Override
    public String getTitle() {
        return null;
    }

    @Override
    public String getSortKey() {
        return null;
    }

    @Override
    public String getSortDirection() {
        return null;
    }

    @Override
    public PageInfo getPageInfo() {
        return null;
    }
}
