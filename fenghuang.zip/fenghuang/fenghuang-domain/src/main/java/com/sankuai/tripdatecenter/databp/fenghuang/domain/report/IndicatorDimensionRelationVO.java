package com.sankuai.tripdatecenter.databp.fenghuang.domain.report;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2022/4/24 4:14 下午
 */
@Data
@ToString
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class IndicatorDimensionRelationVO extends RelationVO{
    /**
     * 关联的报表id
     */
    private Long reportId;

    /**
     * 版本号。格式 yyyyMMddHHmmss
     */
    private Long version;

    /**
     * 主题 id
     */
    private Long topicId;

    /**
     * 维度类型
     */
    private String dimensionType;



}
