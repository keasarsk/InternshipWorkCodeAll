package com.sankuai.tripdatecenter.databp.fenghuang.domain.request;

import com.meituan.mdp.boot.starter.web.response.paging.FixedSizePageInfo;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.report.ReportVO;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2022/4/18 8:06 下午
 */
@Data
@ToString
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class ReportRequestParam extends ReportVO {
    //todo 预留其他条件
    private FixedSizePageInfo pageInfo;

    private String relatedMis;
}
