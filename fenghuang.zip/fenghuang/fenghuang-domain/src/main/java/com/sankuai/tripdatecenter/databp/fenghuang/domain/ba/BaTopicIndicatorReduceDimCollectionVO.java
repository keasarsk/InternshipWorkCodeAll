package com.sankuai.tripdatecenter.databp.fenghuang.domain.ba;

import lombok.Data;

import java.util.List;

@Data
public class BaTopicIndicatorReduceDimCollectionVO {
    /**
     * 维度id
     */
    private String dimensionId;

    /**
     * 维度name
     */
    private String dimensionName;

    /**
     * 排序
     */
    private Integer orderNum;

    /**
     * 维值枚举数据
     */
    private List<BaTopicIndicatorReduceDimEnumVO> dimEnumVOS;
}