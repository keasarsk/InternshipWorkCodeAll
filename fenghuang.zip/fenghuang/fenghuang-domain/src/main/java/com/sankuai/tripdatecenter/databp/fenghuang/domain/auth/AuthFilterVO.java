package com.sankuai.tripdatecenter.databp.fenghuang.domain.auth;

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.util.List;

@Data
@EqualsAndHashCode
public class AuthFilterVO implements Serializable {

    private String name;

    private String value;

    private Boolean all;

    private String type;

    private Integer isAll;

    @EqualsAndHashCode.Exclude
    private List<AuthFilterVO> items;

}