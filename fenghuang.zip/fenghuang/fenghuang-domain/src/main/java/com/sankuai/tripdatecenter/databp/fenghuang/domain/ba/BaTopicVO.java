package com.sankuai.tripdatecenter.databp.fenghuang.domain.ba;

import com.sankuai.tripdatecenter.databp.fenghuang.domain.report.TopicVO;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2023/2/27 15:20
 */
@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class BaTopicVO extends TopicVO {
    /**
     * 是否开启漏斗。0为否，1为开启
     */
    private Short isFunnel = 0;

    /**
     * 是否开启POI搜索。0为否，1为开启
     */
    private Short isPoiSearch = 0;

    /**
     * 是否开启Deal搜索。0为否，1为开启
     */
    private Short isDealSearch = 0;

    /**
     * 是否开启供应商搜索。0为否，1为开启
     */
    private Short isPartnerSearch = 0;

    /**
     * POI搜索
     */
    private String poiDimensionId;

    /**
     * 是否开启地域信息（省份-城市）级联筛选器。1：开启
     */
    private Short isLocation;

    /**
     * 是否开启地域（含大区）组件
     */
    private Short isRegionLocation;

    /**
     * 是否开启战略等级（战略等级-细分）级联筛选器
     */
    private Short isStrategyRank;
}
