package com.sankuai.tripdatecenter.databp.fenghuang.domain.request;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.Date;

/**
 * description
 *
 * @author fuzhengwei02
 * @createTime 2023/2/6 11:40 上午
 */
@Data
@ToString
@NoArgsConstructor
public class UpdateUploadAppParam {

    /**
     * 应用ID
     */
    private Long id;

    /**
     * 应用名称
     */
    private String appName;

    /**
     * 应用用途
     */
    private String appUse;

    /**
     * 业务线ID
     */
    private String businessId;

}
