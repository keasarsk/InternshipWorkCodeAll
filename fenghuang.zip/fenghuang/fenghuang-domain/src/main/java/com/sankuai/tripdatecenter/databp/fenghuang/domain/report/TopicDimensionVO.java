package com.sankuai.tripdatecenter.databp.fenghuang.domain.report;

import com.sankuai.databp.common.web.enums.FilterTypeEnum;
import com.sankuai.tripdatecenter.databp.fenghuang.domain.tmpapp.DimensionVO;
import lombok.Data;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2022/4/21 5:51 下午
 */
@Data
public class TopicDimensionVO extends DimensionVO {
    private Long id;
    private Long reportId;
    private Long topicId;
    private Integer orderNum;
    private FilterTypeEnum compType;
    /**
     * 是否开启权限控制
     */
    private Short isAuth;

    /**
     * 权限控制将军令资源code
     */
    private String authSourceCode;
}
