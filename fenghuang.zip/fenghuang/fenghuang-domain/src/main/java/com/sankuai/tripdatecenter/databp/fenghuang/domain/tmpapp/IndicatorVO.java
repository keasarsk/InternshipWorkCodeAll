package com.sankuai.tripdatecenter.databp.fenghuang.domain.tmpapp;

import lombok.Data;
import lombok.ToString;

/**
 * description 指标VO
 * @author nixuefeng
 * @createTime 2022/4/13 2:27 下午
 */
@Data
@ToString
public class IndicatorVO {
    private Long id;
    private String indicatorId;
    // 起源指标id
    private Long orgIndicatorId;
    private Long version;
    private Long appId;
    private String appType;
    private String indicatorCode;
    private String indicatorName;
    private String indicatorType;
    private String aggregateFunction;
    private String indicatorComment;
    private String indicatorUnit;
    private String businessId;

}
