package com.sankuai.tripdatecenter.databp.fenghuang.domain.ba;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * description
 *
 * @author mayuzhe@meituan.com
 * @date 2023/2/28
 */
@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class BaModuleVO {
    private Long reportId;
    private Long topicId;
    /**
     * 主题 id
     */
    private Long moduleId;
    /**
     * 业务 id
     */
    private String businessId;
    /**
     * 模块名称
     */
    private String moduleName;
    /**
     * 排序
     */
    private Integer orderNum;
}
