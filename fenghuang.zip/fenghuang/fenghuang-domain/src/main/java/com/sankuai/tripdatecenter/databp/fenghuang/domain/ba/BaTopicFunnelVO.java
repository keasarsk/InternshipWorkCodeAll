package com.sankuai.tripdatecenter.databp.fenghuang.domain.ba;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.io.Serializable;
import java.util.List;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2023/2/27 10:51
 */
@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class BaTopicFunnelVO implements Serializable {
    //报表ID
    private Long reportId;

    //主题Id
    private Long topicId;

    //业务线
    private String businessId;

    //指标集合
    private List<FunnelIndicatorVO> funnelIndicators;
}
