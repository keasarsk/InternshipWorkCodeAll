package com.sankuai.tripdatecenter.databp.fenghuang.domain.ba;

import lombok.Data;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2023/5/18 20:01
 */
@Data
public class AuthTopicVO {
    private Long reportId;
    private Long topicId;
    private String topicName;
    /**
     * 是否鉴权
     */
    private Boolean isAuth;

    /**
     * 业务线ID
     */
    private String businessId;
}
