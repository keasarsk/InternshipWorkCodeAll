package com.sankuai.tripdatecenter.databp.fenghuang.domain.meta;

import java.util.List;
import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class AppDetailVO extends AppVO {

    private List<String> indicatorCodes;

    private List<String> dimensionCodes;

}