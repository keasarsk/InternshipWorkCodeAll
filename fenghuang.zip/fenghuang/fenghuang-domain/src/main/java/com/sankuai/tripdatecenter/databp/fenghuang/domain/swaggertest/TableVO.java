package com.sankuai.tripdatecenter.databp.fenghuang.domain.swaggertest;

import com.meituan.mdp.boot.starter.web.response.paging.PageInfo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.util.List;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2022/5/10 3:56 下午
 */
@ApiModel(value = "TableDataVo", description = "table表格类结构")
public interface TableVO<C,R> {
    @ApiModelProperty(value = "数据列信息")
    List<R> getRows();
    @ApiModelProperty(value = "标题")
    String getTitle();
    @ApiModelProperty(value = "排序的字段Key")
    String getSortKey();
    @ApiModelProperty(value = "排序方向")
    String getSortDirection();
    @ApiModelProperty(value = "分页信息")
    PageInfo getPageInfo();
}
