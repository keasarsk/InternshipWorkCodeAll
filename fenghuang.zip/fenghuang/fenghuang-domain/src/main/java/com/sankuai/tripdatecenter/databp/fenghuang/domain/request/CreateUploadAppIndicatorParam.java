package com.sankuai.tripdatecenter.databp.fenghuang.domain.request;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * description
 *
 * @author fuzhengwei02
 * @createTime 2023/2/6 11:40 上午
 */
@Data
@ToString
@NoArgsConstructor
public class CreateUploadAppIndicatorParam {

    /**
     * 应用ID
     */
    private Long appId;

    /**
     * 指标名称
     */
    private String indicatorName;

    /**
     * 业务线ID
     */
    private String businessId;

}
