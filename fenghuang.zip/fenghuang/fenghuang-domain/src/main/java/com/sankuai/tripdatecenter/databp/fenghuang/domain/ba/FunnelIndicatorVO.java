package com.sankuai.tripdatecenter.databp.fenghuang.domain.ba;

import com.sankuai.tripdatecenter.databp.fenghuang.domain.report.DimensionEnumVO;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.io.Serializable;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2023/2/27 10:51
 */
@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class FunnelIndicatorVO implements Serializable {
    //指标ID
    private String indicatorId;

    //维度ID
    private String indicatorName;

    //是否显示
    private Integer isDisplay;

    //位置
    private Integer orderNum;
}
