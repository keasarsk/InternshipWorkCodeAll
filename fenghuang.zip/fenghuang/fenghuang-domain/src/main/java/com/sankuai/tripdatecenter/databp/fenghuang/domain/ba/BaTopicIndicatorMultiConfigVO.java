package com.sankuai.tripdatecenter.databp.fenghuang.domain.ba;

import lombok.Data;

/**
 * Description:
 *
 * @author mayuzhe@meituan.com
 * @date 2023/3/1
 */
@Data
public class BaTopicIndicatorMultiConfigVO {
    // 多选key
    private String multiKey;
    // 多选key
    private String multiName;
    // 是否选择
    private Boolean isSelected;
}
