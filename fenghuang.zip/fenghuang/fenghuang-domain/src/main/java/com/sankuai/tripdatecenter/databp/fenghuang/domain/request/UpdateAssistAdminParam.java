package com.sankuai.tripdatecenter.databp.fenghuang.domain.request;

import lombok.*;

import java.io.Serializable;
import java.util.List;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2022/4/18 8:06 下午
 */
@Data
@ToString
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class UpdateAssistAdminParam implements Serializable {

    /**
     * 报表ID
     */
    private Long reportId;
    /**
     * 业务线ID
     */
    private String businessId;

    private List<String> assistAdmin;

}
