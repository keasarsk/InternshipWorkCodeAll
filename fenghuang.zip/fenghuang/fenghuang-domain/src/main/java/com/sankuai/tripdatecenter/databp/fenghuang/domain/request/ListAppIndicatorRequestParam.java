package com.sankuai.tripdatecenter.databp.fenghuang.domain.request;

import com.meituan.mdp.boot.starter.web.response.paging.FixedSizePageInfo;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class ListAppIndicatorRequestParam {

    /**
     * 分页参数
     */
    private FixedSizePageInfo pageInfo;

    /**
     * 应用ID
     */
    private Long appId;

    /**
     * 应用名称
     */
    private String appName;

    /**
     * 应用用途
     */
    private String appUse;

    /**
     * 是否在线
     */
    private Integer isOnline;

    /**
     * 业务线ID
     */
    private String businessId;

    /**
     * 指标ID
     */
    private String indicatorId;
}
