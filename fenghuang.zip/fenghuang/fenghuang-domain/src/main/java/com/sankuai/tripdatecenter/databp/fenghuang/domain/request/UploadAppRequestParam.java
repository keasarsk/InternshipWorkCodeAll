package com.sankuai.tripdatecenter.databp.fenghuang.domain.request;

import com.meituan.mdp.boot.starter.web.response.paging.FixedSizePageInfo;
import lombok.*;

@Data
@ToString
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class UploadAppRequestParam {

    /**
     * 分页参数
     */
    private FixedSizePageInfo pageInfo;

    /**
     * 应用ID
     */
    private Long id;

    /**
     * 应用名称
     */
    private String appName;

    /**
     * 应用用途
     */
    private String appUse;

    /**
     * 是否在线
     */
    private Integer isOnline;

    /**
     * 业务线ID
     */
    private String businessId;
}
