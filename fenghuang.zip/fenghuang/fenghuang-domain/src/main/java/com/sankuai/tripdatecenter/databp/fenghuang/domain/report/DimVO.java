package com.sankuai.tripdatecenter.databp.fenghuang.domain.report;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class DimVO {
       /**
     * 维度code
     */
    private String dimensionId;

    /**
     * 维度name
     */
    private String dimensionName;

    /**
     * 维度别名
     */
    private String dimensionAlias;

    /**
     * 是否被选中
     */
    private Boolean isSelected;

    /**
     * 展示顺序
     */
    private Integer orderNum = Integer.MAX_VALUE;
}