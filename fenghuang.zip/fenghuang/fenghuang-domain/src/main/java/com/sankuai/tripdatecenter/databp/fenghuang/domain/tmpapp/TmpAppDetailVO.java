package com.sankuai.tripdatecenter.databp.fenghuang.domain.tmpapp;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.ToString;

import java.util.Date;
import java.util.List;

/**
 * description 临时应用详情信息
 *
 * @author nixuefeng
 * @createTime 2022/4/6 8:28 下午
 */
@Data
@ToString
public class TmpAppDetailVO extends TmpAppInfoVO {
    private String definitionInfo;
    private String useInfo;
    private String comment;
    private String sqlTemplate;
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date lastUpdateTime;
    private List<IndicatorOrDimVO> fields;

}
