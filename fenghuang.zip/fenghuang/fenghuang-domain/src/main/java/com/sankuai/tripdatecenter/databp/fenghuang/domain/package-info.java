/**
 * description
 *
 * @author fuzhengwei02
 * @createTime 2022年03月31日 14:08:00
 */

package com.sankuai.tripdatecenter.databp.fenghuang.domain;