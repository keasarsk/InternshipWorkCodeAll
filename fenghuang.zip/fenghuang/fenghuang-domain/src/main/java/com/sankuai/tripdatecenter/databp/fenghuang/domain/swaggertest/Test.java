package com.sankuai.tripdatecenter.databp.fenghuang.domain.swaggertest;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2022/5/12 4:04 下午
 */
public class Test {
    public static void main(String[] args) {
        String json = "{\"project_id\":{\"data\":{\"dimensionCode\":\"project_id_1\",\"value\":[{\"label\":\"北京\",\"value\":\"aaa\"}]},\"type\":\"RADIO\"},\"date_id_domestic\":{\"data\":{\"dimensionCode\":\"date_id_domestic_1\",\"end\":\"20220502\",\"start\":\"20220501\",\"type\":\"DAY\"},\"type\":\"DATE\"},\"keyword_1\":{\"data\":{\"dimensionCode\":\"keyword_1\",\"value\":[{\"label\":\"中国\",\"value\":\"111\"},{\"label\":\"美国\",\"value\":\"222\"}]},\"type\":\"CHECKBOX\"}}";
    }
}
