package com.sankuai.tripdatecenter.databp.fenghuang.domain.report;

import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * description
 *
 * @author fuzhengwei02
 * @createTime 2022/4/20 2:36 下午
 */
@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class TopicExtVO extends TopicVO{

    private List<TopicDimensionExtVO> dimensions;

}
