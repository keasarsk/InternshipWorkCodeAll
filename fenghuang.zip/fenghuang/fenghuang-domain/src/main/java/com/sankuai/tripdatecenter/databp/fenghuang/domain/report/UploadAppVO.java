package com.sankuai.tripdatecenter.databp.fenghuang.domain.report;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.Date;

/**
 * description
 *
 * @author fuzhengwei02
 * @createTime 2023/2/6 11:40 上午
 */
@Data
@ToString
@NoArgsConstructor
public class UploadAppVO {

    /**
     * 应用ID
     */
    private Long id;

    /**
     * 应用名称
     */
    private String appName;

    /**
     * 应用用途
     */
    private String appUse;

    /**
     * 删除状态
     */
    private Long isDelete;

    /**
     * 是否在线
     */
    private Integer isOnline;

    /**
     * 创建人mis
     */
    private String createMis;

    /**
     * 创建人姓名
     */
    private String createName;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新人mis
     */
    private String lastUpdateMis;

    /**
     * 更新人名称
     */
    private String lastUpdateName;

    /**
     * 更新时间
     */
    private Date lastUpdateTime;

    private String businessId;

}
