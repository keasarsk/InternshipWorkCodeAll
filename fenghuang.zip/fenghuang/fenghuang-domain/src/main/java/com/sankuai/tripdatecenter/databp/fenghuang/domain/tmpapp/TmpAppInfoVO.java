package com.sankuai.tripdatecenter.databp.fenghuang.domain.tmpapp;

import lombok.Data;
import lombok.ToString;

/**
 * description 临时应用VO
 * @author nixuefeng
 * @createTime 2022/4/6 8:18 下午
 */
@Data
@ToString
public class TmpAppInfoVO {
    private Long id;
    private Long tmpAppId;
    private String tmpAppName;
    private Long dataSourceId;
    private String dataSourceName;
    private String dataSourceType;
    private String createdMis;
    private Short isOnline;
    private Long version;

}
