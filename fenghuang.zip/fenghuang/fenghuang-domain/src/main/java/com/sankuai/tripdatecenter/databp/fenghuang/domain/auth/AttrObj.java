package com.sankuai.tripdatecenter.databp.fenghuang.domain.auth;

import lombok.Data;

import java.util.List;

@Data
public class AttrObj {

    private String name;

    private String label;

    private List<AuthFilterVO> items;

    private Boolean all;
}
