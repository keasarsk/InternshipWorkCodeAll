package com.sankuai.tripdatecenter.databp.fenghuang.domain.ba;

import lombok.Data;

@Data
public class BaTopicIndicatorReduceDimEnumVO {
    /**
     * 维度枚举code
     */
    private String dimensionEnumCode;

    /**
     * 维度枚举name
     */
    private String dimensionEnumName;

    /**
     * 维度枚举别名
     */
    private String dimensionEnumAlias;


    /**
     * 是否选中
     */
    private Boolean isSelected;
}