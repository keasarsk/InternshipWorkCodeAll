package com.sankuai.tripdatecenter.databp.fenghuang.domain.meta;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class AppVO {
    /**
     * 自增主键
     */
    private Long id;

    /**
     * 版本号。固定:1
     */
    private Long version;

    /**
     * 起源应用id
     */
    private Integer appId;

    /**
     * 起源应用名称
     */
    private String appName;

    /**
     * 备注
     */
    private String appComment;

    /**
     * 数据源DSN
     */
    private String dsn;


}