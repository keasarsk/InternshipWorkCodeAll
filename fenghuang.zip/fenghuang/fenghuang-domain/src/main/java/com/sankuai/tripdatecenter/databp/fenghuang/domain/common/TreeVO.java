package com.sankuai.tripdatecenter.databp.fenghuang.domain.common;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;

/**
 * Description:
 *
 * @author mayuzhe@meituan.com
 * @date 2022/4/21
 */
@Data
public class TreeVO<K, E> {
    private K parentId;
    private K curId;
    private List<E> children = new ArrayList<>();
}
