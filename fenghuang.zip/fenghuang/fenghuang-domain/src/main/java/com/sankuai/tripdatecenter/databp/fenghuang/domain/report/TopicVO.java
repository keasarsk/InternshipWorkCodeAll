package com.sankuai.tripdatecenter.databp.fenghuang.domain.report;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2022/4/20 2:36 下午
 */
@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class TopicVO {
    private Long reportId;
    private Long topicId;
    private String topicName;
    /**
     * 排序
     */
    private Integer orderNum;
    private Long version;
    /**
     * 模版类型字段
     */
    private String templateType;

    /**
     * 是否开启组织架构鉴权
     */
    private Integer isAuth;

    /**
     * 鉴权类型
     */
    private Integer authType;

    /**
     * 业务线ID
     */
    private String businessId;

    /**
     * 权限控制，将军令资源code
     */
    private String authSourceCode;
}
