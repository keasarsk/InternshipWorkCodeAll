package com.sankuai.tripdatecenter.databp.fenghuang.domain.request;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class GetAppIndicatorByIdRequestParam {

    /**
     * 应用ID
     */
    private Long appId;

    /**
     * 业务线ID
     */
    private String businessId;

    /**
     * 指标ID
     */
    private String indicatorId;


}
