package com.sankuai.tripdatecenter.databp.fenghuang.domain.report;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2022/4/24 6:49 下午
 */
@Data
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class IndicatorInfo {
    /**
     * 指标 id
     */
    private String indicatorId;
    /**
     * 指标 id
     */
    private String indicatorName;

    /**
     * 是否有效
     */
    private boolean isSelected;
}
