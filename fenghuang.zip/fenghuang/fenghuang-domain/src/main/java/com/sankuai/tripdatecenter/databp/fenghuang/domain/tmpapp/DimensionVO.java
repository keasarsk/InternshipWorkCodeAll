package com.sankuai.tripdatecenter.databp.fenghuang.domain.tmpapp;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.util.Date;

/**
 * Description: 维度 VO
 *
 * @author mayuzhe@meituan.com
 * @date 2022/4/18
 */
@Data
public class DimensionVO {
    /**
     * 维度 id
     */
    private String dimensionId;

    /**
     * 版本号。格式 yyyyMMddHHmmss
     */
    private Long version;

    /**
     * 应用 id
     */
    private Long appId;

    /**
     * 应用类型。起源1，临时应用2。默认为1
     */
    private String appType;

    /**
     * 维度 code
     */
    private String dimensionCode;

    /**
     * 维度名
     */
    private String dimensionName;

    /**
     * 维度别名
     */
    private String dimensionAlias;

    /**
     * 维度类型
     */
    private String dimensionType;

    /**
     * 维度注释
     */
    private String dimensionComment;

    /**
     * 是否删除。0为未删除，1为删除
     */
    private Short isDelete = 0;

    /**
     * 编辑人
     */
    private String createdMis;

    /**
     * 最新编辑人
     */
    private String lastUpdateMis;

    /**
     * 创建时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date createdTime;

    /**
     * 最后修改时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date updateTime;
}
