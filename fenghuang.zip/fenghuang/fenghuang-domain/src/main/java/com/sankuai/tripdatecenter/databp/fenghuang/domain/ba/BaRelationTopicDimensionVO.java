package com.sankuai.tripdatecenter.databp.fenghuang.domain.ba;

import com.sankuai.tripdatecenter.databp.fenghuang.domain.report.DimensionEnumVO;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.compress.utils.Lists;

import java.util.List;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2023/3/3 16:55
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class BaRelationTopicDimensionVO {
    private Long reportId;
    private Long topicId;
    private String dimensionId;
    private String dimensionName;
    private String dimensionType;
    private List<DimensionRelation> relations = Lists.newArrayList();

    @Data
    public static class DimensionRelation{
        private Long Id;
        private Integer orderNum;
        private String dimensionEnumCode;
        private String dimensionEnumName;
        private String relationDimensionId;
        private String relationDimensionName;
        private List<DimensionEnumVO> relationDimensionEnums = Lists.newArrayList();
    }
}
