package com.sankuai.tripdatecenter.databp.fenghuang.domain.menu;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.List;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2022/4/20 2:51 下午
 */
@Data
@ToString
public class MenuVO {
    /**
     * 资源ID
     */
    private String resourceCode;

    /**
     * 菜单名称
     */
    private String menuName;

    /**
     * 排序
     */
    private String menuUrl;

    /**
     * 子菜单
     */
    private List<MenuVO> children;
}
