package com.sankuai.tripdatecenter.databp.fenghuang.domain.report;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2022/4/20 2:51 下午
 */
@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class ModuleVO {
    private Long reportId;
    private Long topicId;
    private Long version;
    /**
     * 主题 id
     */
    private Long moduleId;
    /**
     * 模块名称
     */
    private String moduleName;
    /**
     * 排序
     */
    private Integer orderNum;
}
