package com.sankuai.tripdatecenter.databp.fenghuang.domain.ba;

import lombok.Data;

import java.util.Date;
import java.util.List;

/**
 * Description:
 *
 * @author mayuzhe@meituan.com
 * @date 2023-03-01
 */
@Data
public class BaTopicIndicatorVO {
    /**
     * 报表 id
     */
    private Long reportId;

    /**
     * 主题 id
     */
    private Long topicId;

    /**
     * 指标模块
     */
    private Long moduleId;

    /**
     * 模块名称
     */
    private String moduleName;

    /**
     * 业务线id
     */
    private String businessId;

    /**
     * 指标 id
     */
    private String indicatorId;

    /**
     * 指标名
     */
    private String indicatorName;

    /**
     * 指标别名
     */
    private String indicatorAlias;

    /**
     * 指标标签
     */
    private String indicatorTag;

    /**
     * 值保留小数
     */
    private Integer valueDigit;

    /**
     * 比率值保留小数
     */
    private Integer rateValueDigit;

    /**
     * 值数据格式
     */
    private String valueType;

    /**
     * 比率值数据格式
     */
    private String rateValueType;

    /**
     * 指标排序
     */
    private Integer orderNum;

    /**
     * 应用来源
     */
    private Integer appSource;

    /**
     * 应用ID
     */
    private Long appId;

    /**
     * 数值单位
     */
    private String valueUnit;

    /**
     * 比率值数值单位
     */
    private String rateValueUnit;

    /**
     * 千分位分隔符
     */
    private Short ksSeparation;

    /**
     * 比率红绿规则
     */
    private Short yoyDisplay;

    /**
     * 是关键指标。0否，1是
     */
    private Short isKey;

    /**
     * 是否支持趋势分析。0不支持，1支持
     */
    private Short isTrend;

    /**
     * 展示比率
     */
    private List<BaTopicIndicatorMultiConfigVO> rateTypes;

    /**
     * 趋势展示比率
     */
    private List<BaTopicIndicatorMultiConfigVO> trendRateTypes;

    /**
     * 开启降维分析。0不开启，1开启
     */
    private Short isDimReduce;

    /**
     * 降维维度List
     */
    private List<BaDimVO> reduceDims;

    /**
     * 降维枚举值
     */
    private List<BaTopicIndicatorReduceDimCollectionVO> dimEnums;

    /**
     * 是否支持明细数据
     */
    private Short isDetail;

    /**
     * 明细维度List
     */
    private List<BaDimVO> detailDims;

    /**
     * 是否删除。0为未删除，1为删除
     */
    private Short isDelete;

    /**
     * 编辑人
     */
    private String createdMis;

    /**
     * 最新编辑人
     */
    private String lastUpdateMis;

    /**
     * 创建时间
     */
    private Date createdTime;

    /**
     * 最后修改时间
     */
    private Date updateTime;
}
