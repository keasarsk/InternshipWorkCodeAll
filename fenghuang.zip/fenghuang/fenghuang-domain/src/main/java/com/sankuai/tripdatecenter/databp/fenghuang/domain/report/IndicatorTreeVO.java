package com.sankuai.tripdatecenter.databp.fenghuang.domain.report;

import lombok.Data;

import java.util.List;

/**
 * Description:
 *
 * @author mayuzhe@meituan.com
 * @date 2022/4/22
 */
@Data
public class IndicatorTreeVO {
    private long reportId;
    private long version;
    private long topicId;
    private long moduleId;
    List<TopicIndicatorVO> indicators;
}
