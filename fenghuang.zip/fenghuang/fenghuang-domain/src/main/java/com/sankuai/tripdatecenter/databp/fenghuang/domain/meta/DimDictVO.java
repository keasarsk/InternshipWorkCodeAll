package com.sankuai.tripdatecenter.databp.fenghuang.domain.meta;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class DimDictVO {

    private String dimCode;//维度代码

    private String dimName;//维度名称

    private String description;//维度描述

}