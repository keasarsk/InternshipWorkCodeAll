package com.sankuai.tripdatecenter.databp.fenghuang.domain.auth;

import lombok.Data;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2023/5/16 15:51
 */
@Data
public class AuthSourceVO {
    private String authSourceCode;
}
