package com.sankuai.tripdatecenter.databp.fenghuang.domain.swaggertest;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.springframework.util.Assert;
import org.springframework.util.CollectionUtils;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2022/5/10 3:56 下午
 */
@Data
@ApiModel(value = "TableDataVo", description = "table表格类结构")
public class TableDataVo{
//public class TableDataVo<R extends TableDataVo.Row<D> , D extends TableDataVo.DataCell, C extends TableDataVo.Column> implements Serializable {
//    @ApiModelProperty(value = "列元信息")
//    private List<C> columns;
//    @ApiModelProperty(value = "数据列信息")
//    private List<R> rows;
//    @ApiModelProperty(value = "标题")
//    private String title;
//    @ApiModelProperty(value = "排序的字段Key")
//    private String sortKey;
//    @ApiModelProperty(value = "排序方向")
//    private String sortDirection;
//    @ApiModelProperty(value = "分页信息")
//    private TableDataVo.PageInfo pageInfo;
//
//
//    /**
//     * 设置列名
//     *
//     * @param list 列信息
//     * @param f    列信息向Column转化的匿名函数
//     * @return this
//     */
//    public <T> TableDataVo<R, D, C> columns(List<T> list, Function<T, C> f) {
//        return columns(list, f, true);
//    }
//
//    /**
//     * 设置列名
//     *
//     * @param list       列信息
//     * @param f          列信息向Column转化的匿名函数
//     * @param assertMeta 是否校验列头信息和数据信息的一致性
//     * @return this
//     */
//    public <T> TableDataVo<R, D, C> columns(List<T> list, Function<T, C> f, Boolean assertMeta) {
//        List<Set<String>> dataKeyList = new ArrayList<>();
//        if (assertMeta && !CollectionUtils.isEmpty(rows)){
//            dataKeyList = rows.stream().map(row -> row.getValue().keySet()).collect(Collectors.toList());
//        }
//        List<Set<String>> finalDataKeyList = dataKeyList;
//        this.columns = list.stream().map(f).peek(e -> {
//            if (!CollectionUtils.isEmpty(finalDataKeyList)) {
//                Assert.isTrue(finalDataKeyList.contains(e.getKey()), "列元信息与列数据不符");
//            }
//        }).collect(Collectors.toList());
//        return this;
//    }
//
//    /**
//     * 设置数据
//     *
//     * @param list 数据源信息
//     * @param f    数据信息向DateCell转换的匿名函数
//     * @return this
//     */
//    public <T> TableDataVo<R, D, C> rows(List<R> rowList, List<T> list, Function<T, Map<String, D>> f) {
//        return rows(rowList, list, f, true);
//    }
//
//    /**
//     * 设置数据
//     *
//     * @param list       数据源信息
//     * @param f          数据信息向DateCell转换的匿名函数
//     * @param assertMeta 是否校验列头信息和数据信息的一致性
//     * @return this
//     */
//    public <T> TableDataVo<R, D, C> rows(List<R> rowList, List<T> list, Function<T, Map<String, D>> f, Boolean assertMeta) {
//        // assert list size
//        List<String> keyList = null;
//        if (!CollectionUtils.isEmpty(columns)) {
//            keyList = columns.stream().map(TableDataVo.Column::getKey).collect(Collectors.toList());
//        }
//        List<String> finalKeyList = keyList;
//        List<Map<String, D>> data = list.stream().map(f).peek(e -> {
//            if (assertMeta && !CollectionUtils.isEmpty(finalKeyList)) {
//                Assert.isTrue(finalKeyList.containsAll(e.keySet()), "列元信息与列数据不符");
//            }
//        }).collect(Collectors.toList());
//        for (int i = 0; i < rowList.size(); i++) {
//            R row = rowList.get(i);
//            if(row != null ){
//                row.setValue(data.get(i));
//            }
//        }
//        return this;
//    }
//
//    /**
//     * 倒序排列
//     *
//     * @param sortKey 排序的字段Key
//     * @return this
//     */
//    public TableDataVo<R, D, C> desc(String sortKey) {
//        this.sortKey = sortKey;
//        this.sortDirection = TableDataVo.SortType.DESC;
//        return this;
//    }
//
//    /**
//     * 正序排列
//     *
//     * @param sortKey 排序的字段Key
//     * @return this
//     */
//    public TableDataVo<R, D, C> asc(String sortKey) {
//        this.sortKey = sortKey;
//        this.sortDirection = TableDataVo.SortType.ASC;
//        return this;
//    }
//
//    /**
//     * 分页信息
//     *
//     * @param pageSize       每页数量
//     * @param currentPageNum 当前页数
//     * @param total          总数
//     * @return this
//     */
//    public TableDataVo<R, D, C> page(int pageSize, int currentPageNum, long total) {
//        this.pageInfo = new PageInfo(pageSize, currentPageNum, total);
//        return this;
//    }
//
//    /**
//     * 标题
//     *
//     * @param title 标题
//     * @return this
//     */
//    public TableDataVo<R, D, C> title(String title) {
//        this.title = title;
//        return this;
//    }
//
//
//    @NoArgsConstructor
//    @Data
//    private static class PageInfo {
//        @ApiModelProperty(value = "每页数量")
//        private Integer pageSize;
//        @ApiModelProperty(value = "当前页数")
//        private Integer currentPageNum;
//        @ApiModelProperty(value = "总页数")
//        private Integer totalPageCount;
//        @ApiModelProperty(value = "总条目数")
//        private Long totalCount;
//
//        public PageInfo(Integer pageSize, Integer currentPageNum, Long totalCount) {
//            this.pageSize = pageSize;
//            this.currentPageNum = currentPageNum;
//            this.totalPageCount = (int) ((totalCount / pageSize) + 1);
//            this.totalCount = totalCount;
//
//        }
//    }
//
//    @EqualsAndHashCode(callSuper = true)
//    @Data
//    public static class DataCell extends TableDataVo.Style {
//        @ApiModelProperty(value = "值")
//        private String value;
//        @ApiModelProperty(value = "数值描述")
//        private String description;
//        @ApiModelProperty(value = "是否使用列的展示各式，false的话取自己本身的数据格式")
//        private boolean inheritStyle = true;
//
//    }
//
//    @EqualsAndHashCode(callSuper = true)
//    @Data
//    public interface Row<D> extends TableDataVo.Style {
//
//        @ApiModelProperty(value = "行数据信息")
//        private Map<String, D> value;
//
//    }
//
//    @EqualsAndHashCode(callSuper = true)
//    @Data
//    public interface Column extends TableDataVo.Style {
////        @ApiModelProperty(value = "列的key值")
////        private String key;
////        @ApiModelProperty(value = "列头标题")
////        private String name;
////        @ApiModelProperty(value = "描述")
////        private String description;
////        @ApiModelProperty(value = "该列是否支持排序，默认false")
////        private Boolean supportSort = false;
////        @ApiModelProperty(value = "子列头")
////        private List<TableDataVo.Column> children;
////        @ApiModelProperty(value = "锁定列")
////        private String fixed;
////        @ApiModelProperty(value = "宽度")
////        private Integer width;
////        @ApiModelProperty(value = "列可见")
////        private Boolean display;
////        @ApiModelProperty(value = "列对齐方式")
////        private String align;
//
//    }
//
//    public interface Style{
//        String getDataType();
//        void setDataType(String dataType);
//
//        String getDigit();
//        void setDigit(Integer digit);
//
//        void setStyle(Style style);
//
//        Style stringType();
//
//        Style number(int digit);
//
//        Style separateByK(int digit);
//
//        Style percentType(int digit);
//
//        Style ppType(int digit) ;
//
//        Style dateType();
//
//        Style timeType();
//
//        TableDataVo.Style abbr();
//
//    }
//
//
//    private interface SortType {
//        String DESC = "desc";
//        String ASC = "asc";
//    }


}
