package com.sankuai.tripdatecenter.databp.fenghuang.domain.ba;

import com.sankuai.tripdatecenter.databp.fenghuang.domain.auth.AuthSourceVO;
import lombok.Data;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2023/5/16 15:47
 */
@Data
public class BaAuthDimensionVO extends AuthSourceVO {
    private String dimensionId;
    private String dimensionName;
    private boolean isAuth = false;

}
