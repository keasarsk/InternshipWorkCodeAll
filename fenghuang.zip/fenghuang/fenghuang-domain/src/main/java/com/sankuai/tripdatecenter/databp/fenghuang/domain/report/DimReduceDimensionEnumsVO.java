package com.sankuai.tripdatecenter.databp.fenghuang.domain.report;

import java.io.Serializable;
import java.util.List;
import lombok.Data;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2022/4/21 5:51 下午
 */
@Data
public class DimReduceDimensionEnumsVO implements Serializable {

    //报表ID
    private Long reportId;

    //主题ID
    private Long topicId;

    //版本
    private Long version;

    //指标ID
    private String indicatorId;

    //维度ID
    private String dimensionId;

    //维度ID
    private String dimensionName;

    //维度枚举
    private List<DimensionEnumVO> dimensionEnums;

}
