package com.sankuai.tripdatecenter.databp.fenghuang.domain.report;

import java.io.Serializable;
import java.util.List;
import lombok.Data;

/**
 * description
 *
 * @author fuzhengwei02
 * @createTime 2022/10/10 02:02 下午
 */
@Data
public class DimensionEnumsVO implements Serializable {

    //维度ID
    private String dimensionId;

    //维度ID
    private String dimensionName;

    //维度枚举
    private List<DimensionEnumVO> dimensionEnums;

}
