package com.sankuai.tripdatecenter.databp.fenghuang.domain.report;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.Date;

/**
 * description 凤凰架构定制化报表配置管理VO
 *
 * @author nixuefeng
 * @createTime 2022/9/22 20:18
 */
@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class MetaReportVO {
    private String reportId;
    private String topicId;
    private Short version;
    private String reportConfig;
    private String desc;
    private String sqlReceiver;
    private String reportName;
    private String createdMis;
    private String updateMis;
    private Short isOnline;
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date createdTime;
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date updateTime;
}
