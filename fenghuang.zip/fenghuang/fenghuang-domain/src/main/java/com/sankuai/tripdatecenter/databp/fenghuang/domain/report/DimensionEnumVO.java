package com.sankuai.tripdatecenter.databp.fenghuang.domain.report;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2022/4/28 6:34 下午
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class DimensionEnumVO {
    /**
     * 枚举code
     */
    private String dimensionEnumCode;
    /**
     * 枚举名称（可修改）
     */
    private String dimensionEnumName;

    /**
     * 是否有效
     */
    private Boolean isSelected;

    /**
     * 起源名称
     */
    private String originDimensionEnumName;

    /**
     * 是否包含级联维度
     */
    private Boolean isHasRelatedDimension;

}
