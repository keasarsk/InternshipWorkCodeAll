package com.sankuai.tripdatecenter.databp.fenghuang.domain.tmpapp;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2022/4/6 8:29 下午
 */
@Data
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class IndicatorOrDimVO {
    private String id;
    private String fieldCode;
    private String showName;
    private Short fieldType;
    private String aggregateType;
    private String desc;

}
