package com.sankuai.tripdatecenter.databp.fenghuang.domain.request;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class GetUploadAppRequestParam {

    /**
     * 应用ID
     */
    private Long id;

    /**
     * 业务线ID
     */
    private String businessId;
}
