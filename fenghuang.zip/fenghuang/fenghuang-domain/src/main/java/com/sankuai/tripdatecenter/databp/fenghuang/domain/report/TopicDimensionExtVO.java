package com.sankuai.tripdatecenter.databp.fenghuang.domain.report;

import java.util.List;
import lombok.Data;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2022/4/21 5:51 下午
 */
@Data
public class TopicDimensionExtVO extends TopicDimensionVO {

    private List<DimensionEnumVO> dimensionEnums;

}
