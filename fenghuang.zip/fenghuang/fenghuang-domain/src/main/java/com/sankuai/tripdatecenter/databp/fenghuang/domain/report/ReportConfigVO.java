package com.sankuai.tripdatecenter.databp.fenghuang.domain.report;

import java.io.Serializable;
import java.util.List;
import lombok.Data;
import lombok.ToString;

/**
 * description
 *
 * @author fuzhengwei02
 * @createTime 2022年07月15日 09:53:00
 */
@Data
@ToString
public class ReportConfigVO implements Serializable {

    private ReportVO reportInfo;

    private List<TopicExtVO> topicInfos;

    private String businessId;

}
