package com.sankuai.tripdatecenter.databp.fenghuang.domain.report;

import lombok.Data;
import lombok.ToString;

import java.util.Date;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2023/2/28 17:33
 */
@Data
@ToString
public class TemplateVO {
    /**
     * 自增主键
     */
    private Long id;

    /**
     * 模板 id
     */
    private Long templateId;

    /**
     * 模板 code
     */
    private String templateCode;

    /**
     * 模板名称
     */
    private String templateName;

    private String templateType;
}
