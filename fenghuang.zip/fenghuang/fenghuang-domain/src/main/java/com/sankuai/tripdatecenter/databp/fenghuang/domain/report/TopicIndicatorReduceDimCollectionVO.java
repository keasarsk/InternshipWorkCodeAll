package com.sankuai.tripdatecenter.databp.fenghuang.domain.report;

import com.sankuai.tripdatecenter.databp.fenghuang.domain.ba.BaTopicIndicatorReduceDimEnumVO;
import lombok.Data;

import java.util.List;

@Data
public class TopicIndicatorReduceDimCollectionVO {
    /**
     * 维度id
     */
    private String dimensionId;

    /**
     * 维度name
     */
    private String dimensionName;

    /**
     * 排序
     */
    private Integer orderNum;

    /**
     * 维值枚举数据
     */
    private List<BaTopicIndicatorReduceDimEnumVO> dimEnumVOS;
}