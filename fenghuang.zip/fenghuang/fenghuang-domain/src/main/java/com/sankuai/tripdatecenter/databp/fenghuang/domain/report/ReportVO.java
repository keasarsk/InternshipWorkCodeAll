package com.sankuai.tripdatecenter.databp.fenghuang.domain.report;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.sankuai.tripdatecenter.databp.fenghuang.common.enums.OnlineStatusEnum;
import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.TimeUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.WutongUserUtils;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.sql.Time;
import java.util.Date;
import java.util.List;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2022/4/18 7:50 下午
 */
@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class ReportVO {
    private Long reportId;
    private Long version;
    private String reportName;
    private String reportDesc;
    private String createdMis;
    private String lastUpdateMis;
    private Short isOnline;
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date createdTime;
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date updateTime;
    //扩展信息
    private String extData;

    /**
     * 业务线ID
     */
    private String businessId;

    private List<String> assistAdmin;

}
