package com.sankuai.tripdatecenter.databp.fenghuang.domain.report;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.List;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2022/4/24 5:52 下午
 */
@Data
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class RelationVO {
    /**
     * 维度 id
     */
    private String dimensionId;

    /**
     * 维度枚举code
     */
    private String dimensionEnumCode;

    /**
     * 维度枚举名称
     */
    private String dimensionEnumName;

    /**
     * 指标列表
     */
    private List<IndicatorInfo> indicatonInfoList;

    public IndicatorInfo createIndicatorInfo(){
        IndicatorInfo indicatorInfo = new IndicatorInfo();
        return indicatorInfo;
    }


}
