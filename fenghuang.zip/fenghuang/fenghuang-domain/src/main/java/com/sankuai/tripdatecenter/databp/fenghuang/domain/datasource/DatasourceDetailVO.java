package com.sankuai.tripdatecenter.databp.fenghuang.domain.datasource;

import lombok.Data;

import java.util.Date;

/**
 * Created by mayuzhe on 2022/4/11
 *
 * @author mayuzhe
 */
@Data
public class DatasourceDetailVO {
    /**
     * 数据源 id
     */
    private Long datasourceId;

    /**
     * 数据源名字
     */
    private String datasourceName;

    /**
     * 数据源类型。MySQL、Doris、Kylin、ES、REF、BQ
     */
    private String datasourceType;

    /**
     * 连接地址
     */
    private String jdbcUrl;

    /**
     * 用户名
     */
    private String username;

    /**
     * psw
     */
    private String psw;

    /**
     * 驱动类
     */
    private String driverClassName;

    /**
     * 编辑人
     */
    private String createdMis;

    /**
     * 最新编辑人
     */
    private String lastUpdateMis;

    /**
     * 创建时间
     */
    private Date createdTime;

    /**
     * 最后修改时间
     */
    private Date updateTime;

    /**
     * 参数配置
     */
    private String params;
}
