package com.sankuai.tripdatecenter.databp.fenghuang.domain.ba;

import com.sankuai.tripdatecenter.databp.fenghuang.domain.auth.AuthSourceVO;
import lombok.Data;

import java.util.List;

/**
 * description
 *
 * @author nixuefeng
 * @createTime 2023/5/16 15:46
 */
@Data
public class BaAuthTopicVO extends AuthSourceVO {
    private String businessId;
    private Long topicId;
    private String topicName;
    private List<BaAuthDimensionVO> dimensions;
}
