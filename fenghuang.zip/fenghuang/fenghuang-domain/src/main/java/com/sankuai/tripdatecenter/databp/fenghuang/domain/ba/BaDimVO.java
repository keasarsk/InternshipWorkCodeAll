package com.sankuai.tripdatecenter.databp.fenghuang.domain.ba;

import com.sankuai.tripdatecenter.databp.fenghuang.domain.report.DimVO;
import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class BaDimVO extends DimVO {
}