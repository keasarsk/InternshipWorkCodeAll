package com.sankuai.tripdatecenter.databp.fenghuang.auth.annotation;

import java.lang.annotation.*;

/**
 * @author fuzhengwei02
 * @date 2023/4/18 14:28
 **/
@Documented
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@Inherited
public @interface FhAuth {

    String[] resourceCode() default "";//将军令资源code

    String checkRelation() default "AND";  //如果是多个资源CODE，校验逻辑关系


}
