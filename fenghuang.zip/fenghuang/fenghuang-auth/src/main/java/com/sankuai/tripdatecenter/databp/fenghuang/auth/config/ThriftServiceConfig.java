package com.sankuai.tripdatecenter.databp.fenghuang.auth.config;

import com.meituan.service.mobile.mtthrift.proxy.ThriftClientProxy;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import  com.sankuai.tripdatecenter.databp.fenghuang.client.config.FhAuthService;

@Configuration
public class ThriftServiceConfig {



}
