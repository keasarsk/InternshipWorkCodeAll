package com.sankuai.tripdatecenter.databp.fenghuang.auth.enums;

import org.apache.commons.lang3.StringUtils;

/**
 * description 权限校验类型
 *
 * @author nixuefeng
 * @createTime 2022/4/11 7:48 下午
 */
public enum AuthRelationEnum {
    AND("AND", "同时满足"),
    OR("OR","满足一个");

    private String code;
    private String name;

    private AuthRelationEnum(String code, String name) {
        this.code = code;
        this.name = name;
    }

    public static AuthRelationEnum getByCode(String code) {
        if(StringUtils.isNotBlank(code)){
            for (AuthRelationEnum valEnum : values()) {
                if (valEnum.getCode().equals(code)) {
                    return valEnum;
                }
            }
        }
        return null;
    }

    public String getCode() {
        return this.code;
    }

    public String getName() {
        return this.name;
    }
}
