package com.sankuai.tripdatecenter.databp.fenghuang.auth.aop;

import com.sankuai.tripdatecenter.databp.fenghuang.auth.annotation.FhAuth;
import com.sankuai.tripdatecenter.databp.fenghuang.auth.enums.AuthRelationEnum;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.FhAuthService;
import com.sankuai.tripdatecenter.databp.fenghuang.common.domain.user.FhUserInfo;
import com.sankuai.tripdatecenter.databp.fenghuang.common.enums.ResponseCodeEnum;
import com.sankuai.tripdatecenter.databp.fenghuang.common.exception.FHBaseException;
import com.sankuai.tripdatecenter.databp.fenghuang.common.exception.FhAuthException;
import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.SpringContextUtils;
import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.WutongUserUtils;
import org.aspectj.lang.annotation.Before;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.xml.ws.Response;
import java.lang.reflect.Method;

/**
 * @author jiabosen
 * @date 2022/7/5 15:06
 **/
@Aspect
@Order(100)
@Component
@Slf4j
public class AuthAspect {

    @Autowired
    private FhAuthService fhAuthService;


    @Pointcut("@annotation(com.sankuai.tripdatecenter.databp.fenghuang.auth.annotation.FhAuth)")
    public void authPointcut(){
    }

    @Before("authPointcut()")
    public void validate(JoinPoint joinPoint) throws Throwable  {
        log.info("进入权限拦截....");
        Signature signature = joinPoint.getSignature();
        Object target = joinPoint.getTarget();
        MethodSignature msg = (MethodSignature) signature;
        Method method = msg.getMethod();

        FhAuth annotation = getAnnotation(joinPoint);
        checkPermission(annotation, method, target);
    }

    private FhAuth getAnnotation(JoinPoint joinPoint){
        MethodSignature signature = (MethodSignature) joinPoint.getSignature();
        Method method = signature.getMethod();
        return method.getAnnotation(FhAuth.class);
    }

    private void checkPermission(FhAuth annotation, Method method, Object target){
        FhUserInfo fhUserInfo = WutongUserUtils.getUser2();
        String userMis = fhUserInfo.getMisId();
        String methodName = method.getName();
        String methodClass = target.getClass().getName();
        String[] resourceCodes = annotation.resourceCode();
        String checkRelation = annotation.checkRelation();
        AuthRelationEnum authRelation = AuthRelationEnum.getByCode(checkRelation);
        if(authRelation == null){
            throw new RuntimeException("不识别的权限校验逻辑类型" + checkRelation);
        }
        int counter = 0;
        for(String resourceCode : resourceCodes){
            boolean notHasPermission = fhAuthService.checkPermission(userMis, resourceCode);
            log.info("auth check result :{},{},{},{},{}", userMis, resourceCode, notHasPermission, methodClass, methodName);
            if(notHasPermission){
                switch (authRelation){
                    case AND:
                        throw new FhAuthException(ResponseCodeEnum.FORBID_REQUEST.getCode(), "无权限（" + resourceCode + ")");
                    case OR:
                        //
                        break;
                    default:
                        throw new RuntimeException("不识别的权限校验逻辑类型" + checkRelation);
                }
            }else{
                counter ++;
                break;
            }
        }
        switch (authRelation){
            case OR:
                if(counter == 0){
                    throw new FhAuthException(ResponseCodeEnum.FORBID_REQUEST.getCode(), "无权限");
                }
                break;
            default:
                throw new RuntimeException("不识别的权限校验逻辑类型" + checkRelation);
        }
        log.info("鉴权通过: {}, {}, {}", methodClass, methodName, userMis);
    }


}
