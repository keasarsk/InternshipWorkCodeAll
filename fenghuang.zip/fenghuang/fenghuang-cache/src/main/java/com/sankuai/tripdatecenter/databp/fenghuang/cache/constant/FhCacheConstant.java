package com.sankuai.tripdatecenter.databp.fenghuang.cache.constant;

/**
 * description 凤凰缓存常量信息
 *
 * @author fuzhengwei02
 * @createTime 2023/6/18 7:33 上午
 */
public class FhCacheConstant {

    public static final String CACHE_GROUP_KEY = "cache_group_key";

    public static final String CACHE_KEY = "cache_key";

    public static final String CACHE_SERIALIZE_TYPE = "cache_serialize_type";

}
