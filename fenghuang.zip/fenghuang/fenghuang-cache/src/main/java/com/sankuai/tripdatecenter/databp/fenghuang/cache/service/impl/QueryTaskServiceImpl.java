package com.sankuai.tripdatecenter.databp.fenghuang.cache.service.impl;

import com.google.common.collect.Maps;
import com.sankuai.tripdatecenter.databp.fenghuang.cache.constant.FhCacheConstant;
import com.sankuai.tripdatecenter.databp.fenghuang.cache.service.CacheOperateService;
import com.sankuai.tripdatecenter.databp.fenghuang.cache.service.QueryTaskService;
import com.sankuai.tripdatecenter.databp.fenghuang.cache.vo.QueryTaskInfo;
import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.MD5Util;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.nio.charset.StandardCharsets;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
import java.util.UUID;

@Service
public class QueryTaskServiceImpl implements QueryTaskService {

    @Autowired
    private CacheOperateService cacheOperateService;

    private static final String TASK_PREFIX = "qt_";

    private static final String FIELD_CREATE_TIME = "create_time";

    private static final String FIELD_STATUS = "status";

    private static final String FIELD_SERIALIZE_TYPE = "cache_serialize_type";

    private static final String FIELD_CACHE_GROUP_TYPE = "cache_group_key";

    private static final String FIELD_CACHE_KEY = "cache_key";

    private static final String DATE_FORMAT = "yyyyMMddHHmmss";

    private static final int CELLAR_TIMEOUT = 1000 * 6;

    private static final int CACHE_EMPIRE_TIME = 24 * 60 * 60;

    private static final String FIELD_STATUS_SUCCESS = "1";

    private static final String FIELD_STATUS_WAIT = "0";

    private static final String FIELD_STATUS_FAIL = "-1";

    @Override
    public QueryTaskInfo getQueryTaskInfo(String queryTaskId) {
        Map<String, byte[]> cacheValues = cacheOperateService.getCacheValuesByGroupKey(queryTaskId, CELLAR_TIMEOUT);
        if(cacheValues == null){
            return null;
        }
        byte[] createTimeValue = cacheValues.get(FIELD_CREATE_TIME);
        byte[] statusValue = cacheValues.get(FIELD_STATUS);
        byte[] serializeTypeValue = cacheValues.get(FIELD_SERIALIZE_TYPE);
        byte[] cacheGroupKeyValue = cacheValues.get(FIELD_CACHE_GROUP_TYPE);
        byte[] cacheKeyValue = cacheValues.get(FIELD_CACHE_KEY);
        QueryTaskInfo queryTaskInfo = new QueryTaskInfo();
        queryTaskInfo.setQueryTaskId(queryTaskId);
        if(createTimeValue != null){
            queryTaskInfo.setCreateTime(new String(createTimeValue, StandardCharsets.UTF_8));
        }
        if(statusValue != null){
            queryTaskInfo.setStatus(new String(statusValue, StandardCharsets.UTF_8));
        }
        if(serializeTypeValue != null){
            queryTaskInfo.setSerializeType(new String(serializeTypeValue, StandardCharsets.UTF_8));
        }
        if(cacheGroupKeyValue != null){
            queryTaskInfo.setCacheGroupKey(new String(cacheGroupKeyValue, StandardCharsets.UTF_8));
        }
        if(cacheKeyValue != null){
            queryTaskInfo.setCacheKey(new String(cacheKeyValue, StandardCharsets.UTF_8));
        }
        if(createTimeValue != null){
            return queryTaskInfo;
        }else{
            return null;
        }
    }

    @Override
    public void updateQueryTaskStatus(String queryTaskId, boolean success, String message) {
        byte[] newStatus = success ? FIELD_STATUS_SUCCESS.getBytes(StandardCharsets.UTF_8) : FIELD_STATUS_FAIL.getBytes(StandardCharsets.UTF_8);
        cacheOperateService.setCache(queryTaskId, FIELD_STATUS, newStatus , CACHE_EMPIRE_TIME, CELLAR_TIMEOUT);
    }

    @Override
    public void updateQueryTaskCacheInfo(String queryTaskId, String cacheGroupKey, String cacheKey, String serializeType) {
        Map<String, byte[]> mapValues = Maps.newHashMap();
        if(cacheGroupKey != null){
            mapValues.put(FhCacheConstant.CACHE_GROUP_KEY, cacheGroupKey.getBytes(StandardCharsets.UTF_8));
        }
        if(cacheKey == null){
            throw new RuntimeException("cacheKey is null");
        }
        if(serializeType == null){
            throw new RuntimeException("serializeType is null");
        }
        mapValues.put(FhCacheConstant.CACHE_KEY, cacheKey.getBytes(StandardCharsets.UTF_8));
        mapValues.put(FhCacheConstant.CACHE_SERIALIZE_TYPE, serializeType.getBytes(StandardCharsets.UTF_8));
        cacheOperateService.setCache4MapValues(queryTaskId, mapValues, CACHE_EMPIRE_TIME, CELLAR_TIMEOUT);
    }

    @Override
    public QueryTaskInfo createQueryTask() {
        String queryTaskId = generateTaskId();
        String nowTime = generateNowStr();
        Map<String, byte[]> mapValues = Maps.newHashMap();
        mapValues.put(FIELD_STATUS, FIELD_STATUS_WAIT.getBytes(StandardCharsets.UTF_8));
        mapValues.put(FIELD_CREATE_TIME, nowTime.getBytes(StandardCharsets.UTF_8));
        cacheOperateService.setCache4MapValues(queryTaskId, mapValues, CACHE_EMPIRE_TIME, CELLAR_TIMEOUT);
        QueryTaskInfo queryTaskInfo = new QueryTaskInfo();
        queryTaskInfo.setQueryTaskId(queryTaskId);
        queryTaskInfo.setStatus(FIELD_STATUS_WAIT);
        queryTaskInfo.setQueryTaskId(queryTaskId);
        queryTaskInfo.setCreateTime(nowTime);
        return queryTaskInfo;
    }

    @Override
    public Long getQueryTaskDuration(String queryTaskId) {
        QueryTaskInfo queryTaskInfo = getQueryTaskInfo(queryTaskId);
        if(queryTaskInfo != null && queryTaskInfo.getCreateTime() != null){
            Long createTime = Long.parseLong(queryTaskInfo.getCreateTime());
            if(createTime != null){
                String nowStr = generateNowStr();
                Long nowTime = Long.parseLong(nowStr);
                return nowTime - createTime;
            }
        }
        return null;
    }

    private String generateTaskId(){
        String forceQueryTaskId = MD5Util.encode(UUID.randomUUID().toString());
        return TASK_PREFIX + forceQueryTaskId;
    }

    private String generateNowStr(){
        DateFormat dateFormat = new SimpleDateFormat(DATE_FORMAT);
        return dateFormat.format(new Date());
    }

}
