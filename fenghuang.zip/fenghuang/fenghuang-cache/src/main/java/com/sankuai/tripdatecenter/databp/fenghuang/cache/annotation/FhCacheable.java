package com.sankuai.tripdatecenter.databp.fenghuang.cache.annotation;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.util.concurrent.TimeUnit;

/**
 * @author fuzhengwei02
 * @date 2022/7/5 14:28
 **/
@Documented
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@Inherited
public @interface FhCacheable {
    boolean USE() default true; //是否开启缓存功能（key为空也认为不开启缓存）
    String KEY(); //缓存key值 输入支持EL表达式，应传入序列化后的logicQuery
    int CACHE_DURATION() default 60;  //默认缓存有效期
    int LOCK_DURATION() default 40;   //默认分布式锁有效期
    long OPERATRE_TIMEOUT() default 6000; //默认请求超时时间（毫秒）
    TimeUnit TIME_UNIT() default TimeUnit.MINUTES;  //时间单位（只针对缓存和分布式锁）
    String REFRESH_KEY() default "";//缓存刷新参数名称，用于判断是否需要刷新缓存。支持EL表达式
    String CACHE_DURATION_KEY() default "";  //缓存有效时间参数名称，用于动态更新缓存有效时间。支持EL表达式
    String CATEGORY() default "default"; // 缓存所属类别。用于 lion 中获取某一类缓存配置的唯一标识。
    String VALUE_SERIALIZE_TYPE() default "JSON"; //缓存序列化类型。目前支持 JSON , KRYO 两种类型
    String ASYNC_EXEC() default "0"; //是否异步执行。默认是0, 同步执行
    String MESSAGE_BEAN() default ""; //消息推送bean
    String MESSAGE_RECEIVER() default ""; //消息接收人
    String MESSAGE_SUCCESS() default ""; //成功消息
    String MESSAGE_FAILED() default ""; //失败消息
    String GROUP_KEY() default ""; //缓存分类
    String QUERY_TASK_ID() default ""; //查询任务ID

}
