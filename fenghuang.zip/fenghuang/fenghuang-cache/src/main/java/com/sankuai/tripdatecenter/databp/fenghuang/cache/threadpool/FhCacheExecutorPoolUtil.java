package com.sankuai.tripdatecenter.databp.fenghuang.cache.threadpool;

import com.dianping.rhino.Rhino;
import com.dianping.rhino.threadpool.DefaultThreadPoolProperties;
import com.dianping.rhino.threadpool.ThreadPool;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import lombok.extern.slf4j.Slf4j;

/**
 * @author fuzhengwei02
 * @version 1.0
 * @descrition
 */
@Slf4j
public class FhCacheExecutorPoolUtil {

    static int corePoolSize = 10;
    static int maximumPoolSize = 10;
    static int keepAliveTime = 10;
    static int blockingQueueCount = 100;

    public static ThreadPool CACHE_PUT_THREAD_POOL = Rhino.newThreadPool("FenghuangCachePutThreadPool",
            DefaultThreadPoolProperties.Setter().withCoreSize(corePoolSize).withMaxSize(maximumPoolSize)
                    .withKeepAliveTimeMinutes(keepAliveTime).withKeepAliveTimeUnit(TimeUnit.MINUTES)
                    .withBlockingQueue(new LinkedBlockingQueue<>(blockingQueueCount))
                    .withRejectHandler(new ThreadPoolExecutor.CallerRunsPolicy()));

}
