package com.sankuai.tripdatecenter.databp.fenghuang.cache.service;

public interface BeanGetter {

    <T> T getBean(String beanName);
}
