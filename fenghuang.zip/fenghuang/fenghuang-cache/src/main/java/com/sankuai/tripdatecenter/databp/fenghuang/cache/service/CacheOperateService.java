package com.sankuai.tripdatecenter.databp.fenghuang.cache.service;

import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * @author jiabosen
 * @date 2022/6/30 17:32
 **/
public interface CacheOperateService {
    /**
     * cacheDuration : 缓存有效期（秒）
     * lockDuration : 分布式锁有效期（秒）
     * retryDuration : 请求超时时间（毫秒）
     * timeUnit : 时间单位
     **/
    // 设置缓存
    boolean setCache(String groupKey, String key, byte[] value, int cacheDuration, long operateTimeout);

    // 设置缓存
    boolean setCache4MapValues(String groupKey, Map<String, byte[]> keyValues, int cacheDuration, long operateTimeout);

    // 获取缓存
    byte[] getCache(String groupKey, String key, long operateTimeout);

    // 检查缓存是否存在
    boolean checkCacheByKey(String groupKey, String key, long operateTimeout);

    // 尝试获取锁
    boolean tryLock(String groupKey, String key, long operateTimeout, int lockDuration);

    // 释放锁
    void unLock(String groupKey, String key, long operateTimeout);

    /**
     * 等待缓存结果
     *
     * @param key           缓存 key
     * @param timeout       等待超时时间，单位为秒
     * @param operateTimeout tair 获取时间
     * @param timeUnit      tair 获取时间 时间单位
     * @return
     */
    byte[] waitingCache(String groupKey, String key, int timeout, long operateTimeout, TimeUnit timeUnit);

    /**
     * 删除缓存, map结构，根据一级key删除全部。
     * @param groupKey
     * @param operateTimeout
     * @return
     */
    boolean deleteCacheByGroupKey(String groupKey, long operateTimeout);

    /**
     * 查询一级缓存key下的所有缓存值
     * @param groupKey
     * @param operateTimeout
     * @return
     */
    Map<String, byte[]> getCacheValuesByGroupKey(String groupKey, long operateTimeout);

}
