package com.sankuai.tripdatecenter.databp.fenghuang.cache.vo;

import lombok.Data;

import java.io.Serializable;

@Data
public class QueryTaskInfo implements Serializable {

    private String queryTaskId;

    private String status;

    private String createTime;

    private String message;

    private String cacheGroupKey;

    private String cacheKey;

    private String serializeType;

}
