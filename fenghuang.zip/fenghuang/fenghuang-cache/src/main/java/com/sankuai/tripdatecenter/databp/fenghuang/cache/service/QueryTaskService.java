package com.sankuai.tripdatecenter.databp.fenghuang.cache.service;


import com.sankuai.tripdatecenter.databp.fenghuang.cache.vo.QueryTaskInfo;

/**
 * description 查询任务服务
 *
 * @author fuzhengwei02
 * @createTime 2022年04月28日 14:11:00
 */
public interface QueryTaskService {

    QueryTaskInfo getQueryTaskInfo(String queryTaskId);

    void updateQueryTaskStatus(String queryTaskId, boolean success, String message);

    void updateQueryTaskCacheInfo(String queryTaskId, String cacheGroupKey, String cacheKey, String serializeTypeEnum);

    QueryTaskInfo createQueryTask();

    Long getQueryTaskDuration(String queryTaskId);



}
