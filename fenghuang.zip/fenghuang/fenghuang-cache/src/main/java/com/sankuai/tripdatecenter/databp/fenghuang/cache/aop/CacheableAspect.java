package com.sankuai.tripdatecenter.databp.fenghuang.cache.aop;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.dianping.lion.client.ConfigRepository;
import com.dianping.lion.client.Lion;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.meituan.mtrace.Tracer;
import com.sankuai.tripdatecenter.databp.fenghuang.cache.annotation.FhCacheable;
import com.sankuai.tripdatecenter.databp.fenghuang.cache.service.QueryTaskService;
import com.sankuai.tripdatecenter.databp.fenghuang.cache.vo.CacheConfigBean;
import com.sankuai.tripdatecenter.databp.fenghuang.cache.service.CacheOperateService;
import com.sankuai.tripdatecenter.databp.fenghuang.cache.threadpool.FhCacheExecutorPoolUtil;
import com.sankuai.tripdatecenter.databp.fenghuang.client.config.request.SendTextMessageRequest;
import com.sankuai.tripdatecenter.databp.fenghuang.client.push.FhMessagePushService;
import com.sankuai.tripdatecenter.databp.fenghuang.common.domain.result.DataResult;
import com.sankuai.tripdatecenter.databp.fenghuang.common.domain.result.thrift.BooleanDataResult;
import com.sankuai.tripdatecenter.databp.fenghuang.common.domain.user.FhUserInfo;
import com.sankuai.tripdatecenter.databp.fenghuang.common.enums.SerializeTypeEnum;
import com.sankuai.tripdatecenter.databp.fenghuang.common.enums.YnEnum;
import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.*;

import java.lang.reflect.Method;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.TimeUnit;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.LocalVariableTableParameterNameDiscoverer;
import org.springframework.expression.ExpressionParser;
import org.springframework.expression.spel.standard.SpelExpressionParser;
import org.springframework.expression.spel.support.StandardEvaluationContext;
import org.springframework.stereotype.Component;
import com.sankuai.tripdatecenter.databp.fenghuang.cache.constant.FhCacheConstant;

import javax.annotation.PostConstruct;


/**
 * @author jiabosen
 * @date 2022/7/5 15:06
 **/
@Aspect
@Component
@Slf4j
public class CacheableAspect {

    @Autowired
    CacheOperateService cacheOperateService;

    @Autowired
    QueryTaskService queryTaskService;

    private static final String APPKEY = "com.sankuai.tripdatecenter.fenghuang";

    private static final String DISABLE_FENGHUANG_CACHE = "disable_fenghuang_cache";

    private static final String FORCE_RESET_CACHE = "fh.cache.force_reset_cache";

    private static final String TEMP_DISABLE_CACHE = "fh.cache.temp_disable_cache";

    // fenghuang-cache 配置 lion key
    private static final String CACHE_CONF_LION_KEY = "fenghuang_cache_config";

    private static final String Y_TAG = String.valueOf(YnEnum.Y.getCode());

    private List<String> globalUserBlackList;

    private CacheConfigBean localCacheConfig;

    private int CACHE_OPERATE_TIMEOUT = 10 * 1000;

    private int QUERY_TASK_CACHE_EXPIRE_TIME = 24 * 60 * 60;


    @Pointcut("@annotation(com.sankuai.tripdatecenter.databp.fenghuang.cache.annotation.FhCacheable)")
    public void cachePointcut(){
    }

    private FhCacheable getFhCacheable(JoinPoint joinPoint){
        MethodSignature signature = (MethodSignature) joinPoint.getSignature();
        Method method = signature.getMethod();
        return method.getAnnotation(FhCacheable.class);
    }

    /**
     * 根据EL表达式获取是否强制刷新缓存功能
     *
     * @param key
     * @param paramMap
     * @return
     */
    private boolean getRefreshStatus(String key, Map<String, Object> paramMap) {
        if ("".equals(key)) {
            /**
             * 未设置强制刷新功能
             */
            return false;
        }
        Boolean refreshStatus = parserEL(key, paramMap, Boolean.class);
        if (refreshStatus == null) {
            refreshStatus = false;
        }
        return refreshStatus;
    }

    /**
     * 获取运行时参数Map
     *
     * @param args
     * @param method
     * @return
     */
    private Map<String, Object> getParamMap(Object[] args, Method method) {
        Map<String, Object> paramNameValueMap = new TreeMap<>();
        LocalVariableTableParameterNameDiscoverer nameDiscoverer = new LocalVariableTableParameterNameDiscoverer();
        String[] paraNameArr = nameDiscoverer.getParameterNames(method);
        for (int i = 0; i < paraNameArr.length; i++) {
            paramNameValueMap.put(paraNameArr[i], args[i]);
        }
        return paramNameValueMap;
    }
    /**
     * 解析EL表达式
     *
     * @param key
     * @param paramNameValueMap
     * @return
     */
    private <T> T parserEL(String key, Map<String, Object> paramNameValueMap, Class<T> type) {

        // 初始化SPEL上下文（把方法参数放入SPEL上下文中）
        StandardEvaluationContext context = new StandardEvaluationContext();
        context.setVariables(paramNameValueMap);
        // 使用SPEL进行key的解析
        ExpressionParser parser = new SpelExpressionParser();
        try {
            T keyParam = parser.parseExpression(key).getValue(context, type);
            log.info("cache parserEL key {} value is : {}", key, keyParam.toString());
            return keyParam;
        } catch (Exception e) {
            log.info("cache parserEL key {} error:", key, JsonUtils.toJson(e));
            return null;
        }
    }

    public String getKey(JoinPoint joinPoint){
        FhCacheable handler = getFhCacheable(joinPoint);
        if(joinPoint.getArgs() == null) return null;
        log.info("handler.KEY():{}" , handler.KEY());
        String[] index = handler.KEY().split(",");
        Object[] objects = joinPoint.getArgs();
        String className = joinPoint.getTarget().getClass().getName();
        String methodName = ((MethodSignature) joinPoint.getSignature()).getMethod().getName();
        String rawKey = className + "_" + methodName + "_" + appendStr(index, objects);
        log.info("raw key:{}",rawKey);
        String cacheKey = MD5Util.encode(rawKey);
        log.info("get Key:{}", cacheKey);
        return cacheKey;
    }

    public String appendStr(String[] index, Object[] objects){
        StringBuilder stringBuffer = new StringBuilder();
        for(String i : index){
            stringBuffer.append(JsonUtils.toJson(objects[Integer.parseInt(i)], SerializerFeature.DisableCircularReferenceDetect));
        }
        return stringBuffer.toString();
    }

    @PostConstruct
    private void init(){
        this.initFenghuangLionGlobalConfig();
        this.initLocalLionConfig();
    }

    // 凤凰 lion 注册
    private void initFenghuangLionGlobalConfig() {
        // 凤凰 lion
        ConfigRepository fenghuangGlobalLionConfig = Lion.getConfigRepository(APPKEY);
        String disableMisList = fenghuangGlobalLionConfig.get(DISABLE_FENGHUANG_CACHE);
        log.info("disableFHCache disableMisList :{}", disableMisList);
        refreshUserWhitelist(disableMisList);
        fenghuangGlobalLionConfig.addConfigListener(DISABLE_FENGHUANG_CACHE, configEvent -> {
            //refresh blackList status
            String configValue = configEvent.getValue();
            log.info("receive disable fenghuang cache misIds change:{}", configValue);
            refreshUserWhitelist(configValue);
        });
    }

    private void refreshUserWhitelist(String disableFHCache){
        if(StringUtils.isBlank(disableFHCache)){
            globalUserBlackList = Lists.newArrayList();
        }
        else{
            String[] misIds = disableFHCache.split(",");
            globalUserBlackList = Lists.newArrayList(misIds);
        }
    }

    private void initLocalLionConfig() {
        // 应用 lion
        ConfigRepository localLionConfig = Lion.getConfigRepository(AppKey.get());
        String cacheConfLionValue = localLionConfig.get(CACHE_CONF_LION_KEY);
        log.info("cacheConfLionValue:{}", cacheConfLionValue);
        this.refreshCacheConfigBean(cacheConfLionValue);
        localLionConfig.addConfigListener(CACHE_CONF_LION_KEY, configEvent -> {
            String newCacheConfLionValue = configEvent.getValue();
            log.info("receive cacheConfLionValue change:{}", newCacheConfLionValue);
            this.refreshCacheConfigBean(newCacheConfLionValue);
        });
    }

    private void refreshCacheConfigBean(String cacheConfLionValue){
        if(StringUtils.isBlank(cacheConfLionValue)){
            localCacheConfig = new CacheConfigBean();
        } else{
            localCacheConfig = JSON.parseObject(cacheConfLionValue, CacheConfigBean.class);
        }
    }

    // 用户不在黑名单内，但需要临时关闭缓存功能
    private boolean tempDisableCache(){
        String tempDisableCache = null;
        if(Tracer.getAllContext() != null && Tracer.getAllContext().get(TEMP_DISABLE_CACHE) != null){
            tempDisableCache = Tracer.getAllContext().get(TEMP_DISABLE_CACHE);
        };
        return StringUtils.isNotBlank(tempDisableCache) && Y_TAG.equals(tempDisableCache);
    }

    private String getQueryTaskId(FhCacheable annotation, Map<String, Object> paramMap){
        String rawValue = annotation.QUERY_TASK_ID();
        String queryTaskId = parserEL(rawValue, paramMap, String.class);

        if(StringUtils.isNotBlank(queryTaskId)){
            return queryTaskId.trim();
        }else{
            return null;
        }
    }

    private boolean forceResetCache(){
        String forceResetCache = null;
        if( Tracer.getAllContext() != null && Tracer.getAllContext().get(FORCE_RESET_CACHE) != null){
            forceResetCache = Tracer.getAllContext().get(FORCE_RESET_CACHE);
        }
        return StringUtils.isNotBlank(forceResetCache) && Y_TAG.equals(forceResetCache);
    }

    private boolean inBlackList(){
        FhUserInfo userInfo = WutongUserUtils.getFhUserInfo();
        return userInfo == null || StringUtils.isBlank(userInfo.getMisId()) || globalUserBlackList.contains(userInfo.getMisId());
    }

    private boolean checkAsync(FhCacheable annotation, Map<String, Object> paramMap){
        String asyncRawStr = annotation.ASYNC_EXEC();
        Boolean async = parserEL(asyncRawStr, paramMap, Boolean.class);
        if(async != null && async){
            return true;
        }
        return false;
    }

    private String parseCacheGroup(FhCacheable annotation, Map<String, Object> paramMap){
        String cacheGroupStr = annotation.GROUP_KEY();
        String cacheGroup = parserEL(cacheGroupStr, paramMap, String.class);
        if(StringUtils.isNotBlank(cacheGroup)){
            return cacheGroup.trim();
        }
        return null;
    }

    private String parseMessageSuccess(FhCacheable annotation, Map<String, Object> paramMap){
        String messageSuccessRawStr = annotation.MESSAGE_SUCCESS();
        String messageSuccess = parserEL(messageSuccessRawStr, paramMap, String.class);
        return messageSuccess;
    }

    private String parseMessageFailed(FhCacheable annotation, Map<String, Object> paramMap){
        String messageFailedRawStr = annotation.MESSAGE_FAILED();
        String messageFailed = parserEL(messageFailedRawStr, paramMap, String.class);
        return messageFailed;
    }

    private void pushMessage(FhCacheable annotation, String message, String defaultMessage, Map<String, Object> paramMap){
        try {
            String messageBeanRawStr = annotation.MESSAGE_BEAN();
            String messageBean = parserEL(messageBeanRawStr, paramMap, String.class);
            String messageReceiverRawStr = annotation.MESSAGE_RECEIVER();
            String messageReceiver = parserEL(messageReceiverRawStr, paramMap, String.class);
            FhMessagePushService messagePushService = null;
            if(StringUtils.isNotBlank(messageBean)){
                messagePushService = SpringContextUtils.getBeanById(messageBean);
            }
            if(messagePushService != null && StringUtils.isNotBlank(messageReceiver)){
                SendTextMessageRequest sendTextMessageRequest = new SendTextMessageRequest();
                sendTextMessageRequest.setMisIds(Lists.newArrayList(messageReceiver.split(",")));
                String fullMessage = StringUtils.isNotBlank(message) ? ( message + "(" + defaultMessage + ")" ) : defaultMessage;
                sendTextMessageRequest.setMessageContent(fullMessage);
                log.info("send message :{}", JsonUtils.toJson(sendTextMessageRequest));
                BooleanDataResult messageResult = messagePushService.sendTextMessage(sendTextMessageRequest);
                log.info("send message result:{}", JsonUtils.toJson(messageResult));
            }
        } catch (Exception e){
            log.error("消息推送失败"+ e.getMessage(), e);
        }
    }

    /**
     * @description key为序列化后的logicQuery，value为被序列化的DataQueryResult
     * 序列化操作serialize是在LogicQuery和DataQueryResult类中定义的，反序列化操作deserialize是在工具类中定义
     **/
    @Around("cachePointcut()")
    public Object around(ProceedingJoinPoint joinPoint) throws Throwable {
        log.info("进入缓存拦截....");
        Signature signature = joinPoint.getSignature();
        MethodSignature msg = (MethodSignature) signature;
        Method method = joinPoint.getTarget().getClass().getMethod(msg.getName(),msg.getParameterTypes());
        FhCacheable annotation = getFhCacheable(joinPoint);
        Class<?> returnClass = method.getReturnType();
        Type returnType = method.getGenericReturnType();
        Object[] args = joinPoint.getArgs();
        Map<String, Object> paramMap = getParamMap(args, method);
        final String key = getKey(joinPoint);
        final String groupKey = parseCacheGroup(annotation, paramMap);
        final boolean isRefresh = getRefreshStatus(annotation.REFRESH_KEY(), paramMap);
        boolean isAsync = checkAsync(annotation, paramMap);
        final boolean status = annotation.USE();
        final boolean masterSwitch = this.localCacheConfig.isMasterSwitch();
        CacheConfigBean.CacheConfigDetail cacheConfigDetail = this.localCacheConfig.getConfigDetail() == null ? null : this.localCacheConfig.getConfigDetail().get(annotation.CATEGORY());
        final boolean localSwitch = cacheConfigDetail == null || cacheConfigDetail.isLocalSwitch();

        final long operateTimeout = annotation.OPERATRE_TIMEOUT();
        final TimeUnit timeUnit = annotation.TIME_UNIT();
        String valueSerializeTypeStr = annotation.VALUE_SERIALIZE_TYPE();
        SerializeTypeEnum serializeTypeEnum = parseSerializeType(valueSerializeTypeStr);


        boolean inBlackList = inBlackList();
        boolean tempDisableCache = tempDisableCache();
        // 不管是否存在于黑名单，用户需要强制刷新缓存内容（查询并将缓存内容更新）
        /**
         * 1.不管是否存在于黑名单，用户需要强制刷新缓存内容（查询并将缓存内容更新）
         * 2.上游传入强制刷新缓存参数
         */
        boolean forceResetCache = forceResetCache();
        log.info("属性检查:forceResetCache:{} ,tempDisableCache:{}, inBlackList:{}, status:{}, key:{}, masterSwitch:{}, localSwitch:{}", forceResetCache, tempDisableCache, inBlackList, status, key, masterSwitch, localSwitch);
        log.info("isAsync:{}", isAsync);

        String queryTaskId = getQueryTaskId(annotation, paramMap);
        if(forceResetCache || isRefresh){
            //必须派生自DataResult
            if(isAsync && returnClass.isAssignableFrom(DataResult.class)){
                String taskId = UUID.randomUUID().toString();
                log.info("异步执行缓存刷新工作:{},{}", isAsync, taskId);
                //投入异步线程池执行
                ExecutorPoolUtil.FENGHUANG_CACHE_THREAD_POOL.execute(() -> {
                    try {
                        log.info("异步刷新缓存任务开始,taskId:{}", taskId);
                        Object value = joinPoint.proceed();
                        putValue2Cache(annotation, groupKey, key, value, paramMap);
                        if(StringUtils.isNotBlank(queryTaskId)){
                            queryTaskService.updateQueryTaskCacheInfo(queryTaskId, groupKey, key, serializeTypeEnum.getCode());
                        }
                        log.info("异步刷新缓存任务结束,taskId:{}", taskId);
                        String message = parseMessageSuccess(annotation, paramMap);
                        pushMessage(annotation,  message, "刷新缓存任务执行成功,taskId:" + taskId, paramMap);
                    } catch (Throwable e){
                        log.error("异步刷新缓存任务失败，任务ID:" + taskId + ",e:" + e.getMessage(), e);
                        String message = parseMessageFailed(annotation, paramMap);
                        pushMessage(annotation,  message,"刷新缓存任务执行失败,任务id:" + taskId + ",e:" + e.getMessage(), paramMap);
                    }
                });
                //1.构造假结果，必须FhMaybe子类
                DataResult emptyResult = DataResult.success();
                emptyResult.setCache(false);
                emptyResult.setEmptyByAsync(true);
                emptyResult.setQueryTaskId(taskId);
                return emptyResult;
            }else{
                // 执行下层逻辑并返回物理查询结果，并异步加入缓存
                Object value = joinPoint.proceed();
                putValue2Cache(annotation, groupKey, key, value, paramMap);
                return value;
            }
        }
        // 四种情况不会走缓存：
        // 1、用户不在黑名单，但临时关闭缓存；
        // 2、用户在黑名单中；
        // 3、注解中设置缓存关闭；
        // 4、key值为空；
        // 5、应用缓存总开关为关闭；masterSwitch == false
        // 6、应用缓存总开关为打开，但是自己类别的开关为关闭；masterSwitch == true && localSwitch == false

        if(tempDisableCache || inBlackList || !status || key.equals("") || !masterSwitch || !localSwitch){
            log.info("未开启缓存功能:tempDisableCache:{}, inBlackList:{}, status:{}, key:{}, masterSwitch:{}, localSwitch:{}", tempDisableCache,  inBlackList, status, key, masterSwitch, localSwitch);
            Object value = joinPoint.proceed();
            if(queryTaskId != null){
                //异步写缓存
                putValue2Cache(annotation, groupKey, key, value, paramMap);
                if(StringUtils.isNotBlank(queryTaskId)){
                    queryTaskService.updateQueryTaskCacheInfo(queryTaskId, groupKey, key, serializeTypeEnum.getCode());
                }
            }
            return value;
        }
        log.info("{} 进入缓存处理", method);

        //缓存检查
        byte[] valueRaw = cacheOperateService.getCache(groupKey, key, operateTimeout);
        if(valueRaw != null){
            log.info("初始检验，获取缓存成功");
            switch (serializeTypeEnum){
                case JSON:
                    return getCache4Json(valueRaw, returnType, returnClass);
                case KRYO:
                    return getCache4Kryo(valueRaw);
                default:
                    throw new RuntimeException("unsupported serializeTypeEnum:" + serializeTypeEnum);
            }
        } else {
            Object value = null;
            // 锁过期时间单位 s
            int expireTime = 60;
            boolean hasLock = cacheOperateService.tryLock(groupKey, key, operateTimeout, expireTime);
            if(hasLock){
                //拿到锁，则进行查询
                // 执行下层逻辑并返回物理查询结果，并加入缓存
                try {
                    value = joinPoint.proceed();
                    //异步写缓存
                    putValue2Cache(annotation, groupKey, key, value, paramMap);
                } catch (Exception e) {
                    log.error("写入缓存执行失败:", e);
                    // 写入异常状态。异常状态标记 10 秒
                    putValue2Cache(groupKey, "exception_" + key, "true".getBytes(StandardCharsets.UTF_8), 10, operateTimeout, serializeTypeEnum);
                } finally {
                    // 释放锁
                    cacheOperateService.unLock(groupKey, key, operateTimeout);
                }
                return value;
            } else {
               //没有拿到锁，等待主线程查询成功。等待时间 20 秒 try
                byte[] valueRawGet = cacheOperateService.waitingCache(groupKey, key, 20, operateTimeout, timeUnit);
                switch (serializeTypeEnum){
                    case JSON:
                        return getCache4Json(valueRawGet, returnType, returnClass);
                    case KRYO:
                        return getCache4Kryo(valueRawGet);
                    default:
                        throw new RuntimeException("unsupported serializeTypeEnum:" + serializeTypeEnum);
                }
            }
        }
    }



    private Object getCache4Json(byte[] valueRaw, Type returnType, Class<?> returnClass){
        String valueStr = new String(valueRaw);
        log.info("returnType:{}, returnClass:{}",  returnType, returnClass);
        if(returnClass.equals(List.class)){
            ParameterizedType pType = (ParameterizedType) returnType;
            String typeName =  pType.getActualTypeArguments()[0].getTypeName();
            log.info("ParameterizedType :{}, name:{}, ", pType, typeName);
            try {
                return JacksonJsonUtils.string2List(valueStr, Class.forName(typeName));
            } catch (ClassNotFoundException e) {
                throw new RuntimeException(e);
            }
        }else{
            return JacksonJsonUtils.string2Class(valueStr, returnClass);
        }
    }

    private Object getCache4Kryo(byte[] valueRaw){
        log.info("getCache4Kryo");
        return KryoSerializer.deserialize(valueRaw);
    }

    private SerializeTypeEnum parseSerializeType(String valueSerializeTypeStr){
        SerializeTypeEnum serializeTypeEnum = SerializeTypeEnum.getByCode(valueSerializeTypeStr);
        if(serializeTypeEnum == null){
            serializeTypeEnum = SerializeTypeEnum.JSON;
        }
        return serializeTypeEnum;
    }

    private void putValue2Cache(FhCacheable annotation, String groupKey, String key, Object value, Map<String, Object> paramMap){
        log.info("提交写缓存任务, annotation:{}, key:{}, paramMap:{}", annotation, key, paramMap);
        //提交异步写缓存任务
        FhCacheExecutorPoolUtil.CACHE_PUT_THREAD_POOL.submit(
                () -> writeCache( annotation, groupKey, key, value, paramMap)
        );
    }

    private void putValue2Cache(String groupKey, String key, Object value, int cacheDuration, long operateTimeout, SerializeTypeEnum serializeType){
        //提交异步写缓存任务
        FhCacheExecutorPoolUtil.CACHE_PUT_THREAD_POOL.submit(
                () -> writeCache(groupKey, key, value, cacheDuration, operateTimeout, serializeType)
        );
    }

    private void putValue2Cache4MapValues(String groupKey, Map<String, Object> keyValues, int cacheDuration, long operateTimeout, SerializeTypeEnum serializeType){
        //提交异步写缓存任务
        FhCacheExecutorPoolUtil.CACHE_PUT_THREAD_POOL.submit(
                () -> writeCache4MapValues(groupKey, keyValues, cacheDuration, operateTimeout, serializeType)
        );
    }

    private void writeCache(FhCacheable annotation, String groupKey, String key, Object value, Map<String, Object> paramMap){
        if(value == null){
            log.info("value 为 null");
            return ;
        }
        int cacheDuration = getAutoCacheDuration(annotation, paramMap);
        long operateTimeout = annotation.OPERATRE_TIMEOUT();
        SerializeTypeEnum serializeType = parseSerializeType(annotation.VALUE_SERIALIZE_TYPE());
        this.writeCache(groupKey, key, value, cacheDuration, operateTimeout, serializeType);
    }

    private void writeCache(String groupKey, String key, Object value, int cacheDuration, long operateTimeout, SerializeTypeEnum serializeType){
        if(value == null){
            log.info("value 为 null");
            return;
        }
        /**
         * 写入缓存时，关闭json序列化的循环引用功能
         */
        byte[] cacheValue = null;
        log.info("serializeType:{}", serializeType);
        switch (serializeType){
            case JSON:
                cacheValue = JsonUtils.toJson(value, SerializerFeature.DisableCircularReferenceDetect).getBytes(StandardCharsets.UTF_8);
                break;
            case KRYO:
                cacheValue = KryoSerializer.serialize(value);
                break;
            default:
                throw new RuntimeException("unsupport serilize type :" + serializeType);

        }
        cacheOperateService.setCache(groupKey, key, cacheValue, cacheDuration, operateTimeout);
    }

    private void writeCache4MapValues(String groupKey, Map<String, Object> keyValues, int cacheDuration, long operateTimeout, SerializeTypeEnum serializeType){
        if(groupKey == null){
            log.info("groupKey 为 null");
            return;
        }
        Map<String, byte[]> cacheValues = Maps.newHashMap();
        for(String key : keyValues.keySet()){
            Object value = keyValues.get(key);
            byte[] cacheValue = null;
            log.info("serializeType:{}", serializeType);
            switch (serializeType){
                case JSON:
                    cacheValue = JsonUtils.toJson(value, SerializerFeature.DisableCircularReferenceDetect).getBytes(StandardCharsets.UTF_8);
                    break;
                case KRYO:
                    cacheValue = KryoSerializer.serialize(value);
                    break;
                default:
                    throw new RuntimeException("unsupport serilize type :" + serializeType);
            }
            cacheValues.put(key, cacheValue);
        }
        cacheOperateService.setCache4MapValues(groupKey, cacheValues, cacheDuration, operateTimeout);
    }

    private int getAutoCacheDuration(FhCacheable annotation, Map<String, Object> paramMap) {
        int defaultDuration = annotation.CACHE_DURATION();
        String autoDurationKey = annotation.CACHE_DURATION_KEY();
        if ("".equals(autoDurationKey)) {
            return defaultDuration;
        }
        Integer autoDuration = parserEL(autoDurationKey, paramMap, Integer.class);
        if (autoDuration == null) {
            return defaultDuration;
        }
        return autoDuration;
    }
}
