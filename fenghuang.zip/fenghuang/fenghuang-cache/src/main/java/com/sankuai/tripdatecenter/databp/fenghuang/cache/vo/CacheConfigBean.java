package com.sankuai.tripdatecenter.databp.fenghuang.cache.vo;

import lombok.Data;
import java.util.Map;

/**
 * Description:
 *
 * @author mayuzhe@meituan.com
 * @date 2022/10/14
 */
@Data
public class CacheConfigBean {
    // 应用总开关。默认为 true，缓存开启
    private boolean masterSwitch = true;
    // 具体缓存配置。key 为缓存 category，value 为配置内容
    private Map<String, CacheConfigDetail> configDetail;

    @Data
    public static class CacheConfigDetail {
        // 缓存开关
        private boolean localSwitch = true;
    }
}
