package com.sankuai.tripdatecenter.databp.fenghuang.cache.service.impl;

import com.dianping.lion.client.ConfigRepository;
import com.dianping.lion.client.Lion;
import com.google.common.collect.Maps;
import com.sankuai.tripdatecenter.databp.fenghuang.cache.service.CacheOperateService;
import com.sankuai.tripdatecenter.databp.fenghuang.common.utils.JsonUtils;
import com.taobao.tair3.client.Result;
import com.taobao.tair3.client.ResultMap;
import com.taobao.tair3.client.TairClient;
import com.taobao.tair3.client.config.impl.SimpleTairConfig;
import com.taobao.tair3.client.config.impl.TairConfig;
import com.taobao.tair3.client.error.TairException;
import com.taobao.tair3.client.impl.MultiTairClient;
import com.taobao.tair3.client.impl.ShareCellarClient;

import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.concurrent.*;
import javax.annotation.PostConstruct;

import com.taobao.tair3.client.util.ByteArray;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.lucene.util.RamUsageEstimator;
import org.springframework.stereotype.Service;


/**
 * @author fuzhengwei02
 * @date 2022/6/30 17:35
 **/
@Slf4j
@Service
public class CacheOperateServiceImpl implements CacheOperateService {

    private static final int CACHE_MAX_PER_SIZE = 1024 * 1024 * 2; //缓存大小上限

    //用于获取链接Lion整体配置
    private static final String APPKEY = "com.sankuai.tripdatecenter.fenghuang";

    //Cellar area属性
    private static final String LION_KEY_CELLAR_AREA = "tair_area";

    //Cellar local和remote的appkey，通过；隔开
    private static final String LION_KEY_CELLAR_APPKEY = "tair_local_remote_appkey";

    public MultiTairClient TAIR_CLIENT = null;

    private Short tairArea;

    private final Map<String, FutureTask<byte[]>> waitingCacheTaskMap = new ConcurrentHashMap<>();

    private void refreshCellarClient(String tairLocalAndRemoteAppkey) {
        String[] appkeys = tairLocalAndRemoteAppkey.split(";");
        String localAppKey = appkeys[0];
        String remoteAppKey = appkeys[1];
        log.info("init tair with locatAppKey:{}, remoteAppKey:{}", localAppKey, remoteAppKey);
        TairConfig config = new SimpleTairConfig(localAppKey, remoteAppKey);
        try {
            TAIR_CLIENT = ShareCellarClient.create(config);
            log.info("Tair Client 初始化成功");
        } catch (TairException e) {
            log.error("Tair Client 初始化失败" + e.getMessage(), e);
        }
    }

    private void refreshCellarArea(Short cellarArea) {
        this.tairArea = cellarArea;
    }

    @PostConstruct
    public void init() {
        ConfigRepository lionConfig = Lion.getConfigRepository(APPKEY);

        String tairLocalAndRemoteAppkey = lionConfig.get(LION_KEY_CELLAR_APPKEY);
        Short tairAreaConfig = lionConfig.getShortValue(LION_KEY_CELLAR_AREA);
        refreshCellarArea(tairAreaConfig);
        log.info("get cellar config :{}, {}", tairAreaConfig, tairLocalAndRemoteAppkey);
        //初始化刷新cellar客户端
        refreshCellarClient(tairLocalAndRemoteAppkey);


        //添加监控，动态变更任务状态信息
        lionConfig.addConfigListener(LION_KEY_CELLAR_AREA, configEvent -> {
            //refresh
            String configValue = configEvent.getValue();
            log.info("receive lion tair area change:{}", configValue);
            Short newArea = Short.parseShort(configValue);
            refreshCellarArea(newArea);
        });
        lionConfig.addConfigListener(LION_KEY_CELLAR_APPKEY, configEvent -> {
            //refresh
            String configValue = configEvent.getValue();
            log.info("receive lion tair local remote appkey change:{}", configValue);
            refreshCellarClient(configValue);
        });

    }

    @Override
    public boolean setCache(String groupKey, String key, byte[] value, int cacheDuration, long operateTimeout) {
        log.info("添加缓存:{}, {}", groupKey, key);
        if (RamUsageEstimator.shallowSizeOf(value) > CACHE_MAX_PER_SIZE) {
            log.info("缓存大小超出限制 :{} key:{},{}, 拒绝存储 ", CACHE_MAX_PER_SIZE, groupKey, key);
            return false;
        }
        if (value == null) {
            log.info("value 为 null，无法缓存。key:{}, value:{}", key, value);
            return false;
        }
        TairClient.TairOption tairOption = new TairClient.TairOption();
        tairOption.setTimeout(operateTimeout);
        tairOption.setExpireTime(cacheDuration);
        try {
            if(StringUtils.isNotBlank(groupKey)){
                Result<Void> result = TAIR_CLIENT.mapPut(tairArea, groupKey.getBytes(StandardCharsets.UTF_8), key.getBytes(StandardCharsets.UTF_8), value, tairOption);
                if (result != null) {
                    log.info("添加缓存key为:{}, {}, 结果为:{}", groupKey, key, JsonUtils.toJson(result));
                    return true;
                }
            }else{
                Result<Void> result = TAIR_CLIENT.put(tairArea, key.getBytes(StandardCharsets.UTF_8), value, tairOption);
                if (result != null) {
                    log.info("添加缓存key为:{}, 结果为: {}", key, JsonUtils.toJson(result));
                    return true;
                }
            }
        } catch (Throwable throwable) {
            log.info("添加缓存失败.", throwable);
            return false;
        }
        return false;
    }

    @Override
    public boolean setCache4MapValues(String groupKey, Map<String, byte[]> keyValues, int cacheDuration, long operateTimeout) {
        if (StringUtils.isBlank(groupKey)) {
            log.info("groupKey 为 空，无法缓存。groupKey:{}", groupKey);
            return false;
        }
        TairClient.TairOption tairOption = new TairClient.TairOption();
        tairOption.setTimeout(operateTimeout);
        tairOption.setExpireTime(cacheDuration);
        try {
            Map<byte[], byte[]> cacheValues = Maps.newHashMap();
            for(String key : keyValues.keySet()){
                cacheValues.put(key.getBytes(StandardCharsets.UTF_8), keyValues.get(key));
            }
            ResultMap<ByteArray, Result<Void>> resultMap = TAIR_CLIENT.mapPut(tairArea, groupKey.getBytes(StandardCharsets.UTF_8), cacheValues, tairOption);
            if (resultMap != null) {
                log.info("添加缓存key为:{}, 结果为:{}", groupKey, JsonUtils.toJson(resultMap));
                return true;
            }
        } catch (Throwable throwable) {
            log.info("添加缓存失败.", throwable);
            return false;
        }
        return false;
    }

    @Override
    public boolean deleteCacheByGroupKey(String groupKey, long operateTimeout) {
        log.info("删除缓存:{}", groupKey);
        if (groupKey == null) {
            log.info("groupKey 为 null");
            return false;
        }
        TairClient.TairOption tairOption = new TairClient.TairOption();
        tairOption.setTimeout(operateTimeout);
        try {
            if(StringUtils.isNotBlank(groupKey)){
                Result<Void> result = TAIR_CLIENT.mapRemoveAll(tairArea, groupKey.getBytes(StandardCharsets.UTF_8), tairOption);
                if (result != null) {
                    log.info("删除map缓存, groupKey为:{}, 结果为:{}", groupKey, JsonUtils.toJson(result));
                    return true;
                }
            }
        } catch (Throwable throwable) {
            log.info("添加缓存失败.", throwable);
            return false;
        }
        return false;
    }

    @Override
    public Map<String, byte[]> getCacheValuesByGroupKey(String groupKey, long retryDuration) {
        log.info("获取map缓存:{}", groupKey);
        if (groupKey == null) {
            log.info("groupKey 为 null");
        }
        TairClient.TairOption tairOption = new TairClient.TairOption();
        tairOption.setTimeout(retryDuration);
        try {
            if(StringUtils.isNotBlank(groupKey)){
                ResultMap<ByteArray, Result<byte[]>> resultMap = TAIR_CLIENT.mapGetAll(tairArea, groupKey.getBytes(StandardCharsets.UTF_8), tairOption);
                if (resultMap != null) {
                    Map<String, byte[]> returnResult = Maps.newHashMap();
                    for(ByteArray keyRaw : resultMap.keySet()){
                        if(keyRaw.getBytes() != null && resultMap.get(keyRaw) != null){
                            returnResult.put(new String(keyRaw.getBytes(), StandardCharsets.UTF_8), resultMap.get(keyRaw).getResult());
                        }
                    }
                    return returnResult;
                }
            }
        } catch (Throwable throwable) {
            log.info("查询缓存失败.", throwable);
        }
        return null;
    }

    @Override
    public byte[] getCache(String groupKey, String key, long operateTimeout) {
        log.info("获取缓存 {}", key);
        if (StringUtils.isBlank(key)) {
            log.info("key 为 null 或空，无法读取缓存。key:{}", key);
        }
        TairClient.TairOption tairOption = new TairClient.TairOption();
        tairOption.setTimeout(operateTimeout);
        try {
            if(StringUtils.isNotBlank(groupKey)){
                Result<byte[]> result = TAIR_CLIENT.mapGet(tairArea, groupKey.getBytes(StandardCharsets.UTF_8), key.getBytes(StandardCharsets.UTF_8), tairOption);
                if(result != null && result.getResult() != null){
                    log.info("获取 {} 的缓存成功",key);
                    return result.getResult();
                }
            }else{
                Result<byte[]> result = TAIR_CLIENT.get(tairArea, key.getBytes(StandardCharsets.UTF_8), tairOption);
                if(result != null && result.getResult() != null){
                    log.info("获取 {} 的缓存成功",key);
                    return result.getResult();
                }
            }
        } catch (Throwable throwable) {
            log.info("获取缓存失败.key:{}", key, throwable);
        }
        return null;
    }

    @Override
    public boolean checkCacheByKey(String groupKey, String key, long operateTimeout) {
        log.info("检查缓存是否存在 {}", key);
        TairClient.TairOption tairOption = new TairClient.TairOption();
        tairOption.setTimeout(operateTimeout);
        try {
            if(StringUtils.isNotBlank(groupKey)){
                Result<Void> result = TAIR_CLIENT.mapExist(tairArea, groupKey.getBytes(StandardCharsets.UTF_8), key.getBytes(StandardCharsets.UTF_8), tairOption);
                if (Result.ResultCode.OK.equals(result.getCode())) {    // 判断是否成功
                    log.info("缓存存在 key:{} result:{}",key,result.getResult());
                    return true;
                } else {
                    log.info("缓存不存在 {}", key);
                    return false;
                }
            }else{
                Result<Void> result = TAIR_CLIENT.exist(tairArea, key.getBytes(StandardCharsets.UTF_8), tairOption);
                if (Result.ResultCode.OK.equals(result.getCode())) {    // 判断是否成功
                    log.info("缓存存在 key:{} result:{}",key,result.getResult());
                    return true;
                } else {
                    log.info("缓存不存在 {}", key);
                    return false;
                }
            }
        } catch (Throwable throwable) {
            log.info("检查缓存失败.", throwable);
        }
        return false;
    }

    @Override
    public boolean tryLock(String groupKey, String key, long operateTimeout, int lockDuration) {
        TairClient.TairOption tairOption = new TairClient.TairOption();
        tairOption.setTimeout(operateTimeout);
        tairOption.setExpireTime(lockDuration);
        try {
           if(StringUtils.isNotBlank(groupKey)){
               Result<Void> result = TAIR_CLIENT.mapSetNx(tairArea, groupKey.getBytes(StandardCharsets.UTF_8), ("lock_" + key).getBytes(StandardCharsets.UTF_8), "1".getBytes(StandardCharsets.UTF_8), tairOption);
               if (Result.ResultCode.OK.equals(result.getCode())) {
                   log.info("获取分布式锁成功 key:{}, result:{}", key, result);
                   return true;
               } else {
                   log.info("分布式锁被占用 key:{}, result:{}", key, result);
                   return false;
               }
           }else{
               Result<Void> result = TAIR_CLIENT.setNx(tairArea, ("lock_" + key).getBytes(StandardCharsets.UTF_8), "1".getBytes(StandardCharsets.UTF_8), tairOption);
               if (Result.ResultCode.OK.equals(result.getCode())) {
                   log.info("获取分布式锁成功 key:{}, result:{}", key, result);
                   return true;
               } else {
                   log.info("分布式锁被占用 key:{}, result:{}", key, result);
                   return false;
               }
           }
        } catch (Throwable throwable) {
            log.info("尝试获取分布式锁失败.key:{},", key, throwable);
            return false;
        }
    }

    @Override
    public void unLock(String groupKey, String key, long operateTimeout) {
        TairClient.TairOption tairOption = new TairClient.TairOption();
        tairOption.setTimeout(operateTimeout);
        try {
            if (checkCacheByKey(groupKey, "lock_" + key, operateTimeout)) {
                if(StringUtils.isNotBlank(groupKey)){
                    Result<Void> result = TAIR_CLIENT.prefixDelete(tairArea, groupKey.getBytes(StandardCharsets.UTF_8), ("lock_" + key).getBytes(StandardCharsets.UTF_8), tairOption);
                    if (Result.ResultCode.OK.equals(result.getCode())) {
                        log.info("分布式锁存在，释放成功 key:{}, result:{}", key, result);
                    } else {
                        log.info("分布式锁存在，释放失败 key:{}, result:{}", key, result);
                    }
                }else{
                    Result<Void> result = TAIR_CLIENT.delete(tairArea, ("lock_" + key).getBytes(StandardCharsets.UTF_8), tairOption);
                    if (Result.ResultCode.OK.equals(result.getCode())) {
                        log.info("分布式锁存在，释放成功 key:{}, result:{}", key, result);
                    } else {
                        log.info("分布式锁存在，释放失败 key:{}, result:{}", key, result);
                    }
                }
            } else {
                log.info("分布式锁不存在，无需释放 key:{}", key);
            }
        } catch (Throwable throwable) {
            log.info("尝试释放分布式锁失败.key:{}", key, throwable);
        }
    }

    @Override
    public byte[] waitingCache(String groupKey, String key, int timeout, long operateTimeout, TimeUnit timeUnit) {
        byte[] cacheValue = null;
        FutureTask<byte[]> futureTask = waitingCacheTaskMap.get(key);
        if (futureTask == null) {
            FutureTask<byte[]> tryTask = new FutureTask<>(new TryCacheResult(groupKey, key, timeout, operateTimeout, timeUnit));
            futureTask = waitingCacheTaskMap.putIfAbsent(key, tryTask);
            if (futureTask == null) {
                futureTask = tryTask;
                futureTask.run();
            }
            try {
                cacheValue = futureTask.get(timeout, TimeUnit.SECONDS);
            } catch (Exception e) {
                log.info("等待缓存获取时异常，任务执行异常 Exception。key:{}, timeout:{}, retryDuration:{}", key, timeout, operateTimeout, e);
            } finally {
                waitingCacheTaskMap.remove(key);
            }
        } else {
            try {
                cacheValue = futureTask.get(timeout, TimeUnit.SECONDS);
            } catch (Exception e) {
                log.info("等待缓存获取时异常。key:{}, timeout:{}, retryDuration:{}", key, timeout, operateTimeout, e);
            }
        }
        return cacheValue;
    }

    private class TryCacheResult implements Callable<byte[]> {
        private final String groupKey;
        private final String key;
        private final int timeout;
        private final long operateTimeout;
        private final TimeUnit timeUnit;

        public TryCacheResult(String groupKey, String key, int timeout, long operateTimeout, TimeUnit timeUnit) {
            this.groupKey = groupKey;
            this.key = key;
            this.timeout = timeout;
            this.operateTimeout = operateTimeout;
            this.timeUnit = timeUnit;
        }

        @Override
        public byte[] call() throws Exception {
            byte[] cacheValue = null;
            boolean flag = false;
            long startTime = System.currentTimeMillis();
            do {
                // 轮询时间
                Thread.sleep(50);
                if (checkCacheByKey(groupKey, "exception_" + key, operateTimeout)) {
                    log.error("key:{} 缓存异常", key);
                    return null;
                }
                if (System.currentTimeMillis() - startTime > (timeout * 1000L)) {
                    log.error("key:{} 获取缓存超时失败.超时时间为:{}", key, (timeout * 1000L));
                    throw new TimeoutException("key:" + key + " 获取缓存超时失败");
                }
                if (checkCacheByKey(groupKey, key, operateTimeout)) {
                    cacheValue = getCache(groupKey, key, operateTimeout);
                    flag = cacheValue != null;
                }
            } while (!flag);
            return cacheValue;
        }
    }
}
